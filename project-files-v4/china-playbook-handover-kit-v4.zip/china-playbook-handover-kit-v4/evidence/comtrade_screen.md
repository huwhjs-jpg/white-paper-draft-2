# UN Comtrade screen: China's share of import value, five markets
Source: UN Comtrade public API (preview endpoint, comtradeapi.un.org/public/v1/preview/C/A/HS), reporter-reported imports, flowCode M, partner China (156) / World (0). Pulled 1 Oct 2026 via browser. Validated against paper figures: Thai pumps 33.3→53.4 (2019→2024), India 841480 44.0→52.6, Indonesia 842952 33.1→74.5 and US$590.6m→1,248.8m — all match.
Format per market: China share % 2015/2019/latest(2024; VN 2023)/2025 where reported, then latest import value US$m. ALL5 = value-weighted China share across the five, 2019→latest, and total import value.

841480 air/gas compressors nes: IN 48/44/53/49 $951m; ID 23/34/46/53 $405m; TH 19/21/37/42 $751m; VN 34/36/53 $197m; MY 32/41/47/52 $335m; ALL5 34->46 $1956m->$2638m
841430 refrigeration compressors: IN 64/74/76/68 $365m; ID 58/74/62/74 $245m; TH 57/69/85/84 $570m; VN 19/46/65 $84m; MY 40/59/49/53 $76m; ALL5 68->75 $1197m->$1340m
841440 air compressors on wheeled chassis: IN 14/35/78/77 $99m; ID 21/31/46/46 $26m; TH 21/29/46/57 $8m; VN 32/43/73 $3m; MY 21/25/32/46 $14m; ALL5 32->66 $166m->$150m
841370 centrifugal pumps nes: IN 32/36/34/35 $212m; ID 26/41/47/60 $390m; TH 26/33/53/56 $268m; VN 19/42/51 $198m; MY 30/40/59/59 $144m; ALL5 38->48 $1060m->$1212m
841360 rotary positive-displacement pumps (incl. hydraulic gear pumps): IN 20/8/15/15 $126m; ID 19/36/33/33 $78m; TH 19/25/29/33 $63m; VN 11/36/37 $13m; MY 13/24/36/38 $51m; ALL5 20->26 $297m->$332m
841350 reciprocating pumps: IN 7/18/11/13 $257m; ID 32/21/37/55 $151m; TH 12/12/19/33 $75m; VN 23/39/56 $36m; MY 23/36/17/25 $54m; ALL5 22->22 $277m->$575m
841381 pumps nes: IN 13/17/26/26 $81m; ID 43/29/29/40 $74m; TH 28/28/41/44 $62m; VN 13/31/39 $57m; MY 12/24/24/18 $45m; ALL5 25->31
841221 hydraulic cylinders: IN 4/6/28/25 $105m; ID 13/32/45/48 $66m; TH 33/29/23/28 $72m; VN 12/22/46 $24m; MY 24/12/17/15 $26m; ALL5 21->31 $192->292m
841229 hydraulic motors (other): IN 7/8/19/18 $250m; ID 10/8/22/28 $65m; TH 5/9/19/18 $48m; VN 9/31/46 $13m; MY 3/10/21/22 $25m; ALL5 9->21 $269->400m
848120 valves for oleohydraulic/pneumatic transmissions: IN 5/7/9/9 $225m; ID 14/9/14/13 $124m; TH 8/6/12/12 $97m; VN 17/26/30 $35m; MY 6/6/9/10 $71m; ALL5 9->12 $348->552m
848180 valves nes (industrial): IN 13/21/22/22 $1319m; ID 28/41/48/54 $919m; TH 22/27/33/36 $806m; VN 23/48/46 $334m; MY 26/27/30/28 $639m; ALL5 30->34 $3113->4016m
848130 check valves: ALL5 24->29; 848140 safety valves: ALL5 18->27
850152 AC multiphase motors 750W–75kW: IN 25/27/27/33 $190m; ID 43/57/64/58 $84m; TH 37/35/49/62 $99m; VN 45/49/54 $42m; MY 54/54/59/57 $57m; ALL5 40->44 $346->472m
850153 AC multiphase motors >75kW: IN 27/23/37/41 $137m; ID 38/58/63/57 $62m; TH 29/23/47/37 $34m; VN 31/53/73 $45m; MY 12/27/37/39 $31m; ALL5 35->49 $221->310m
850140 AC single-phase motors: ALL5 71->85 $392->595m
850131 DC motors ≤750W (incl. many servo/small drives): IN 46/46/56/58 $309m; ID 28/40/30/29; TH 73/54/55/67 $378m; VN 40/37/64 $250m; MY 22/29/38/41 $275m; ALL5 44->52 $820->1267m
850440 static converters (VFDs, inverters, power supplies): IN 44/48/63/62 $1893m; ID 45/53/61/67 $751m; TH 55/48/57/62 $1196m; VN 67/68/78 $1231m; MY 41/46/59/52 $1316m; ALL5 53->64 $3585->6387m (mixed consumer/industrial)
853710 control panels incl. PLC, ≤1,000V: IN 14/15/25/22 $769m; ID 41/40/49/49 $747m; TH 27/30/45/48 $2096m; VN 26/39/58 $1014m; MY 22/22/36/52 $1030m; ALL5 29->43 $3629->5656m
848210 ball bearings: IN 49/50/55/58 $562m; ID 14/23/30/33 $225m; TH 17/24/28/31 $230m; VN 28/34/43 $224m; MY 31/37/51/26 $368m; ALL5 36->45 $1277->1609m
848340 gears, gearboxes, ball screws: IN 40/34/57/64 $641m; ID 15/24/33/31 $267m; TH 24/19/54/53 $163m; VN 19/33/52 $164m; MY 27/29/38/37 $205m; ALL5 29->49 $995->1440m
850423 liquid-dielectric transformers >10MVA: IN 0/16/54/8 $54m; ID 65/80/84/93; TH 87/83/91/89; VN 47/58/50; MY 6/30/43/62; ALL5 55->59 (India volatile; policy restrictions)
850213 diesel generating sets >375kVA: IN 3/15/20/44 $66m; ID 48/66/69/73 $225m; TH 44/51/77/79 $59m; VN 7/26/53 $126m; MY 13/20/84/82 $326m; ALL5 42->69 $403->801m
850212 diesel gensets 75–375kVA: ALL5 71->69
845811 CNC horizontal lathes: IN 10/7/12/13 $158m; ID 7/11/28/36 $24m; TH 4/7/29/58 $49m; VN 8/19/33 $48m; MY 4/9/27/27 $29m; ALL5 10->21 $268->308m
845710 machining centres: IN 2/5/15/12 $385m; ID 4/8/39/30 $48m; TH 1/5/30/43 $121m; VN 7/13/41 $117m; MY 3/8/25/32 $113m; ALL5 7->24 $826->785m
845611 laser machine tools (HS2017+; no 2015): IN -/39/47/44 $133m; ID -/53/70/68 $44m; TH -/33/52/60 $110m; VN -/36/45 $235m; MY -/45/47/54 $99m; ALL5 38->49 $472->621m
847710 injection-moulding machines: IN 13/23/53/47 $306m; ID 27/38/66/69 $203m; TH 26/24/53/68 $223m; VN 34/39/56 $150m; MY 31/48/49/59 $90m; ALL5 33->56 $856->973m
851539 arc welding machines nes: ALL5 65->76 $185->179m
847950 industrial robots nes: IN 12/16/26/34 $172m; ID 8/25/17/62 $73m; TH 20/31/38/44 $58m; VN 13/34/49 $102m; MY 10/26/33/40 $60m; ALL5 25->32 $516->464m
842710 electric forklifts: ALL5 36->65 $344->559m; 842720 other forklifts: ALL5 42->68
842952 360° excavators: IN 5/8/34/38 $210m; ID 16/33/74/73 $1249m; TH 32/35/36/42 $316m; VN 2/5/21 $159m; MY 8/23/50/54 $361m; ALL5 28->58 $1254->2296m
842641 self-propelled cranes on tyres/crawler (part): IN 55/28/90/87 $302m

## Who lost share (value-weighted, five markets, 2019 → latest)
847710 injection moulding: CN 33→56; JP 31→19; KR 8→3; TW 9→4; DE 5→3
845710 machining centres: CN 7→24; JP 50→41; TW 15→10; KR 9→7; DE 6→8
845811 CNC lathes: CN 10→21; JP 46→26; KR 11→17; TW 10→9
845611 laser machines: CN 38→49; DE 13→9; JP 15→15; KR 15→14
848340 gears/gearboxes: CN 29→49; JP 21→14; DE 12→10
853710 control panels/PLC: CN 29→43; JP 15→7; DE 9→5; US 8→7
850213 large gensets: CN 42→69; KR 9→2; DE 7→2; JP 5→2
841480 compressors: CN 34→46; JP 20→15; DE 7→6
841370 pumps: CN 38→48; JP 9→5; KR 7→4
847950 robots: CN 25→32; JP 32→29; KR 16→11
850152 motors: CN 40→44; DE 17→14
848210 ball bearings: CN 36→45; JP 26→16
841229 hydraulic motors: CN 9→21; JP 22→13; DE 13→9; KR 15→15
850131 small DC motors: CN 44→52; JP 18→7
848180 valves: CN 30→34; US 9→12
841440 portable compressors: CN 32→66; JP 21→6; US 12→5
