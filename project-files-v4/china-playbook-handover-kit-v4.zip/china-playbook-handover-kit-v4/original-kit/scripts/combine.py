import json, re, html
E = lambda t: html.escape(str(t), quote=True)
S = json.load(open('/home/claude/build/secs.json'))
C = json.load(open('/home/claude/build/css.json'))
PK = json.load(open('/home/claude/upl/pack.json'))
pk = {}
for it in PK:
    m = re.match(r'^(Exhibit ([0-9A-Z]+b?)|Part (I|II|III|IV) (flow|at a glance))\.', it['cap'])
    key = m.group(2) if m.group(2) else f"P{m.group(3)} {m.group(4)}"
    pk[key] = it

def sup(t):
    # turn trailing reference digits like 'Finance Ministry customs notifications37' into superscripts where clearly glued
    return E(t)

def pack_section(key):
    it = pk[key]
    cap = it['cap']
    num, title = cap.split('. ', 1)
    parts = []
    for img in it['imgs']:
        parts.append(f'<div class="pk-img"><img src="pack/{E(img)}" alt="{E(title)}" loading="lazy"></div>')
    for t in it['tables']:
        head = ''.join(f'<th>{E(c)}</th>' for c in t[0])
        rows = ''.join('<tr>' + ''.join(f'<td>{E(c)}</td>' for c in r) + '</tr>' for r in t[1:])
        parts.append(f'<div class="tw pk-tw"><table><thead><tr>{head}</tr></thead><tbody>{rows}</tbody></table></div>')
    notes = ''.join(f'<span>{E(n)}</span>' for n in it['notes'])
    src = f'<div class="ex-src">{notes}</div>' if notes else ''
    return (f'<section class="ex pk" id="pk-{re.sub(r"[^A-Za-z0-9]", "", key)}"><div class="ex-num">{E(num)} <span>{E(it["placement"])}</span> '
            f'<span class="ex-tag pkt">your pack · {E(it["type"].lower())}</span></div><p class="ex-head">{E(title)}</p>'
            f'<div class="frame">{"".join(parts)}{src}</div></section>')

def ours(n):
    s = S[str(n)]
    return s.replace('<div class="ex-num">Exhibit ', '<div class="ex-num">Built here · Exhibit ', 1)

slots = [
 ("Front matter", "Executive summary · the six learnings", [], ["A"]),
 ("Front matter", "About this paper · scope", [], ["B"]),
 ("Front matter", "About this paper · how the paper is organised", [1], ["1", "1b"]),
 ("Part I · The shift", "Part I opener", [2], ["PI flow", "PI at a glance"]),
 ("Part I · The shift", "Chapter 1 · export volumes", [3], []),
 ("Part I · The shift", "Chapter 1 · overseas revenue", [4], ["2"]),
 ("Part I · The shift", "Chapter 1 · the 2026 policy reset", [5], ["3"]),
 ("Part I · The shift", "Chapter 2 · import shares by country and category", [6], ["4"]),
 ("Part I · The shift", "Chapter 2 · Japanese and Korean suppliers", [], ["5"]),
 ("Part I · The shift", "Chapter 2 · Indonesian distributor shares", [7], ["6"]),
 ("Part I · The shift", "Chapter 2 · category sequence", [], ["7"]),
 ("Part I · The shift", "Chapter 3 · the five tests", [], ["8"]),
 ("Part I · The shift", "Chapter 3 · verdict", [8], ["9"]),
 ("Part II · The playbook", "Part II opener", [9, 10], ["PII flow", "PII at a glance", "10"]),
 ("Part II · The playbook", "Chapter 5 · SANY's finance steps", [11], ["11"]),
 ("Part II · The playbook", "Chapter 6 · pricing and lifecycle", [12, 13], []),
 ("Part II · The playbook", "Chapter 7 · plants", [14], ["12"]),
 ("Part II · The playbook", "Chapter 8 · local-content rules", [15], []),
 ("Part II · The playbook", "Chapter 9 · electrification", [16], ["13"]),
 ("Part II · The playbook", "End of Part II · moves over time", [17], []),
 ("Part III · Markets", "Part III opener", [18, 19], ["PIII flow", "PIII at a glance"]),
 ("Part III · Markets", "Chapter 10 · where Chinese brands have gained", [21], ["14"]),
 ("Part III · Markets", "Chapter 10 · the crane case", [20], ["15"]),
 ("Part III · Markets", "Chapter 11 · Indonesia", [22], ["16"]),
 ("Part III · Markets", "Chapter 12 · Thailand", [23], ["17"]),
 ("Part IV · Limits and actions", "Part IV opener", [24], ["PIV flow", "PIV at a glance"]),
 ("Part IV · Limits and actions", "Chapter 13 · failure modes", [25], ["18"]),
 ("Part IV · Limits and actions", "Chapter 14 · actions by reader", [26], ["19"]),
 ("Part IV · Limits and actions", "Chapter 15 · signposts", [27], ["20"]),
 ("Appendices", "Data appendix", [], ["B1"]),
]
used = {k for s in slots for k in s[3]}
assert used == set(pk), (set(pk) - used, used - set(pk))
assert sorted(n for s in slots for n in s[2]) == list(range(1, 28))

out, idx, lastgrp = [], [], None
for i, (grp, where, ob, pb) in enumerate(slots, 1):
    if grp != lastgrp:
        out.append(f'<div class="group">{E(grp)}</div>'); lastgrp = grp
    o = ''.join(ours(n) for n in ob)
    p = ''.join(pack_section(k) for k in pb)
    count = len(ob) + len(pb)
    out.append(f'<section class="slot" id="s{i}"><div class="slot-h"><span class="slot-n">Position {i}</span><h2>{E(where)}</h2><span class="slot-c">{count} option{"s" if count != 1 else ""}</span></div>{o}{p}</section>')
    def lab(k):
        it = pk[k]; return E(it['cap'].split('. ')[0])
    idx.append(f'<tr><td class="num"><a href="#s{i}">{i}</a></td><td>{E(where)}</td><td>{", ".join(str(n) for n in ob) or "—"}</td><td>{", ".join(lab(k) for k in pb) or "—"}</td></tr>')

css = '''<style>
.slot{padding-top:40px;display:grid;gap:4px}
.slot-h{display:flex;flex-wrap:wrap;align-items:baseline;gap:6px 14px;border-bottom:2px solid var(--ink);padding-bottom:6px}
.slot-h h2{border:0;padding:0;font-size:22px}
.slot-n{font-family:var(--mono);font-size:12px;color:var(--accent)}
.slot-c{font-size:12.5px;color:var(--muted);margin-left:auto}
.ex.pk .frame{border-top:3px solid var(--jp)}
.pkt{background:var(--warn-bg);color:var(--warn)}
.pk-img{background:#fff;border:1px solid var(--rule);padding:8px;border-radius:4px}
.pk-img img{display:block;width:100%;height:auto}
.pk-tw table{min-width:560px}
.pk-tw td{font-size:12.5px}
.ex-src span{overflow-wrap:anywhere}
.legend2{display:flex;flex-wrap:wrap;gap:8px 18px;font-size:13px;color:var(--muted)}
.legend2 i{display:inline-block;width:22px;height:4px;vertical-align:3px;margin-right:6px}
</style>'''

body = f'''<div class="wrap">
<header class="top">
  <div class="eyebrow">Step 3 · Combined exhibit set · 29 September 2026</div>
  <h1>The China Playbook: all exhibit options</h1>
  <p class="lede">The 27 exhibits built in this project and the 32 in your exhibit pack, placed together at the point in the paper where each belongs. Where both sets cover the same point, the options sit one after another so you can choose.</p>
  <div class="legend2"><span><i style="background:var(--cn)"></i>Built here (Exhibits 1–27)</span><span><i style="background:var(--jp)"></i>Your pack (Exhibits A, B, 1–20, 1b, B1 and eight Part diagrams)</span></div>
</header>
<section id="index">
  <h2>Index by position in the paper</h2>
  <div class="tw"><table>
    <thead><tr><th class="num">#</th><th>Position</th><th>Built here</th><th>Your pack</th></tr></thead>
    <tbody>{"".join(idx)}</tbody>
  </table></div>
</section>
<section id="flags">
  <h2>Differences to settle before choosing</h2>
  <ul class="prose">
    <li><b>Reader groups.</b> Your pack uses five reader groups, with dealers and financiers together (Exhibit 1b, Part IV at a glance, Exhibit 19). The agreed decision is six, with them split. The built set uses six.</li>
    <li><b>Learning 5 label.</b> Your pack's Exhibit 1 and Part II flow say “FDI rules”; the agreed label is “investment rules” (Step 1, F3).</li>
    <li><b>India crane duties.</b> Your pack says “still unnotified” (Part III at a glance, Exhibits 3 and 20). Step 1 found they were not imposed within the three-month window; the wording needs to follow F1.</li>
    <li><b>Failure-mode count.</b> Your pack has seven (trade remedies in India and abroad counted separately); the built set has six. Either works, but the paper must use one count.</li>
    <li><b>Colour.</b> Your pack shows China in orange and Japan in blue; the built set shows China in blue and Japan in amber. The final paper should use one scheme.</li>
  </ul>
</section>
{"".join(out)}
</div>'''
open('/home/claude/pub/index.html', 'w').write('<title>China Playbook Exhibit Options</title>\n' + C['head'] + C['css'] + css + body)
print('ok', len(slots))
