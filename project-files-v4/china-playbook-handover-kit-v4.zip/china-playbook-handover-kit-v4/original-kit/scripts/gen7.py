import re,html
t=open('step7_text.html').read()
def wc(id_):
    s=re.search(r'<div id="%s">(.*?)\n    </div>\n'%id_, t, re.S).group(1)
    for pat in [r'<sup>.*?</sup>', r'<div class="exslot">.*?</div>', r'<h3.*?</h3>', r'<span class="(hz|lt|fl)[^"]*">.*?</span>']:
        s=re.sub(pat,'',s,flags=re.S)
    return len(html.unescape(re.sub(r'<[^>]+>',' ',s)).split())
ids=['p0','c13','c14','c15']; c={k:wc(k) for k in ids}; c['all']=sum(c.values()); print(c)
draft={'p0':50,'c13':600,'c14':700,'c15':550}
names={'p0':'Part IV introduction','c13':'Chapter 13 · Where the playbook breaks','c14':'Chapter 14 · What each reader should do','c15':'Chapter 15 · Outlook and signposts'}
rows=''.join(f'<tr><td>{names[k]}</td><td class="num">{draft[k]:,}</td><td class="num">{c[k]:,}</td></tr>' for k in ids)
rows+=f'<tr><td><b>Part IV total</b></td><td class="num"><b>~{sum(draft.values()):,}</b></td><td class="num"><b>{c["all"]:,}</b></td></tr>'
body_tot=1202+2504+3250+2208+c["all"]
share=round((c["all"]+259)/body_tot*100)
print(body_tot, share)
src=open('/home/claude/build/pub/china-playbook-step7-part4.html').read()
css=re.search(r'<style>.*?</style>',src,re.S).group(0)
page=src[src.index('</style>')+8:]
page=re.sub(r'(<section id="summary">.*?<tbody>).*?(</tbody>)', lambda m: m.group(1)+rows+m.group(2), page, count=1, flags=re.S)
page=page.replace('New counts exclude headings, exhibit slots, superscripts, tables and the horizon and learning tags.','New counts include tables and exclude headings, exhibit slots, superscripts and the horizon and learning tags.')
bal=f'''<tr><td>About this paper, executive summary, conclusion</td><td class="num">1,750</td><td class="num">1,202</td></tr>
    <tr><td>Part I · The shift</td><td class="num">4,960</td><td class="num">2,504</td></tr>
    <tr><td>Part II · The playbook</td><td class="num">6,450</td><td class="num">3,250</td></tr>
    <tr><td>Part III · Markets (including tables)</td><td class="num">3,360</td><td class="num">2,208</td></tr>
    <tr><td>Part IV · Limits and actions (including tables)</td><td class="num">1,900</td><td class="num">{c["all"]:,}</td></tr>
    <tr><td><b>Body total</b></td><td class="num"><b>~18,400</b></td><td class="num"><b>{body_tot:,}</b></td></tr>'''
page=re.sub(r'(<section id="balance">.*?<tbody>).*?(</tbody>)', lambda m: m.group(1)+bal+m.group(2), page, count=1, flags=re.S)
page=re.sub(r'Part IV plus the conclusion&#39;s agenda now makes up about \d+%|Part IV plus the conclusion\'s agenda now makes up about \d+%', f"Part IV plus the conclusion now makes up about {share}%", page)
page=re.sub(r'(<section id="text"><h2>Rewritten text</h2><div class="paper">).*?(</div></section>\s*<section id="checks">)', lambda m: m.group(1)+'\n'+t+'\n'+m.group(2), page, count=1, flags=re.S)
open('/home/claude/build/pub/china-playbook-step7-part4.html','w').write('<title>China Playbook Part IV Rewrite</title>\n'+open('/home/claude/_head.html').read()+css+page)
