import json, re
RR = json.load(open('/home/claude/build/refrows.json'))
css = re.search(r'<style>.*?</style>', open('/home/claude/build/pub/china-playbook-step6-part3.html').read(), re.S).group(0)
css = css.replace('</style>', '''.ctx{font-size:12px;color:var(--muted)}
.ph{background:var(--warn-bg);color:var(--warn);padding:1px 6px;border-radius:3px;font-family:var(--sans);font-size:13px}
.toc2{font-family:var(--sans);font-size:14.5px;display:grid;gap:3px}
.toc2 .pt{font-weight:700;color:var(--ink);margin-top:8px}
.toc2 .ch{padding-left:18px}
.gl td:first-child{font-weight:700;color:var(--ink);white-space:nowrap}
details.big summary{cursor:pointer;font-weight:700;color:var(--accent);padding:6px 0}
</style>''')

body = f'''{css}
<div class="wrap">
<header class="top">
  <div class="eyebrow">Step 8 of 9 · Front and back matter · 29 September 2026</div>
  <h1>The China Playbook: front and back matter</h1>
  <p class="lede">Everything around the body of the paper: cover lines, disclaimer, table of contents, About YCP, Appendix A on method and definitions, the glossary, and a full audit of the references against the rewritten text.</p>
  <div class="meta"><span>Orange tags mark text only you can supply</span><span>Voice: “we”, no “you”</span></div>
</header>
<nav class="toc" aria-label="Sections"><a href="#need">What I need from you</a><a href="#front">Front matter</a><a href="#about">About YCP</a><a href="#appa">Appendix A</a><a href="#gloss">Glossary</a><a href="#refs">References</a></nav>

<section id="need">
  <h2>What I need from you</h2>
  <div class="tw"><table><thead><tr><th>Item</th><th>Why</th></tr></thead><tbody>
    <tr><td>The house disclaimer text and the legal entity name</td><td>The past papers carry a standard disclaimer at the foot of the cover. I have not seen its wording, so I have not invented one.</td></tr>
    <tr><td>About YCP: the approved firm description</td><td>A draft structure is below, with placeholders for facts such as office count and founding year.</td></tr>
    <tr><td>Publication month</td><td>The draft says September 2026. If the paper goes out in October, the cover and the as-of line change.</td></tr>
  </tbody></table></div>
</section>

<section id="front">
  <h2>Front matter</h2>
  <div class="paper">
    <h3>Cover</h3>
    <p><b>The China Playbook for Emerging Asia</b><br>What industrial leaders can learn from Chinese OEMs' rise in India and Southeast Asia<br><span class="ph">Month</span> 2026</p>
    <p>Data as of 28 September 2026 · Free, publicly verifiable sources only</p>
    <p><span class="ph">House disclaimer, set in small print at the foot of the cover</span></p>

    <h3>Contents</h3>
    <div class="toc2">
      <span>Executive summary</span><span>About this paper</span>
      <span class="pt">Part I · The shift</span>
      <span class="ch">1. Why learn from Chinese OEMs now</span><span class="ch">2. Where the shift is happening</span><span class="ch">3. Structural or cyclical?</span>
      <span class="pt">Part II · The playbook</span>
      <span class="ch">4. Learning 1: Enter through a narrow beachhead, then broaden</span><span class="ch">5. Learning 2: Treat customer credit as part of the product</span><span class="ch">6. Learning 3: Price just enough, then invest in the lifecycle</span><span class="ch">7. Learning 4: Localise plants, then export from the host</span><span class="ch">8. Learning 5: Turn local-content and investment rules into an advantage</span><span class="ch">9. Learning 6: Use electrification as the entry wedge</span><span class="ch">Box: Two supporting moves</span>
      <span class="pt">Part III · Markets</span>
      <span class="ch">10. India: the full playbook meets pushback</span><span class="ch">11. Indonesia: the complete case</span><span class="ch">12. Thailand and the comparators</span>
      <span class="pt">Part IV · Limits and actions</span>
      <span class="ch">13. Where the playbook breaks</span><span class="ch">14. What each reader should do</span><span class="ch">15. Outlook to 2030 and signposts</span>
      <span class="pt">Conclusion: a playbook open to every firm</span>
      <span class="pt">Appendices</span>
      <span class="ch">A. Method and definitions</span><span class="ch">B. Glossary</span><span class="ch">C. UN Comtrade import values used in this paper (your pack's Exhibit B1, if chosen)</span>
      <span class="pt">References · About YCP · Our offices</span>
    </div>
    <p class="ctx">Page numbers are added at assembly. The titles above match the rewritten chapters exactly.</p>
  </div>
</section>

<section id="about">
  <h2>About YCP</h2>
  <div class="paper">
    <p>YCP is <span class="ph">approved one-line description of the firm</span>, with <span class="ph">number</span> offices across Asia and beyond. <span class="ph">One sentence on how YCP works, as the firm describes it</span>.</p>
    <p>For industrial companies, dealers and investors in India and Southeast Asia, our work includes market entry, channel and dealer design, qualification for local-content rules and incentives, and partner search and M&amp;A.</p>
    <p>We welcome conversations with firms working through what the findings of this paper mean for their plans in the region. <span class="ph">Contact email or web page</span></p>
  </div>
  <p class="prose ctx">Firm-level only, with no author bios, as decided. The closing invitation in the conclusion (Step 2) uses the same four capabilities; change both together.</p>
</section>

<section id="appa">
  <h2>Appendix A. Method and definitions</h2>
  <div class="paper">
    <h4>A.1 Import shares</h4>
    <p>China's share of imports is the value of imports from China divided by the value of imports from the world, in US dollars, for the reporting country and product code. Data come from UN Comtrade through the World Bank's WITS portal, retrieved on 27 September 2026. The product codes are HS 842952 for 360° excavators; 842710 and 842720 for electric and other forklifts, summed; 842641 and 842649 for self-propelled cranes, summed; 841480 for air and gas compressors not elsewhere specified; and 841370 for centrifugal pumps not elsewhere specified. These codes are narrower than the four equipment families: they cover the main products in each, not every product. There is no trade measure for robots in this paper.</p>
    <p>We compare 2019, the last full year before the pandemic and before most of the moves described here, with 2024, the latest full year most countries have reported. Vietnam has not reported 2024, so its latest year is 2023; where we use Vietnam's 2024 position, we use exporters' reports of their shipments to Vietnam (mirror data), which are valued differently and are not strictly comparable. Vietnam's 2019 excavator data show Japan and Korea with identical unit counts, so we check its trend against a 2020 base.</p>

    <h4>A.2 Definitions</h4>
    <ul>
      <li><b>Chinese OEM</b> means an equipment maker headquartered in mainland China, counted by the brand it sells under. SDLG is a Chinese brand, which Volvo owned 70% of until 2025. AntOn is a Jungheinrich brand made for it in China by EP Equipment, so it counts as an incumbent's brand even though its imports count as Chinese in trade data. Machines that incumbents make in China, such as Caterpillar's Chinese output, likewise count as Chinese in trade data.</li>
      <li><b>Equipment families.</b> Construction and mining equipment (excavators, loaders, cranes and piling rigs); material handling (forklifts, and in the trade data self-propelled cranes); compressors, pumps and fluid power; and factory automation and robotics.</li>
      <li><b>Market shares.</b> This paper uses four kinds of share, which are not interchangeable: import shares by value (A.1); company-reported shares, such as United Tractors' Komatsu share, which the company bases on internal market research; Hexindo's reported share, which covers excavators above six tonnes up to 2023 and heavy-equipment sales in 2024 and 2025; and India's road registrations, which cover mostly wheeled machines.</li>
      <li><b>Financial years.</b> Indian figures marked FY run from April to March; FY26 is April 2025 to March 2026.</li>
      <li><b>Currency.</b> Figures are given in the currency reported. Headline local-currency figures carry a US-dollar equivalent at rates on 28 September 2026. <span class="ph">Rates added at assembly</span></li>
    </ul>

    <h4>A.3 Strength of evidence</h4>
    <p>The grades for each learning by country rate the public evidence, not the size of the effect. <b>Strong:</b> regulator findings, filings or trade data show both the move and its effect. <b>Moderate:</b> the move is documented, but its effect rests on company claims or indirect data. <b>Weak:</b> there is little public evidence of the move.</p>

    <h4>A.4 Structural or cyclical</h4>
    <p>Chapter 3 applies five tests: whether the incumbent loses share in good years as well as bad; whether the shift began before the cyclical shock; whether it appears outside the cyclical segment; whether it holds in a control market without the cycle; and whether lost share has come back anywhere. A yes on any of the first three points to a structural shift; a no on the fourth points to an effect specific to the category; a yes on the fifth means the market is still contestable. Each market is then graded on a five-point scale: structural, likely structural, inconclusive, likely cyclical or cyclical.</p>

    <h4>A.5 Our calculations</h4>
    <ul>
      <li><b>Indonesian market size:</b> United Tractors' Komatsu units divided by Komatsu's reported share, rounded to the nearest 100 units.</li>
      <li><b>Combined Japanese share in Indonesia:</b> Komatsu's share plus Hitachi's as reported by Hexindo. Because the two measure different things, the sum is indicative only.</li>
      <li><b>China's share of Vietnam's 2024 excavator supply:</b> China's reported exports to Vietnam as a share of China's, Japan's and Korea's combined.</li>
      <li><b>Korea against Japan:</b> each country's change in import share measured against its own 2019 share.</li>
      <li><b>United Tractors' machine revenue:</b> segment revenue less parts and service revenue, from the company's rounded figures.</li>
      <li><b>Battery-pack prices in North America and Europe:</b> BloombergNEF's China price raised by the 44% and 56% premiums it reports.</li>
    </ul>

    <h4>A.6 Sources and limits</h4>
    <p>We used only free, publicly verifiable sources: trade data, company filings and releases, regulators and governments, reputable media, and notes by law firms and research institutes. We used no paid databases, surveys or interviews, so buyers' views appear only as companies and dealers report them. Company claims, competitors' claims and our own calculations are labelled as such in the text. Import data record where a machine was shipped from, not whose badge it carries; they miss machines built locally and can be affected by re-exports and misclassification. Retail and e-catalogue prices are asking prices, not transaction prices. No free public dataset of used-equipment prices by brand exists in these markets, so claims about resale value remain untested.</p>
  </div>
</section>

<section id="gloss">
  <h2>Appendix B. Glossary</h2>
  <p class="prose ctx">Completed from the 13 draft entries. “UT” is dropped because the text now uses “United Tractors” in full. Entries are in the P1 style, with a meaning for each.</p>
  <div class="tw gl"><table><thead><tr><th>Term</th><th>Meaning</th></tr></thead><tbody>
    <tr><td>ACFTA</td><td>ASEAN–China Free Trade Area, under which fully built Chinese heavy equipment enters Indonesia free of duty</td></tr>
    <tr><td>BOI</td><td>Board of Investment, Thailand's investment-promotion agency</td></tr>
    <tr><td>CCMA</td><td>China Construction Machinery Association, the source of China's excavator sales data</td></tr>
    <tr><td>CETA</td><td>UK–India Comprehensive Economic and Trade Agreement, in force since 15 July 2026</td></tr>
    <tr><td>DGTR</td><td>Directorate General of Trade Remedies, India's trade-remedies regulator</td></tr>
    <tr><td>e-catalogue</td><td>A government's online marketplace for public purchasing: GeM in India, INAPROC in Indonesia</td></tr>
    <tr><td>EEC</td><td>Eastern Economic Corridor, Thailand's industrial zone east of Bangkok</td></tr>
    <tr><td>EV 3.5</td><td>Thailand's 2024–27 incentive scheme for electric vehicles, which ties subsidies to local production</td></tr>
    <tr><td>FADA</td><td>Federation of Automobile Dealers Associations, the source of India's retail registrations</td></tr>
    <tr><td>FDI</td><td>Foreign direct investment</td></tr>
    <tr><td>FY</td><td>Indian financial year, April to March</td></tr>
    <tr><td>GeM</td><td>Government e-Marketplace, India's public-purchasing platform</td></tr>
    <tr><td>GFR 144(xi)</td><td>Rule in India's General Financial Rules that restricts public-tender bidders from countries sharing a land border with India</td></tr>
    <tr><td>HINABI</td><td>Indonesian association of heavy-equipment manufacturers</td></tr>
    <tr><td>HS</td><td>Harmonized System, the international product classification used in trade data</td></tr>
    <tr><td>ICEMA</td><td>Indian Construction Equipment Manufacturers' Association</td></tr>
    <tr><td>INAPROC</td><td>Indonesia's national e-catalogue for public purchasing, run by the procurement agency LKPP</td></tr>
    <tr><td>LFP</td><td>Lithium iron phosphate, the cheaper battery chemistry used in most Chinese packs</td></tr>
    <tr><td>Mirror data</td><td>Trade figures taken from the exporting country's reports when the importer has not reported</td></tr>
    <tr><td>NBFC</td><td>Non-bank financial company, India's term for lenders outside the banking system</td></tr>
    <tr><td>n.e.s.</td><td>Not elsewhere specified, a residual product code in trade data</td></tr>
    <tr><td>OEM</td><td>Original equipment manufacturer: the company whose brand the machine carries</td></tr>
    <tr><td>OJK</td><td>Otoritas Jasa Keuangan, Indonesia's financial services regulator</td></tr>
    <tr><td>Press Note 2 (2026)</td><td>India's revised rules for investment from countries sharing a land border with India</td></tr>
    <tr><td>RKAB</td><td>Indonesia's annual mining work plan and budget, which sets production quotas</td></tr>
    <tr><td>Rule 18(1)</td><td>The provision of India's Anti-Dumping Rules, 1995, allowing the government to impose a duty within three months of the regulator's final findings</td></tr>
    <tr><td>Section 122</td><td>US trade-law provision used for a temporary 10% surcharge from February to July 2026</td></tr>
    <tr><td>Section 301</td><td>US trade-law provision used for two separate 2026 actions: an investigation into excess capacity, and tariffs over the enforcement of bans on imports made with forced labour</td></tr>
    <tr><td>Stage V</td><td>India's emission standard for construction equipment, which has raised machine prices</td></tr>
    <tr><td>TKDN</td><td>Tingkat Komponen Dalam Negeri, Indonesia's local-content score</td></tr>
    <tr><td>WITS</td><td>World Integrated Trade Solution, the World Bank's portal to UN Comtrade data</td></tr>
  </tbody></table></div>
  <p class="prose ctx">Dropped from the draft glossary because the text no longer uses the term: QCO (the text says “certification rule”) and UT.</p>
</section>

<section id="refs">
  <h2>References</h2>
  <h3>Rules for the final list</h3>
  <ul class="prose">
    <li>Numbered in order of first citation in the final text, so numbers change at assembly.</li>
    <li>Each entry adds a “Used for” note naming the figure it supports, as P16 does.</li>
    <li>Exhibit source lines cite the same numbers.</li>
  </ul>

  <h3>New references to add</h3>
  <div class="tw"><table><thead><tr><th>Reference</th><th>Supports</th></tr></thead><tbody>
    <tr><td>Customs Tariff (Identification, Assessment and Collection of Anti-Dumping Duty on Dumped Articles and for Determination of Injury) Rules, 1995, Rule 18(1). India Code.</td><td>Crane duties not imposed within three months (Chapters 1, 8, 10, 13)</td></tr>
    <tr><td>Vietnam imports of HS 842952 by partner, 2020. UN Comtrade via WITS (add to reference 75).</td><td>Vietnam 2020 base (Chapter 2)</td></tr>
    <tr><td>“China's excavator exports boom in 2021”. China Daily, 16 January 2022.</td><td>2021 domestic and export sales (built Exhibit 3)</td></tr>
    <tr><td>“Excavator sales rise 3.13% YoY in 2024”. Shanghai Metals Market (CCMA data).</td><td>2024 domestic and export sales (built Exhibit 3)</td></tr>
  </tbody></table></div>

  <h3>Sources to upgrade</h3>
  <div class="tw"><table><thead><tr><th class="num">Ref</th><th>Now</th><th>Upgrade</th></tr></thead><tbody>
    <tr><td class="num">86</td><td>An automated summary of Estun's annual report on Sina Finance (the URL is an AI-generated content page)</td><td><b>Priority.</b> Replace with Estun's 2025 annual report on CNINFO</td></tr>
    <tr><td class="num">3, 4, 6</td><td>Sina Finance articles on Zoomlion, XCMG and LiuGong results</td><td>The companies' 2025 annual reports on CNINFO or HKEXnews</td></tr>
    <tr><td class="num">17</td><td>MarketScreener copy of a United Tractors release</td><td>The release on United Tractors' own site, as for refs 15 and 16</td></tr>
    <tr><td class="num">145, 146</td><td>Third-party summaries of ELGi's earnings call</td><td>ELGi's own call transcript on NSE, if published; otherwise keep and label as summaries</td></tr>
    <tr><td class="num">23</td><td>OJK's general announcements page</td><td>A direct link to the licence announcement</td></tr>
    <tr><td class="num">109, 138</td><td>Home pages of Trakindo and SANY India</td><td>The specific page supporting the fact (Trakindo as Caterpillar dealer; SANY India's company-owned outlet model)</td></tr>
  </tbody></table></div>

  <h3>References the rewrite no longer cites ({RR["n_drop"]})</h3>
  <div class="tw"><table><thead><tr><th class="num">Ref</th><th>Source</th><th>Why</th><th>Action</th></tr></thead><tbody>{RR["drop_rows"]}</tbody></table></div>

  <details class="big"><summary>All {RR["n_cited"]} references still cited, with where and for what</summary>
  <div class="tw"><table><thead><tr><th class="num">Ref</th><th>Source</th><th>Cited in</th><th>Supports (text before the citation)</th></tr></thead><tbody>{RR["rows"]}</tbody></table></div>
  </details>
</section>
</div>'''
open('/home/claude/build/pub/china-playbook-step8-matter.html', 'w').write('<title>China Playbook Front and Back Matter</title>\n' + open('/home/claude/_head.html').read() + body)
print('ok')
