import json
P = json.load(open('/home/claude/build/parts.json'))
WC = json.load(open('/home/claude/build/wc.json'))
head = open('/home/claude/_head.html').read()

css = r'''<style>
.wrap{max-width:1480px}
:root{--cn:#0B6FD9;--jp:#C07A00;
  --h1:#EDF3FC; --h1t:#0D1E43; --h2:#C9DDF6; --h2t:#0D1E43; --h3:#8DB9EC; --h3t:#0D1E43;
  --h4:#2A78D2; --h4t:#FFFFFF; --h5:#0D1E43; --h5t:#FFFFFF; --na:#F1F3F6; --nat:#8A93A6;}
@media (prefers-color-scheme: dark){:root:not([data-theme="light"]){--cn:#3383E0;--jp:#B97A12;
  --h1:#152646; --h1t:#D3DBE8; --h2:#1D3B69; --h2t:#E8EEF8; --h3:#2B5A9C; --h3t:#FFFFFF;
  --h4:#5B97DE; --h4t:#0B1426; --h5:#B7D4F7; --h5t:#0B1426; --na:#141F36; --nat:#7D8AA3;}}
:root[data-theme="dark"]{--cn:#3383E0;--jp:#B97A12;
  --h1:#152646; --h1t:#D3DBE8; --h2:#1D3B69; --h2t:#E8EEF8; --h3:#2B5A9C; --h3t:#FFFFFF;
  --h4:#5B97DE; --h4t:#0B1426; --h5:#B7D4F7; --h5t:#0B1426; --na:#141F36; --nat:#7D8AA3;}
.b1{background:var(--h1)!important;color:var(--h1t)} .b2{background:var(--h2)!important;color:var(--h2t)}
.b3{background:var(--h3)!important;color:var(--h3t)} .b4{background:var(--h4)!important;color:var(--h4t)}
.b5{background:var(--h5)!important;color:var(--h5t)} .na{background:var(--na)!important;color:var(--nat);font-style:italic}
.nat{color:var(--nat)}
.group{font-size:12.5px;letter-spacing:.09em;text-transform:uppercase;font-weight:700;color:var(--muted);padding-top:40px}
.ex{display:grid;gap:14px;padding-top:30px}
.ex-num{font-family:var(--mono);font-size:13px;color:var(--accent);font-weight:500;display:flex;gap:12px;flex-wrap:wrap}
.ex-num span{color:var(--muted)}
.ex-head{font-family:var(--serif);font-size:23px;color:var(--ink);font-weight:600;line-height:1.25;text-wrap:balance;margin:0;max-width:62ch}
.pair{display:grid;gap:18px}
@media (min-width:1180px){.pair{grid-template-columns:minmax(0,1fr) minmax(0,1fr);align-items:start}}
.ver{display:grid;gap:8px}
.vlab{font-size:12px;letter-spacing:.08em;text-transform:uppercase;font-weight:700;color:var(--muted);display:flex;justify-content:space-between;gap:8px;flex-wrap:wrap}
.vlab .w{font-family:var(--mono);letter-spacing:0;text-transform:none;font-weight:500}
.ver.b .vlab{color:var(--accent)}
.frame{background:var(--surface);border:1px solid var(--rule);padding:18px clamp(14px,2.4vw,24px);display:grid;gap:12px}
.ver.b .frame{border-top:3px solid var(--cn)}
.ex-title{font-family:var(--serif);font-size:15.5px;color:var(--ink);font-weight:600;padding-bottom:6px;border-bottom:1.5px solid var(--ink);margin:0}
.ex-src{display:grid;gap:3px;font-size:12px;color:var(--muted);font-style:italic;border-left:3px solid var(--fill);padding-left:10px}
.frame table{min-width:640px}
.frame td,.frame th{font-size:13px}
/* reuse A styles */
.amap{display:grid;gap:12px}
.amap .q,.amap .a{padding:14px 18px;font-family:var(--serif);font-size:16px;line-height:1.45}
.amap .q{background:var(--pale);color:var(--ink)} .amap .a{background:var(--h5);color:var(--h5t)}
.lbl{display:block;font-family:var(--sans);font-size:11px;letter-spacing:.09em;text-transform:uppercase;font-weight:700;opacity:.8;margin-bottom:3px}
.parts{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}
.part{border:1px solid var(--rule);border-top:4px solid var(--h4);background:var(--surface);padding:12px 14px;display:grid;gap:8px;align-content:start}
.part .pn{font-family:var(--mono);font-size:12px;color:var(--accent)} .part h4{margin:0;font-family:var(--serif);font-size:16px;color:var(--ink)}
.part .pq{font-size:13px;color:var(--muted);font-style:italic} .part .pa{font-size:13.5px} .part .ch{font-family:var(--mono);font-size:12px;color:var(--muted);border-top:1px solid var(--rule);padding-top:6px}
.flowdown{text-align:center;color:var(--accent)}
.heat td.cell{text-align:center;font-family:var(--mono);white-space:nowrap;border:2px solid var(--surface)}
.heat td.cell small{display:block;font-size:11px;opacity:.85;margin-bottom:2px}
.grade td.g{text-align:center;font-size:12px;font-weight:700;border:2px solid var(--surface);white-space:nowrap}
.grade tr.sup td:first-child{font-style:italic}
.tl td{font-size:12.5px;vertical-align:top} .tl td ul{padding-left:16px;gap:4px} .tl .pol{font-style:italic;color:var(--muted)}
.tl tfoot td{font-family:var(--mono);font-size:12px;color:var(--muted);background:var(--pale)}
.tl td.dense{background:color-mix(in srgb,var(--h2) 45%,transparent)}
.keyrow{display:flex;flex-wrap:wrap;gap:6px 14px;align-items:center;font-size:12px;color:var(--muted)}
.keyrow i{display:inline-block;width:24px;height:13px;vertical-align:-2px;margin-right:5px;border:1px solid var(--rule)}
/* B visuals */
.vizwrap{overflow-x:auto}
.viz{width:100%;min-width:560px;height:auto;display:block;font-family:var(--sans)}
.viz .grid{stroke:var(--rule);stroke-width:1}
.viz .ref{stroke:var(--ink);stroke-dasharray:4 3;stroke-width:1.2}
.viz .tick{fill:var(--muted);font-size:11px}
.viz .annot{fill:var(--muted);font-size:11.5px;font-style:italic}
.viz .annot-strong{fill:var(--ink);font-size:12px;font-weight:700}
.viz .lab{fill:var(--muted);font-size:12px} .viz .lab-hi{fill:var(--ink);font-size:12px;font-weight:600}
.viz .tag{fill:var(--muted);font-size:11.5px;font-style:italic}
.viz .stem{stroke:var(--cn);stroke-width:2;opacity:.45}
.viz .d19{fill:var(--surface);stroke:var(--cn);stroke-width:2}
.viz .d24{fill:var(--cn);stroke:var(--surface);stroke-width:2}
.viz .val{fill:var(--text);font-size:11.5px;font-family:var(--mono)}
.viz .warnv{fill:var(--ink);font-style:italic}
.viz .split{stroke:var(--ink);stroke-width:1}
.viz .hit{fill:transparent} .viz .row:hover .hit{fill:var(--pale)}
.viz .stem-cn{stroke:var(--cn);stroke-width:2.5;opacity:.5} .viz .stem-jp{stroke:var(--jp);stroke-width:2.5;opacity:.5}
.viz .h-cn{fill:var(--surface);stroke:var(--cn);stroke-width:2} .viz .f-cn{fill:var(--cn);stroke:var(--surface);stroke-width:2}
.viz .h-jp{fill:var(--surface);stroke:var(--jp);stroke-width:2} .viz .f-jp{fill:var(--jp);stroke:var(--surface);stroke-width:2}
.viz .shade{fill:var(--pale)} .viz .lane{stroke:var(--rule)} .viz .axis{stroke:var(--muted)}
.viz .brk{stroke:var(--muted);stroke-width:1.5;fill:none}
.viz .mv{fill:var(--cn);stroke:var(--surface);stroke-width:1.5}
.viz .pol{fill:var(--surface);stroke:var(--muted);stroke-width:1.5}
.viz .callout{fill:var(--ink);font-size:11px;font-weight:600}
.vizkey{display:flex;flex-wrap:wrap;gap:6px 16px;font-size:12px;color:var(--muted);align-items:center}
.vizkey i{display:inline-block;vertical-align:-2px;margin-right:6px}
.k19{width:11px;height:11px;border-radius:50%;border:2px solid var(--cn);background:var(--surface)}
.k24{width:12px;height:12px;border-radius:50%;background:var(--cn)}
.k24g{width:12px;height:12px;border-radius:50%;background:var(--muted)}
.kcn{width:18px;height:10px;background:var(--cn)} .kjp{width:18px;height:10px;background:var(--jp)}
.kmv{width:11px;height:11px;border-radius:50%;background:var(--cn)}
.kpol{width:9px;height:9px;border:1.5px solid var(--muted);transform:rotate(45deg)}
/* harvey */
.harvey{display:grid}
.hr{display:grid;grid-template-columns:24px minmax(0,1fr) repeat(3,86px);align-items:center;gap:8px;padding:9px 0;border-top:1px solid var(--rule)}
.hr > .hb{justify-self:center}
.hh{border-top:0;padding-top:0} .hc{text-align:center;font-size:12.5px;font-weight:700;color:var(--ink)}
.hn{font-family:var(--mono);color:var(--accent);font-size:13px}
.hl b{display:block;font-size:14px;color:var(--ink)} .hl small{display:block;font-size:12px;color:var(--muted)}
.hsup .hl b{font-weight:600;font-style:italic}
.htot{background:var(--pale);font-size:12.5px;color:var(--muted)} .htot .hl{font-size:12.5px;padding-left:2px}
.hc.big{font-family:var(--serif);font-size:22px;color:var(--ink)}
.hdiv{font-size:11px;letter-spacing:.09em;text-transform:uppercase;font-weight:700;color:var(--muted);padding:14px 0 2px}
.hb{display:inline-block;width:20px;height:20px;border-radius:50%;border:2px solid var(--cn);background:transparent}
.hb-s{background:var(--cn)}
.hb-m{background:conic-gradient(var(--cn) 0 50%,transparent 50% 100%)}
.vizkey .hb{width:14px;height:14px}
@media (max-width:560px){.hr{grid-template-columns:20px minmax(0,1fr) repeat(3,52px)}.hc{font-size:11px}}
/* chevrons */
.chev-q,.chev-a{padding:12px 16px;font-family:var(--serif);font-size:16px;line-height:1.4}
.chev-q{background:var(--pale);color:var(--ink)} .chev-a{background:var(--h5);color:var(--h5t)}
.chevs{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:3px}
.chev{padding:14px 22px 14px 28px;display:grid;gap:4px;align-content:start;clip-path:polygon(0 0,calc(100% - 14px) 0,100% 50%,calc(100% - 14px) 100%,0 100%,14px 50%);min-height:118px}
.chev:first-child{clip-path:polygon(0 0,calc(100% - 14px) 0,100% 50%,calc(100% - 14px) 100%,0 100%);padding-left:16px}
.chev:nth-child(1){background:var(--h2);color:var(--h2t)} .chev:nth-child(2){background:var(--h3);color:var(--h3t)}
.chev:nth-child(3){background:var(--h4);color:var(--h4t)} .chev:nth-child(4){background:var(--h5);color:var(--h5t)}
.chev .cp{font-family:var(--mono);font-size:11px;opacity:.85} .chev b{font-family:var(--serif);font-size:17px} .chev .ca{font-size:13px}
@media (max-width:700px){.chevs{grid-template-columns:1fr}.chev,.chev:first-child{clip-path:polygon(0 0,100% 0,100% calc(100% - 10px),50% 100%,0 calc(100% - 10px));padding:12px 16px 20px;min-height:0}}
/* failure cards */
.fms{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:10px}
.fm{border:1px solid var(--rule);border-top:4px solid var(--h5);padding:12px 14px;display:grid;gap:6px;align-content:start;background:var(--surface)}
.fl{font-family:var(--mono);font-size:11px;color:var(--accent)}
.fn{font-size:14.5px;color:var(--ink);line-height:1.3}
.fb{font-family:var(--serif);font-size:30px;color:var(--ink);font-weight:600;line-height:1.1;font-variant-numeric:tabular-nums}
.fc{font-size:12.5px;color:var(--muted);line-height:1.4}
.fw{font-size:12.5px;border-top:1px solid var(--rule);padding-top:6px} .fw em{font-style:normal;font-size:10.5px;letter-spacing:.08em;text-transform:uppercase;font-weight:700;color:var(--muted);display:block}
.fr{display:flex;flex-wrap:wrap;gap:4px}
.rchip{font-size:11px;background:var(--pale);color:var(--ink);padding:2px 7px;border-radius:10px}
.prio{font-family:var(--mono);font-size:12px;font-weight:500;padding:1px 7px;border-radius:3px;white-space:nowrap}
.p1{background:var(--h5);color:var(--h5t)} .p2{background:var(--h3);color:var(--h3t)} .p3{background:var(--h1);color:var(--h1t)}
.names td:first-child{color:var(--muted);text-decoration:line-through}
</style>'''

def pair(n, sub, headline, key, spec):
    a, b = WC[key]
    return f'''<section class="ex" id="{key}">
  <div class="ex-num">Exhibit {n} <span>{sub}</span></div>
  <p class="ex-head">{headline}</p>
  <div class="pair">
    <div class="ver a"><div class="vlab"><span>Version A · table (Step 3)</span><span class="w">{a} words inside</span></div>{P["A"][key]}</div>
    <div class="ver b"><div class="vlab"><span>Version B · visual (new)</span><span class="w">{b} words inside</span></div>{P["B"][key]}</div>
  </div>
  <p class="prose note">{spec}</p>
</section>'''

wc_rows = ''.join(f'<tr><td>Exhibit {n}</td><td class="num">{WC[k][0]}</td><td class="num">{WC[k][1]}</td><td>{how}</td></tr>' for n,k,how in [
 (1,'ex1','Four chevrons in a darkening sequence replace four answer paragraphs'),
 (2,'ex2','Same numbers, but change is shown as length and 50% as a line, sorted so the “12 above half” finding is visible without reading'),
 (3,'ex3','Filled, half and empty dots replace word labels; one short fact per row'),
 (4,'ex4','Dots on a time axis replace 33 bullet sentences; full text moves to hover and the chapter'),
 (5,'ex5','China and Japan as two coloured dumbbells per market replace four columns of sentences'),
 (6,'ex6','One number per card replaces the evidence column; readers become chips'),
])

body = f'''<div class="wrap">
<header class="top">
  <div class="eyebrow">Step 3 · Exhibits, visual versions · 29 September 2026</div>
  <h1>The China Playbook: exhibit redesign</h1>
  <p class="lede">The six Step 3 exhibits in paper order, each shown next to a new visual version. Version A is kept unchanged except for the failure-mode names. At the end, a list of further exhibits to build next.</p>
  <div class="meta"><span>Side by side on wide screens, stacked on narrow ones</span><span>Hover a dot or row in Version B for the full detail</span></div>
</header>

<nav class="toc" aria-label="Sections">
  <a href="#density">Do they reduce density?</a><a href="#names">New failure-mode names</a><a href="#ex1">1</a><a href="#ex2">2</a><a href="#ex3">3</a><a href="#ex4">4</a><a href="#ex5">5</a><a href="#ex6">6</a><a href="#more">More exhibits to build</a>
</nav>

<section id="density">
  <h2>Do these exhibits reduce content density?</h2>
  <div class="prose" style="display:grid;gap:10px">
    <p>Only partly. The Version A exhibits cut about 1,450 words from the body, but mostly by moving sentences into table cells. The reader still has to read them, so the page gets no lighter. Four of the six are tables of sentences, and only Exhibit 2 shows numbers as colour rather than text.</p>
    <p>Version B works differently. Each exhibit carries one message that should be readable in about five seconds. Numbers become position, length or fill; text shrinks to labels; and the detail moves into the note line, the hover text, or the chapter prose. Inside the exhibits, words fall by about 60% overall.</p>
  </div>
  <div class="tw" style="max-width:900px"><table>
    <thead><tr><th>Exhibit</th><th class="num">A: words</th><th class="num">B: words</th><th>What carries the message in B</th></tr></thead>
    <tbody>{wc_rows}</tbody>
  </table></div>
  <p class="src">Words counted inside each exhibit, excluding source and note lines and hover text.</p>
</section>

<section id="names">
  <h2>Failure-mode names, rewritten</h2>
  <p class="prose">Each name is now a plain statement of what happens. Applied to both versions of Exhibit 6.</p>
  <div class="tw" style="max-width:720px"><table class="names">
    <thead><tr><th>Before</th><th>After</th></tr></thead>
    <tbody>
      <tr><td>Uptime ceiling</td><td>Buyers return where uptime matters</td></tr>
      <tr><td>Installed-base hold</td><td>A loyal installed base holds</td></tr>
      <tr><td>Trade-remedy trigger</td><td>High share invites trade cases</td></tr>
      <tr><td>Acquisition overreach</td><td>Overseas acquisitions lose money</td></tr>
      <tr><td>Channel outrun</td><td>Dealer networks outgrow parts supply</td></tr>
      <tr><td>Home price war</td><td>Price wars at home drain cash</td></tr>
    </tbody>
  </table></div>
</section>

{pair(1,"About this paper · flow exhibit","The paper answers one question in four parts","ex1","Version B would suit a single printed page, as P16 and P10 open theirs. It depends on the Chapter 3 verdict (Step 4).")}
{pair(2,"Part I · Chapter 2","China's share of imports rose in 18 of 19 country–category pairs and now exceeds half in 12","ex2","Version B sorts all 19 pairs by 2024 share, so the reader sees the 12 above the 50% line and the single fall (Indian pumps) without reading a number.")}
{pair(3,"Opening of Part II · flow exhibit","India and Indonesia show all six learnings; Thailand shows mainly plants and electrification","ex3","Headline corrected from Step 3: India and Indonesia each have four Strong and two Moderate grades across the six learnings, so Indonesia does not show more of the playbook than India. It leads only once the two supporting moves are counted.")}
{pair(4,"Part II · closing","Plants and lender partnerships came first; owned finance, remanufacturing and electric plants arrived in 2025–26","ex4","Version B uses a compressed time axis so the 2025–26 cluster stands out. For print, the five callouts carry the story and the chapter text carries the detail.")}
{pair(5,"Part III · opening","The same playbook produced five different outcomes","ex5","Version B narrows the message to one category every market has data for, excavators, and lets China against Japan show the split: China leads in three markets, Japan in two. The lessons move to the country tags.")}
{pair(6,"Part IV · Chapter 13","Each way the playbook breaks has an early-warning sign and a reader who can act","ex6","Version B puts one number on each card. The full evidence stays in Chapter 13's text, and the reader chips link to the Chapter 14 action matrix.")}

<section id="more">
  <h2>More exhibits to build next</h2>
  <p class="prose">Not built yet. Each is listed with the form I would use in the Version B style. Most use data already in the draft. Adding all 17 would bring the paper to 23 exhibits, or 24 with the partner grid below, just under the house range of 25–30.</p>
  <div class="tw"><table>
    <thead><tr><th>Priority</th><th>Chapter</th><th>Exhibit</th><th>Form</th><th>Message it carries</th><th>Data</th></tr></thead>
    <tbody>
      <tr><td><span class="prio p1">1</span></td><td>14</td><td>Actions by reader and horizon</td><td>Grid: six readers × three horizons, one verb phrase per cell, learning numbers as small tags</td><td>Every reader has a first move in the next 12 months</td><td>Step 7 rewrite</td></tr>
      <tr><td><span class="prio p1">1</span></td><td>3</td><td>Structural test scorecard</td><td>Five tests × India, Indonesia, Thailand as pass, partial or fail marks, verdict row at the foot</td><td>The shift passes the first three tests in both main markets</td><td>Chapter 3</td></tr>
      <tr><td><span class="prio p1">1</span></td><td>2 or 3</td><td>Komatsu inside a growing Indonesian market, 2020–2025</td><td>Stacked bars in units: Komatsu and the rest of the implied market</td><td>The market grew by about a third from 2023 to 2025 while Komatsu's units fell</td><td>Refs 15–17, 78–80</td></tr>
      <tr><td><span class="prio p1">1</span></td><td>1</td><td>China's excavator sales at home and abroad, 2019–H1 2026</td><td>Two lines crossing in 2023</td><td>Exports overtook domestic sales as the home market collapsed</td><td>Refs 49–53</td></tr>
      <tr><td><span class="prio p1">1</span></td><td>7</td><td>Chinese plants and service bases</td><td>Locator map of India, Indonesia and Thailand, sites dated and sized by type</td><td>Ten sites, five of them new since November 2025</td><td>Chapter 7</td></tr>
      <tr><td><span class="prio p1">1</span></td><td>6</td><td>Asking prices for 20–22 t excavators by brand</td><td>Range bars, India and Indonesia as two panels</td><td>Chinese price ranges overlap incumbents'; there is no separate cheap band</td><td>Refs 112–117</td></tr>
      <tr><td><span class="prio p1">1</span></td><td>15</td><td>Signposts to 2030</td><td>Eight tiles: current value, threshold, red-amber-green status, review date</td><td>What to watch, and when to worry</td><td>Step 7 rewrite</td></tr>
      <tr><td><span class="prio p2">2</span></td><td>1</td><td>Overseas share of revenue, six Chinese OEMs, 2025</td><td>Sorted bars with a 50% line</td><td>The leaders are now majority-overseas businesses</td><td>Refs 1–6, 36, 47</td></tr>
      <tr><td><span class="prio p2">2</span></td><td>5</td><td>SANY's finance ladder in Indonesia, 2017–2026</td><td>Four-step staircase: partner, product, several lenders, own licence</td><td>Credit moved from partnership to ownership in nine years</td><td>Refs 103–106, 23</td></tr>
      <tr><td><span class="prio p2">2</span></td><td>6</td><td>United Tractors revenue, H1 2026</td><td>Two bars: machines −28%, parts and service +1%</td><td>An installed base keeps earning in a downturn</td><td>Ref 89</td></tr>
      <tr><td><span class="prio p2">2</span></td><td>8</td><td>Local-content scores in Indonesia's public e-catalogue</td><td>Bars against a 40% threshold line</td><td>Komatsu qualifies for public tenders; Chinese brands show no score yet</td><td>Ref 117</td></tr>
      <tr><td><span class="prio p2">2</span></td><td>10</td><td>India crane case in four panels</td><td>Small multiples: Chinese imports, Indian share index, loss per unit, inventories</td><td>A 0–10% price gap was enough to take the market</td><td>Ref 14</td></tr>
      <tr><td><span class="prio p2">2</span></td><td>10</td><td>India FY26 equipment registrations by brand</td><td>Waffle chart: JCB 34,632 of 71,227; LiuGong 1,061</td><td>Chinese brands have barely entered India's largest, wheeled segment</td><td>Ref 140</td></tr>
      <tr><td><span class="prio p2">2</span></td><td>12</td><td>Thailand: China against Japan in five categories</td><td>Slope chart, 2019 to 2024</td><td>China won four categories and lost excavators</td><td>Refs 12, 38, 39, 68, 69</td></tr>
      <tr><td><span class="prio p3">3</span></td><td>9</td><td>Lithium-ion pack prices by region, 2025</td><td>Benchmark bars with China highlighted</td><td>Battery cost is the Chinese makers' largest edge in electric equipment</td><td>Ref 132</td></tr>
      <tr><td><span class="prio p3">3</span></td><td>1</td><td>The 2026 policy calendar</td><td>Month strip of nine events, marked as opening or protecting</td><td>Rules reset in the same months Chinese firms moved in</td><td>Refs 34, 57–67</td></tr>
      <tr><td><span class="prio p3">3</span></td><td>11</td><td>Service footprint in Indonesia</td><td>Icon counts: United Tractors, SANY's distributor, XCMG's dealer</td><td>Chinese networks are wide but not yet as deep</td><td>Refs 92, 118, 139</td></tr>
    </tbody>
  </table></div>
  <p class="src">The dealer and JV-partner diligence grid from the benchmark (supplement §5.5) would be the 24th; it is a table by nature and belongs with Chapter 14.</p>
</section>
</div>'''

open('/home/claude/china-playbook-step3-exhibits-v2.html','w').write('<title>China Playbook Exhibit Redesign</title>\n'+head+css+body)
print('ok')
