const { chromium } = require('playwright');
(async()=>{
 const b=await chromium.launch(); const p=await b.newPage({viewport:{width:1100,height:1000},deviceScaleFactor:2});
 await p.goto('file:///home/claude/pub/index.html');
 await p.evaluate(()=>document.querySelectorAll('img').forEach(i=>i.loading='eager'));
 await p.waitForTimeout(3000);
 const jobs=await p.evaluate(()=>{const out=[];
   document.querySelectorAll('section.ex').forEach(s=>{const id=s.id;const fr=s.querySelectorAll(':scope > .frame');
     if(id.startsWith('x')){ const n=id.slice(1).padStart(2,'0'); if(fr[0]) out.push([id,0,'built-'+n]); if(fr[1]) out.push([id,1,'built-'+n+'-table-version']); }
     else if(id.startsWith('pk-')){ out.push([id,0,'pack-'+id.slice(3)]); }
   });return out;});
 for(const [id,i,name] of jobs){
   const el=(await p.$$('#'+id+' > .frame'))[i];
   await el.screenshot({path:'/home/claude/kit/exhibit-images/'+name+'.png'});
 }
 console.log(jobs.length);
 await b.close();})();
