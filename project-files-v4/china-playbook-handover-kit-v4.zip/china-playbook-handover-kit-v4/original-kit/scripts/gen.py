import json, re, html
F = json.load(open('/home/claude/build/frames.json'))

# ---------- names ----------
OLD_NEW = [
 ("Uptime ceiling", "Buyers return where uptime matters"),
 ("Installed-base hold", "A loyal installed base holds"),
 ("Trade-remedy trigger", "High share invites trade cases"),
 ("Acquisition overreach", "Overseas acquisitions lose money"),
 ("Channel outrun", "Dealer networks outgrow parts supply"),
 ("Home price war", "Price wars at home drain cash"),
]
for o, n in OLD_NEW:
    F['ex6'] = F['ex6'].replace('<b>%s</b>' % o, '<b>%s</b>' % n)

def esc(t): return html.escape(t, quote=True)

# ---------- Ex2B: sorted dumbbell ----------
pairs = [
 ("India","Excavators",7.7,33.9),("India","Forklifts",32.5,67.6),("India","Cranes",35.4,92.7),("India","Compressors",44.0,52.6),("India","Pumps",35.5,34.3),
 ("Indonesia","Excavators",33.1,74.5),("Indonesia","Forklifts",52.7,68.9),("Indonesia","Cranes",60.5,80.2),("Indonesia","Compressors",34.3,45.9),("Indonesia","Pumps",41.3,46.5),
 ("Thailand","Excavators",34.5,35.9),("Thailand","Forklifts",38.6,70.5),("Thailand","Cranes",16.0,53.8),("Thailand","Compressors",20.9,37.1),("Thailand","Pumps",33.3,53.4),
 ("Malaysia","Excavators",23.2,50.1),("Malaysia","Forklifts",31.8,64.8),
 ("Vietnam","Excavators",5.0,20.8),("Vietnam","Forklifts",34.6,52.1),
]
pairs.sort(key=lambda r: -r[3])
W, L, R = 660, 190, 610
top, rh = 34, 22
H = top + rh*len(pairs) + 34
def x(v): return L + (R-L)*v/100
g = []
g.append(f'<svg class="viz" viewBox="0 0 {W} {H}" role="img" aria-label="Dumbbell chart of China\'s share of import value for 19 country and category pairs, 2019 and 2024, sorted by 2024 share. 18 of 19 rose; 12 are above half.">')
# grid
for v in (0,25,50,75,100):
    cls = 'ref' if v == 50 else 'grid'
    g.append(f'<line class="{cls}" x1="{x(v):.1f}" x2="{x(v):.1f}" y1="{top-8}" y2="{H-26}"/>')
    g.append(f'<text class="tick" x="{x(v):.1f}" y="{H-10}" text-anchor="middle">{v}%</text>')
g.append(f'<text class="annot" x="{x(50)+6:.1f}" y="{top-14}">Half of imports</text>')
above = sum(1 for p in pairs if p[3] >= 50)
for i,(c,cat,a,b) in enumerate(pairs):
    y = top + rh*i + rh/2
    hi = b >= 50
    yr = "2019→2023" if c == "Vietnam" else "2019→2024"
    g.append(f'<g class="row"><title>{c}, {cat.lower()}: {a}% → {b}% ({yr})</title>')
    g.append(f'<rect class="hit" x="0" y="{y-rh/2:.1f}" width="{W}" height="{rh}"/>')
    lab = f'{c} · {cat.lower()}' + (' (2023)' if c == 'Vietnam' else '')
    g.append(f'<text class="{"lab-hi" if hi else "lab"}" x="{L-12}" y="{y+4:.1f}" text-anchor="end">{esc(lab)}</text>')
    g.append(f'<line class="stem" x1="{x(a):.1f}" x2="{x(b):.1f}" y1="{y:.1f}" y2="{y:.1f}"/>')
    g.append(f'<circle class="d19" cx="{x(a):.1f}" cy="{y:.1f}" r="4.5"/>')
    g.append(f'<circle class="d24" cx="{x(b):.1f}" cy="{y:.1f}" r="5.5"/>')
    if b >= a:
        g.append(f'<text class="val" x="{x(b)+10:.1f}" y="{y+4:.1f}">{b:.1f}</text>')
    else:
        g.append(f'<text class="val warnv" x="{x(a)+12:.1f}" y="{y+4:.1f}">{b:.1f}, fell</text>')
    g.append('</g>')
    if i == above - 1:
        yy = top + rh*(i+1)
        g.append(f'<line class="split" x1="8" x2="{W-8}" y1="{yy}" y2="{yy}"/>')
        g.append(f'<text class="annot-strong" x="{W-8}" y="{yy-5}" text-anchor="end">↑ {above} pairs above half</text>')
g.append('</svg>')
EX2B = f'''<div class="frame">
  <p class="ex-title">China's share of import value, 2019 and 2024, 19 country–category pairs (%)</p>
  <div class="vizkey"><span><i class="k19"></i>2019</span><span><i class="k24"></i>2024 (Vietnam 2023)</span></div>
  <div class="vizwrap">{''.join(g)}</div>
  <div class="ex-src"><span>Source: UN Comtrade via World Bank WITS, accessed 27 September 2026; YCP analysis.</span><span>Note: As Version A. Cranes, compressors and pumps not analysed for Malaysia and Vietnam.</span></div>
</div>'''

# ---------- Ex5B: China vs Japan excavators ----------
mk = [
 ("Indonesia","Every move visible", 33.1,74.5, 23.9,6.7, False),
 ("India","Playbook meets pushback", 7.7,33.9, 36.1,23.7, False),
 ("Malaysia","On Indonesia's path", 23.2,50.1, 18.9,17.4, False),
 ("Thailand","Depends on category", 34.5,35.9, 39.8,50.8, False),
 ("Vietnam","Faster than its data show", 5.0,20.8, 41.7,50.5, True),
]
W5, L5, R5 = 660, 200, 600
top5, blk = 30, 58
H5 = top5 + blk*len(mk) + 40
def x5(v): return L5 + (R5-L5)*v/80
g = [f'<svg class="viz" viewBox="0 0 {W5} {H5}" role="img" aria-label="China versus Japan share of excavator imports in five markets, 2019 and latest year. China leads in Indonesia, India and Malaysia; Japan leads in Thailand and Vietnam.">']
for v in (0,20,40,60,80):
    g.append(f'<line class="grid" x1="{x5(v):.1f}" x2="{x5(v):.1f}" y1="{top5-6}" y2="{H5-30}"/>')
    g.append(f'<text class="tick" x="{x5(v):.1f}" y="{H5-12}" text-anchor="middle">{v}%</text>')
for i,(c,tag,ca,cb,ja,jb,vn) in enumerate(mk):
    y0 = top5 + blk*i
    yc, yj = y0+16, y0+36
    yr = "2019→2023" if vn else "2019→2024"
    g.append(f'<text class="lab-hi" x="12" y="{y0+22}">{c}</text>')
    g.append(f'<text class="tag" x="12" y="{y0+39}">{esc(tag)}</text>')
    for (a,b,yy,cls,nm) in ((ca,cb,yc,'cn','China'),(ja,jb,yj,'jp','Japan')):
        g.append(f'<g class="row"><title>{c}: {nm} {a}% → {b}% ({yr})</title>')
        g.append(f'<line class="stem-{cls}" x1="{x5(a):.1f}" x2="{x5(b):.1f}" y1="{yy}" y2="{yy}"/>')
        g.append(f'<circle class="h-{cls}" cx="{x5(a):.1f}" cy="{yy}" r="4.5"/>')
        g.append(f'<circle class="f-{cls}" cx="{x5(b):.1f}" cy="{yy}" r="5.5"/>')
        tx = x5(max(a,b)) + 10
        g.append(f'<text class="val" x="{tx:.1f}" y="{yy+4}">{nm} {b:.1f}</text>')
        g.append('</g>')
    if i == 2:
        yy = y0 + blk
        g.append(f'<line class="split" x1="8" x2="{W5-8}" y1="{yy-4}" y2="{yy-4}"/>')
g.append(f'<text class="annot" x="{W5-8}" y="{top5-12}" text-anchor="end">China leads ↓</text>')
g.append(f'<text class="annot" x="{W5-8}" y="{top5+blk*3+12}" text-anchor="end">Japan leads ↓</text>')
g.append('</svg>')
EX5B = f'''<div class="frame">
  <p class="ex-title">Share of excavator imports supplied by China and Japan, five markets, 2019 and 2024 (%)</p>
  <div class="vizkey"><span><i class="kcn"></i>China</span><span><i class="kjp"></i>Japan</span><span><i class="k19"></i>hollow = 2019</span><span><i class="k24g"></i>filled = 2024 (Vietnam 2023)</span></div>
  <div class="vizwrap">{''.join(g)}</div>
  <div class="ex-src"><span>Source: UN Comtrade via World Bank WITS (HS 842952), accessed 27 September 2026; YCP analysis.</span><span>Note: Exporters' 2024 figures suggest China shipped more excavators to Vietnam than Japan did; Vietnam's own 2024 data are not yet reported. Excavators are used as the one category available for all five markets.</span></div>
</div>'''

# ---------- Ex4B: swimlane timeline ----------
lanes = ["Beachhead","Credit","Pricing and lifecycle","Plants","Rules","Electrification"]
# (lane, year-fraction, text, kind)  kind: m=counted move, p=policy
ev = [
 (0,2016.79,"SANY takes 52% of India's long-reach excavator niche (announced Oct 2016)","m"),
 (0,2021.5,"Chinese competition for Indonesian nickel-site fleets from 2021","m"),
 (0,2024.2,"Chinese crane imports into India reach 938 units a year (FY24)","m"),
 (0,2025.5,"SANY India claims 55% of cranes and 60% of piling rigs (2025)","m"),
 (0,2026.7,"SANY India reports about 42 dealers (Sep 2026)","m"),
 (1,2017.96,"SANY's Indonesian distributor signs with MNC Leasing (Dec 2017)","m"),
 (1,2018.96,"Low-down-payment financing launched (Dec 2018)","m"),
 (1,2024.25,"Related-party credit of up to three years found in India (2023–24)","m"),
 (1,2025.73,"SANY RMB1.45bn customer-finance agreement (Sep 2025)","m"),
 (1,2026.69,"XCMG and dealer launch ABC Multifinance (9 Sep 2026)","m"),
 (1,2026.71,"OJK licenses PT Sany Indonesia Finance (14 Sep 2026)","m"),
 (2,2021.55,"SANY cuts Indonesian prices by about 20% (reported Jul 2021)","m"),
 (2,2024.3,"Chinese cranes undercut Indian prices by 0–10% (2023–24)","m"),
 (2,2025.5,"XCMG aftermarket revenue up 33% (H1 2025)","m"),
 (2,2026.72,"XCMG breaks ground on remanufacturing base, Balikpapan (16 Sep 2026)","m"),
 (3,2007.5,"SANY opens Chakan, its first plant outside China (2007)","m"),
 (3,2021.5,"XCMG starts manufacturing in Chennai (2021)","m"),
 (3,2023.7,"SANY announces US$150m second phase at Karawang (Sep 2023)","m"),
 (3,2024.35,"Zoomlion opens Khed City plant (May 2024)","m"),
 (3,2025.87,"Heli and Siam Motors Parts break ground in Rayong (Nov 2025)","m"),
 (3,2026.48,"Hangcha opens Chonburi (Jun 2026)","m"),
 (3,2026.52,"LiuGong expands Pithampur (Jul 2026)","m"),
 (3,2026.56,"LiuGong breaks ground in Karawang (Jul 2026)","m"),
 (3,2026.57,"XCMG starts production at Weda Bay (Jul 2026)","m"),
 (4,2020.5,"Policy: India restricts land-border investment and tender bids (2020)","p"),
 (4,2025.79,"Policy: Indonesia's 25% local-content credit for investing (Oct 2025)","p"),
 (4,2026.19,"Policy: India's Press Note 2 (Mar 2026)","p"),
 (4,2026.56,"LiuGong commits to raise local components at Karawang (Jul 2026)","m"),
 (5,2024.95,"China supplies 60–69% of electric-forklift imports in India, Indonesia and Thailand (2024)","m"),
 (5,2025.95,"70% of Heli's unit sales are electric (2025)","m"),
 (5,2026.7,"SANY India launches an electric excavator and loader (dated by source, Sep 2026)","m"),
]
assert sum(1 for e in ev if e[3]=='m') == 28
W4, L4, R4 = 780, 150, 760
top4, lh = 50, 54
H4 = top4 + lh*len(lanes) + 34
segs = [(2007.0,2020.0,0.18),(2020.0,2025.0,0.30),(2025.0,2026.84,0.52)]
def x4(t):
    pos = L4
    for a,b,w in segs:
        span = (R4-L4)*w
        if t < b:
            return pos + span*(t-a)/(b-a)
        pos += span
    return R4
g = [f'<svg class="viz" viewBox="0 0 {W4} {H4}" role="img" aria-label="Swimlane timeline of 28 dated moves by Chinese OEMs from 2007 to September 2026 across six learnings; 15 of them fall in 2025 to September 2026.">']
x25 = x4(2025.0)
g.append(f'<rect class="shade" x="{x25:.1f}" y="{top4-10}" width="{R4-x25:.1f}" height="{lh*len(lanes)+10}"/>')
g.append(f'<text class="annot-strong" x="{x25+8:.1f}" y="{top4-18}">2025 to Sep 2026: 15 of 28 moves</text>')
g.append(f'<text class="annot" x="{L4:.1f}" y="{top4-18}">2007–2019: 4</text>')
g.append(f'<text class="annot" x="{x4(2020.0)+6:.1f}" y="{top4-18}">2020–2024: 9</text>')
for i,ln in enumerate(lanes):
    y = top4 + lh*i + lh/2
    g.append(f'<line class="lane" x1="{L4}" x2="{R4}" y1="{y}" y2="{y}"/>')
    g.append(f'<text class="lab-hi" x="{L4-12}" y="{y+4}" text-anchor="end">{i+1} {esc(ln)}</text>')
# break marks
for bx in (x4(2020.0), x25):
    yb = H4-30
    g.append(f'<path class="brk" d="M{bx-5:.1f},{yb+6} l6,-12 M{bx+1:.1f},{yb+6} l6,-12"/>')
ticks = [(2007.0,"2007"),(2013.0,"2013"),(2020.0,"2020"),(2022.0,"2022"),(2024.0,"2024"),(2025.0,"2025"),(2026.0,"2026"),(2026.5,"Jul")]
g.append(f'<line class="axis" x1="{L4}" x2="{R4}" y1="{H4-30}" y2="{H4-30}"/>')
for t,lab in ticks:
    g.append(f'<line class="axis" x1="{x4(t):.1f}" x2="{x4(t):.1f}" y1="{H4-30}" y2="{H4-25}"/>')
    g.append(f'<text class="tick" x="{x4(t):.1f}" y="{H4-12}" text-anchor="middle">{lab}</text>')
placed = {}
for (ln,t,txt,k) in ev:
    cx = x4(t); cy = top4 + lh*ln + lh/2
    prev = placed.setdefault(ln, [])
    n = sum(1 for p in prev if abs(p-cx) < 11)
    offs = [0,-9,9,-18,18]
    cy2 = cy + offs[min(n,4)]
    prev.append(cx)
    g.append(f'<g class="row"><title>{esc(txt)}</title>')
    if k == 'p':
        g.append(f'<rect class="pol" x="{cx-5:.1f}" y="{cy2-5:.1f}" width="10" height="10" transform="rotate(45 {cx:.1f} {cy2:.1f})"/>')
    else:
        g.append(f'<circle class="mv" cx="{cx:.1f}" cy="{cy2:.1f}" r="5.5"/>')
    g.append('</g>')
# annotations
def note(ln, t, text, dy=-14, anchor="start", dx=8):
    cx = x4(t); cy = top4 + lh*ln + lh/2
    g.append(f'<text class="callout" x="{cx+dx:.1f}" y="{cy+dy:.1f}" text-anchor="{anchor}">{esc(text)}</text>')
note(3,2007.5,"SANY's first plant abroad",-15)
note(1,2017.96,"First lender tie-up",-17,"start",-6)
note(1,2026.71,"Own finance licence",-15,"end",-10)
note(2,2026.72,"Remanufacturing base",-15,"end",-10)
note(3,2026.5,"4 plant moves in Jun–Jul",-24,"end",-14)
g.append('</svg>')
EX4B = f'''<div class="frame">
  <p class="ex-title">Dated moves by Chinese OEMs in India, Indonesia and Thailand, by learning, 2007–September 2026</p>
  <div class="vizkey"><span><i class="kmv"></i>Company move (28)</span><span><i class="kpol"></i>Policy change (context, not counted)</span><span>Time axis compressed before 2025</span></div>
  <div class="vizwrap">{''.join(g)}</div>
  <div class="ex-src"><span>Source: company releases and filings, DGTR, OJK and media as cited in Chapters 4–9; YCP analysis.</span><span>Note: Positions are announcement or ground-breaking dates; annual figures sit at year-end. The axis gives 2025–26 half the width, so the density is real but its spacing is stretched.</span></div>
</div>'''

# ---------- Ex3B: Harvey dots ----------
rows3 = [
 ("1","Beachhead", ["s","s","m"], "SANY India: 52% of a niche in about 18 months"),
 ("2","Customer credit", ["s","s","w"], "Up to 3 years' related-party credit; own finance licence"),
 ("3","Price and lifecycle", ["s","m","w"], "Cranes undercut by only 0–10%"),
 ("4","Local plants", ["m","s","s"], "5 new plants and bases since Nov 2025"),
 ("5","Local rules", ["s","s","m"], "25% local-content credit; 60-day decision"),
 ("6","Electrification", ["m","m","s"], "60–69% of electric-forklift imports"),
]
sup3 = [
 ("","Follow home customers", ["w","s","s"], "Chinese investors 17% of Thai industrial estates"),
 ("","Mixed dealer channels", ["w","s","m"], "SANY India: dealer and company-owned outlets"),
]
word = {"s":"Strong","m":"Moderate","w":"Weak"}
cty = ["India","Indonesia","Thailand"]
def dotrow(r, sup=False):
    n,lab,gr,fact = r
    cells = ''.join(f'<span class="hb hb-{v}" role="img" aria-label="{c}: {word[v]}" title="{c}: {word[v]}"></span>' for v,c in zip(gr,cty))
    num = f'<span class="hn">{n}</span>' if n else '<span class="hn"></span>'
    return f'<div class="hr{" hsup" if sup else ""}">{num}<span class="hl"><b>{esc(lab)}</b><small>{esc(fact)}</small></span>{cells}</div>'
tot = [sum(1 for r in rows3 if r[2][j]=='s') for j in range(3)]
EX3B = f'''<div class="frame">
  <p class="ex-title">Strength of public evidence for each learning, by country, 2019–2026</p>
  <div class="harvey">
    <div class="hr hh"><span class="hn"></span><span class="hl"></span>{''.join(f'<span class="hc">{c}</span>' for c in cty)}</div>
    {''.join(dotrow(r) for r in rows3)}
    <div class="hr htot"><span class="hn"></span><span class="hl">Strong, of six learnings</span>{''.join(f'<span class="hc big">{t}</span>' for t in tot)}</div>
    <div class="hdiv">Supporting moves</div>
    {''.join(dotrow(r, True) for r in sup3)}
  </div>
  <div class="vizkey"><span><i class="hb hb-s"></i>Strong</span><span><i class="hb hb-m"></i>Moderate</span><span><i class="hb hb-w"></i>Weak</span></div>
  <div class="ex-src"><span>Source: references as cited in Chapters 4–9; YCP analysis.</span><span>Note: Grades rate the public evidence, not the size of the effect; criteria as Version A.</span></div>
</div>'''

# ---------- Ex1B: chevrons ----------
EX1B = '''<div class="frame">
  <p class="ex-title">Structure of the argument, by part and chapter</p>
  <div class="chev-q"><span class="lbl">Question</span>Which moves can be copied, by whom, and how fast?</div>
  <div class="chevs">
    <div class="chev"><span class="cp">Part I · Ch 1–3</span><b>The shift</b><span class="ca">Real, and mostly structural</span></div>
    <div class="chev"><span class="cp">Part II · Ch 4–9</span><b>The playbook</b><span class="ca">Six moves any firm can copy</span></div>
    <div class="chev"><span class="cp">Part III · Ch 10–12</span><b>Markets</b><span class="ca">Five different outcomes</span></div>
    <div class="chev"><span class="cp">Part IV · Ch 13–15</span><b>Limits and actions</b><span class="ca">Where it breaks; who acts</span></div>
  </div>
  <div class="chev-a"><span class="lbl">Answer</span>Most moves, by almost any firm; fastest by incumbents with finance arms, installed bases and local plants.</div>
  <div class="ex-src"><span>Source: YCP analysis.</span></div>
</div>'''

# ---------- Ex6B: cards ----------
cards = [
 ("Buyers return where uptime matters","Learning 3","20% → 35%","Tata Hitachi's mining-excavator share, recovering after Chinese entry","Incumbent share rising in mining segments",["Global incumbents","Financiers"]),
 ("A loyal installed base holds","Learning 1","50.8%","Japan's share of Thai excavator imports in 2024, up from 39.8%","Chinese share flat while nearby categories rise",["Global incumbents","Dealers"]),
 ("High share invites trade cases","Learnings 2, 3","18.8–40.1%","UK anti-dumping duties on Chinese excavators, in force to 2030","Near-total import share and local producers exiting",["Chinese OEMs","Policymakers"]),
 ("Overseas acquisitions lose money","Learning 4","RMB497m","Efort's 2025 loss, after an impairment on its overseas business","Impairments on acquired overseas units",["Chinese OEMs","Indian and ASEAN champions"]),
 ("Dealer networks outgrow parts supply","Learnings 1, 2","10 months","Longest parts wait reported by Neta's Thai customers","Dealer count rising faster than parts depots",["Dealers","Financiers","Chinese OEMs"]),
 ("Price wars at home drain cash","All learnings","−6.5 pts","Fall in Efort's robot gross margin in 2025","Falling margins at the parent company",["Financiers","Chinese OEMs"]),
]
cc = []
for nm,lnk,big,cap,watch,rd in cards:
    chips = ''.join(f'<span class="rchip">{esc(r)}</span>' for r in rd)
    cc.append(f'<div class="fm"><span class="fl">{esc(lnk)}</span><b class="fn">{esc(nm)}</b><span class="fb">{esc(big)}</span><span class="fc">{esc(cap)}</span><span class="fw"><em>Watch for</em> {esc(watch)}</span><span class="fr">{chips}</span></div>')
EX6B = f'''<div class="frame">
  <p class="ex-title">Six ways the Chinese playbook breaks: one number, one warning sign and the readers who can act, 2019–2026</p>
  <div class="fms">{''.join(cc)}</div>
  <div class="ex-src"><span>Source: Tata Hitachi via Business Standard [42]; WITS [38]; UK Trade Remedies Authority [43]; Efort filings and press [44, 45]; Bangkok Post [46]; YCP analysis.</span><span>Note: Neta is a car maker, included for its lesson about dealer networks.</span></div>
</div>'''

json.dump({"A":F,"B":{"ex1":EX1B,"ex2":EX2B,"ex3":EX3B,"ex4":EX4B,"ex5":EX5B,"ex6":EX6B}}, open('/home/claude/build/parts.json','w'))

def words(h):
    h = re.sub(r'<div class="ex-src">.*?</div>','',h,flags=re.S)
    h = re.sub(r'<title>.*?</title>','',h,flags=re.S)
    h = re.sub(r'<[^>]+>',' ',h)
    return len(html.unescape(h).split())
wc = {k:(words(F[k]), words(v)) for k,v in {"ex1":EX1B,"ex2":EX2B,"ex3":EX3B,"ex4":EX4B,"ex5":EX5B,"ex6":EX6B}.items()}
json.dump(wc, open('/home/claude/build/wc.json','w'))
print(wc)
