import json, re, html
E = lambda t: html.escape(str(t), quote=True)
X = json.load(open('/home/claude/build/all.json'))
PK = json.load(open('/home/claude/upl/pack.json'))
META = json.load(open('/home/claude/chooser/meta.json'))
built = {str(x[0]): x for x in X}
pk = {}
for it in PK:
    m = re.match(r'^(Exhibit ([0-9A-Z]+b?)|Part (I|II|III|IV) (flow|at a glance))\.', it['cap'])
    key = m.group(2) if m.group(2) else f"P{m.group(3)} {m.group(4)}"
    pk[re.sub(r'[^A-Za-z0-9]', '', key)] = (key, it)

def opt(oid):
    if oid[0] == 'b':
        n = oid[1:]; x = built[n]
        six = n in ('1', '6', '10', '17', '19', '25')
        return {'id': oid, 'src': 'built', 'name': f'Built exhibit {n}' + (' · visual' if six else ''), 'sub': x[3]}
    if oid[0] == 't':
        n = oid[1:]; x = built[n]
        return {'id': oid, 'src': 'table', 'name': f'Built exhibit {n} · table version', 'sub': x[3]}
    k = oid[1:]; key, it = pk[k]
    nm = f'Pack exhibit {key}' if not key.startswith('P') or key in ('B1',) else f'Pack · Part {key[1:].split(" ")[0]} {key.split(" ",1)[1]}'
    if key in ('A', 'B', 'B1') or re.match(r'^\d', key): nm = f'Pack exhibit {key}'
    return {'id': oid, 'src': 'pack', 'name': nm, 'sub': it['cap'].split('. ', 1)[1]}

P = [
 ("Front of the paper", "Executive summary", "Beside the list of six learnings", ["pA"], [], "The summary already lists the six learnings, so a table would repeat them. Leave empty unless you want one."),
 ("Front of the paper", "About this paper", "Scope: the four equipment families", ["pB"], ["pB"], "Shows the four equipment families and how far each has gone abroad, in one table."),
 ("Front of the paper", "About this paper", "How the paper is organised", ["b1", "t1", "p1", "p1b"], ["p1"], "Lists every chapter under its Part. Needs two label fixes at assembly: “investment rules” and six reader types."),
 ("Part I · The shift", "Part I opener", "How Part I flows", ["b2", "pPIflow", "pPIataglance"], ["pPIflow"], "Same design as the other three Part flows in your pack, so all four Part openers match."),
 ("Part I · The shift", "Chapter 1", "Exports against home sales", ["b3"], ["b3"], "The only chart of China's home-market collapse and the export crossover in 2023."),
 ("Part I · The shift", "Chapter 1", "Overseas revenue of Chinese OEMs", ["b4", "p2"], ["p2"], "Cleaner chart, and its table carries the revenue figures the text no longer repeats."),
 ("Part I · The shift", "Chapter 1", "The 2026 policy reset", ["b5", "p3"], ["b5"], "Shows at a glance which events opened access and which raised barriers. Pack 3 gives more detail as a table."),
 ("Part I · The shift", "Chapter 2", "China's import share by country and category", ["b6", "t6", "p4"], ["p4"], "Easiest to read: every cell shows the 2024 share and the change since 2019."),
 ("Part I · The shift", "Chapter 2", "Japanese and Korean suppliers", ["p5"], ["p5"], "Compares China and Japan country by country, with Korea and import values in the table."),
 ("Part I · The shift", "Chapter 2", "Indonesian distributor shares", ["b7", "p6"], ["p6"], "Shows Komatsu and Hitachi together, with the implied market size underneath."),
 ("Part I · The shift", "Chapter 2", "Category sequence", ["p7"], ["p7"], "Summarises the sequence the chapter ends on."),
 ("Part I · The shift", "Chapter 3", "The five tests", ["p8"], [], "The verdict scorecard at the next position already lists the tests, so this can be left empty."),
 ("Part I · The shift", "Chapter 3", "Structural or cyclical: verdict", ["b8", "p9"], ["b8"], "Its marks make pass, partial and contestable visible at a glance."),
 ("Part II · The playbook", "Part II opener", "How Part II flows, and how strong the evidence is", ["b9", "pPIIflow", "pPIIataglance", "b10", "t10", "p10"], ["pPIIflow", "b10"], "Pick one flow and one evidence exhibit. The pack flow matches the other Part openers; built 10 shows evidence strength as dots."),
 ("Part II · The playbook", "Chapter 5", "SANY's finance steps in Indonesia", ["b11", "p11"], ["b11"], "The staircase shows the move from lender partner to own licence in four steps."),
 ("Part II · The playbook", "Chapter 6", "Pricing and lifecycle", ["b12", "b13"], ["b12", "b13"], "Two different points: price ranges overlap, and parts and service held up while machine sales fell."),
 ("Part II · The playbook", "Chapter 7", "Chinese plants", ["b14", "p12"], ["b14"], "The map shows where the ten sites are. Pack 12 gives capacities if you prefer a table."),
 ("Part II · The playbook", "Chapter 8", "Local-content scores", ["b15"], ["b15"], "Shows Komatsu above Indonesia's 40% bar and Chinese brands with no score yet."),
 ("Part II · The playbook", "Chapter 9", "Electrification", ["p13", "b16"], ["p13"], "Pack 13 is the core evidence for the learning. Battery prices (built 16) is the easiest exhibit in the set to drop."),
 ("Part II · The playbook", "End of Part II", "Moves over time", ["b17", "t17"], ["b17"], "Shows the 2025–26 cluster of moves that no single chapter can."),
 ("Part III · Markets", "Part III opener", "How Part III flows, and five markets compared", ["b18", "pPIIIflow", "pPIIIataglance", "b19", "t19"], ["pPIIIflow", "b19"], "Pick one flow and one comparison. The pack flow matches the other openers; built 19 compares China and Japan in all five markets."),
 ("Part III · Markets", "Chapter 10", "Where Chinese brands have gained in India", ["b21", "p14"], ["b21"], "Shows how little of India's largest segment Chinese brands hold, which the penetration table cannot."),
 ("Part III · Markets", "Chapter 10", "The crane case", ["b20", "p15"], ["b20"], "Four panels show volume, demand, share and losses together."),
 ("Part III · Markets", "Chapter 11", "Indonesia", ["b22", "p16"], ["b22"], "Supports the chapter's point that the contest has moved to the aftermarket. Pack 16 repeats the chapter's snapshot table."),
 ("Part III · Markets", "Chapter 12", "Thailand", ["b23", "p17"], ["p17"], "One chart shows all five categories and the excavator exception."),
 ("Part IV · Limits and actions", "Part IV opener", "How Part IV flows", ["b24", "pPIVflow", "pPIVataglance"], ["pPIVflow"], "Matches the other openers. Needs two fixes at assembly: six failure modes and six reader types."),
 ("Part IV · Limits and actions", "Chapter 13", "Failure modes", ["b25", "t25", "p18"], ["b25"], "Its six cards match the six failure modes in the rewritten chapter."),
 ("Part IV · Limits and actions", "Chapter 14", "Actions by reader", ["b26", "p19"], ["b26"], "Covers six reader types and three time horizons, as the rewritten chapter does."),
 ("Part IV · Limits and actions", "Chapter 15", "Signposts", ["b27", "p20"], ["b27"], "Adds a threshold and expected timing to each signpost."),
 ("Appendices", "Data appendix", "UN Comtrade values", ["pB1"], ["pB1"], "The raw trade values behind every import-share figure in the paper."),
]
used = [o for p in P for o in p[3]]
assert len(used) == len(set(used)) == 65, (len(used), len(set(used)))
data = []
for i, (grp, where, what, opts, rec, why) in enumerate(P, 1):
    data.append({'n': i, 'grp': grp, 'where': where, 'what': what, 'rec': rec, 'why': why,
                 'opts': [dict(opt(o), tall=META[o]['h']) for o in opts]})

page = '''<title>China Playbook Exhibit Chooser</title>
<style>
:root{--bg:#F8FAFD;--surface:#FFFFFF;--pale:#EAF2FD;--ink:#0D1E43;--text:#1F2A40;--muted:#56627A;--rule:#D5DDEA;--accent:#0B6FD9;
 --built:#0B6FD9;--built-bg:#E3EFFD;--table:#4B5A78;--table-bg:#ECEFF5;--pack:#9A5B00;--pack-bg:#FCEFD6;--ok:#1E7F4F;--ok-bg:#E3F3EA;--sel:#0B6FD9;
 --serif:"Palatino Linotype",Palatino,"Book Antiqua","Source Serif 4",Georgia,serif;--sans:"Segoe UI","Source Sans 3",system-ui,-apple-system,sans-serif;--mono:"IBM Plex Mono",ui-monospace,Menlo,monospace}
@media (prefers-color-scheme: dark){:root:not([data-theme="light"]){color-scheme:dark;--bg:#0B1426;--surface:#111D35;--pale:#13284A;--ink:#E8EEF8;--text:#D3DBE8;--muted:#9AA8C0;--rule:#263552;--accent:#6BB4FF;
 --built:#6BB4FF;--built-bg:#13284A;--table:#B3BED3;--table-bg:#1C2640;--pack:#F2B65A;--pack-bg:#3A2A0E;--ok:#6FD39E;--ok-bg:#12301F;--sel:#6BB4FF}}
:root[data-theme="dark"]{color-scheme:dark;--bg:#0B1426;--surface:#111D35;--pale:#13284A;--ink:#E8EEF8;--text:#D3DBE8;--muted:#9AA8C0;--rule:#263552;--accent:#6BB4FF;
 --built:#6BB4FF;--built-bg:#13284A;--table:#B3BED3;--table-bg:#1C2640;--pack:#F2B65A;--pack-bg:#3A2A0E;--ok:#6FD39E;--ok-bg:#12301F;--sel:#6BB4FF}
*{box-sizing:border-box}
body{background:var(--bg);color:var(--text);font-family:var(--sans);font-size:15px;line-height:1.55;padding-inline:18px;padding-block:0 80px}
.wrap{max-width:1180px;margin:0 auto}
h1,h2,h3{font-family:var(--serif);color:var(--ink);margin:0;text-wrap:balance;font-weight:600}
header.top{padding-block:32px 18px;border-bottom:3px solid var(--ink);display:grid;gap:10px}
h1{font-size:clamp(28px,4vw,38px)}
.lede{max-width:760px;font-size:16.5px;margin:0}
.how{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:12px;padding-top:18px}
.how div{background:var(--surface);border:1px solid var(--rule);padding:12px 14px;border-radius:6px}
.how b{display:block;color:var(--ink);margin-bottom:2px}
.badge{display:inline-block;font-size:11.5px;font-weight:700;letter-spacing:.03em;padding:2px 8px;border-radius:10px;white-space:nowrap}
.src-built{color:var(--built);background:var(--built-bg)} .src-table{color:var(--table);background:var(--table-bg)} .src-pack{color:var(--pack);background:var(--pack-bg)}
.bar{position:sticky;top:env(safe-area-inset-top,0px);z-index:5;background:var(--bg);border-bottom:1px solid var(--rule);padding:10px 0;margin-top:14px;display:flex;flex-wrap:wrap;gap:8px 18px;align-items:center}
.bar .count{font-weight:700;color:var(--ink)}
.bar .tally{display:flex;gap:8px;flex-wrap:wrap}
.status{font-size:13px;color:var(--muted);margin-left:auto}
.status.ok{color:var(--ok)}
button{font:inherit;cursor:pointer}
.btn{border:1px solid var(--rule);background:var(--surface);color:var(--ink);padding:6px 12px;border-radius:5px;font-size:13.5px}
.btn:hover{border-color:var(--accent)}
:focus-visible{outline:2px solid var(--accent);outline-offset:2px}
.grp{font-size:12.5px;letter-spacing:.09em;text-transform:uppercase;font-weight:700;color:var(--muted);padding-top:34px}
.pos{padding-top:18px;display:grid;gap:10px;scroll-margin-top:70px}
.pos-h{display:flex;flex-wrap:wrap;gap:4px 12px;align-items:baseline}
.pos-n{font-family:var(--mono);font-size:13px;color:var(--accent)}
.pos-h h2{font-size:20px}
.pos-w{font-size:13.5px;color:var(--muted)}
.rec{font-size:13.5px;background:var(--pale);padding:8px 12px;border-radius:5px;max-width:900px}
.rec b{color:var(--ink)}
.opts{display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:12px}
.opt{background:var(--surface);border:2px solid var(--rule);border-radius:8px;overflow:hidden;display:grid;grid-template-rows:auto 1fr;transition:border-color .15s}
.opt.on{border-color:var(--sel);box-shadow:0 0 0 2px color-mix(in srgb,var(--sel) 25%,transparent)}
.thumb{display:block;width:100%;border:0;padding:0;background:#fff;position:relative;max-height:260px;overflow:hidden;border-bottom:1px solid var(--rule)}
.thumb img{display:block;width:100%;height:auto}
.thumb .zoom{position:absolute;right:8px;bottom:8px;background:rgba(13,30,67,.85);color:#fff;font-size:12px;padding:3px 8px;border-radius:4px}
.meta{padding:10px 12px;display:grid;gap:6px;align-content:start}
.meta .row{display:flex;gap:6px;flex-wrap:wrap;align-items:center}
.meta .nm{font-weight:700;color:var(--ink);font-size:14px}
.meta .sub{font-size:13px;color:var(--muted);line-height:1.4}
.rtag{font-size:11px;font-weight:700;color:var(--ok);background:var(--ok-bg);padding:2px 7px;border-radius:10px}
.pick{margin-top:4px;border:1.5px solid var(--sel);background:transparent;color:var(--sel);border-radius:5px;padding:6px 10px;font-weight:700;font-size:13.5px;text-align:center}
.opt.on .pick{background:var(--sel);color:#fff}
:root[data-theme="dark"] .opt.on .pick{color:#0B1426}
@media (prefers-color-scheme: dark){:root:not([data-theme="light"]) .opt.on .pick{color:#0B1426}}
.none{font-size:13px;color:var(--muted);font-style:italic}
.lb{position:fixed;inset:0;background:rgba(5,10,20,.82);z-index:20;display:grid;grid-template-rows:auto 1fr;padding:env(safe-area-inset-top,0px) 12px 12px}
.lb[hidden]{display:none}
.lb-bar{display:flex;justify-content:space-between;align-items:center;gap:10px;color:#fff;padding:10px 4px}
.lb-bar span{font-weight:700}
.lb-scroll{overflow:auto;background:#fff;border-radius:6px}
.lb-scroll img{display:block;max-width:100%;margin:0 auto}
.lb .btn{background:#fff;color:#0D1E43}
.summary{margin-top:36px;background:var(--surface);border:1px solid var(--rule);border-radius:8px;padding:16px 18px;display:grid;gap:10px}
.summary pre{white-space:pre-wrap;font-family:var(--mono);font-size:12.5px;background:var(--pale);padding:12px;border-radius:5px;margin:0;max-height:360px;overflow:auto;color:var(--ink)}
@media (prefers-reduced-motion:reduce){.opt{transition:none}}
</style>
<div class="wrap">
<header class="top">
  <h1>Choose the exhibits</h1>
  <p class="lede">The paper has 30 places where an exhibit can go. At each place you will see every option side by side. Pick one or more by pressing <b>Pick</b>, or none. My recommended picks are already selected, so you only need to change the ones you disagree with.</p>
  <div class="how">
    <div><span class="badge src-built">Built here</span><b>Made in this chat</b>Exhibits 1–27, drawn from the draft's figures.</div>
    <div><span class="badge src-table">Built here · table version</span><b>An earlier edition</b>The original table form of six built exhibits (1, 6, 10, 17, 19, 25). Same content as their visual version.</div>
    <div><span class="badge src-pack">Your pack</span><b>From your zip file</b>The 32 exhibits in your exhibit pack: A, B, 1–20, 1b, B1 and eight Part diagrams.</div>
    <div><span class="badge" style="background:var(--pale);color:var(--ink)">At assembly</span><b>What happens next</b>Whatever you pick is renumbered in paper order and redrawn in one colour scheme.</div>
  </div>
</header>
<div class="bar" role="status">
  <span class="count" id="count"></span>
  <span class="tally" id="tally"></span>
  <button class="btn" id="reset" type="button">Reset to my recommendations</button>
  <span class="status" id="status">Loading saved choices…</span>
</div>
<main id="list"></main>
<section class="summary" id="sum">
  <h2>Your choices as text</h2>
  <p class="none" style="font-style:normal">Your picks save automatically and I can read them. If saving is unavailable in your view, copy this and paste it into the chat.</p>
  <pre id="sumtxt"></pre>
  <div><button class="btn" id="copy" type="button">Copy choices</button> <span class="none" id="copied"></span></div>
</section>
</div>
<div class="lb" id="lb" hidden><div class="lb-bar"><span id="lbt"></span><button class="btn" id="lbx" type="button">Close</button></div><div class="lb-scroll"><img id="lbi" alt=""></div></div>
<script>
const DATA = ''' + json.dumps(data, ensure_ascii=False) + ''';
const SRC = {built:["Built here","src-built"], table:["Built here · table version","src-table"], pack:["Your pack","src-pack"]};
const rec = {}; DATA.forEach(p => rec[p.n] = p.rec.slice());
let picks = JSON.parse(JSON.stringify(rec));
let db = null, saveTimer = null;
const $ = s => document.querySelector(s);
function el(t, c, h){ const e=document.createElement(t); if(c) e.className=c; if(h!==undefined) e.textContent=h; return e; }
function render(){
  const list = $('#list'); list.textContent=''; let last=null;
  DATA.forEach(p => {
    if(p.grp!==last){ list.appendChild(el('div','grp',p.grp)); last=p.grp; }
    const s = el('section','pos'); s.id='pos'+p.n;
    const h = el('div','pos-h'); h.appendChild(el('span','pos-n','Position '+p.n)); h.appendChild(el('h2','',p.what)); h.appendChild(el('span','pos-w',p.where));
    s.appendChild(h);
    const r = el('div','rec'); const rb=el('b','', p.rec.length? 'Recommended: ' : 'Recommended: leave empty. '); r.appendChild(rb);
    if(p.rec.length){ r.appendChild(document.createTextNode(p.rec.map(id=>p.opts.find(o=>o.id===id).name).join(' and ')+'. ')); }
    r.appendChild(document.createTextNode(p.why)); s.appendChild(r);
    const g = el('div','opts');
    p.opts.forEach(o => {
      const on = (picks[p.n]||[]).includes(o.id);
      const c = el('div','opt'+(on?' on':'')); c.dataset.id=o.id;
      const tb = el('button','thumb'); tb.type='button'; tb.setAttribute('aria-label','Enlarge '+o.name);
      const im = el('img'); im.src='thumbs/'+o.id+'.jpg'; im.alt=o.name+': '+o.sub; im.loading='lazy'; tb.appendChild(im); tb.appendChild(el('span','zoom','Enlarge'));
      tb.onclick=()=>openLb(o); c.appendChild(tb);
      const m = el('div','meta'); const row=el('div','row'); const b=el('span','badge '+SRC[o.src][1],SRC[o.src][0]); row.appendChild(b);
      if(p.rec.includes(o.id)) row.appendChild(el('span','rtag','Recommended'));
      m.appendChild(row); m.appendChild(el('span','nm',o.name)); m.appendChild(el('span','sub',o.sub));
      const pk = el('button','pick', on?'Picked ✓':'Pick'); pk.type='button'; pk.setAttribute('aria-pressed', on?'true':'false');
      pk.onclick=()=>toggle(p.n,o.id); m.appendChild(pk); c.appendChild(m); g.appendChild(c);
    });
    s.appendChild(g);
    if(!(picks[p.n]||[]).length) s.appendChild(el('p','none','No exhibit will go here.'));
    list.appendChild(s);
  });
  tally();
}
function tally(){
  let n=0; const t={built:0,table:0,pack:0};
  const lines=[];
  DATA.forEach(p=>{ const ch=picks[p.n]||[]; n+=ch.length; ch.forEach(id=>{ const o=p.opts.find(x=>x.id===id); if(o) t[o.src]++; });
    lines.push('Position '+p.n+' ('+p.what+'): '+(ch.length? ch.map(id=>p.opts.find(x=>x.id===id).name).join('; ') : 'none')); });
  $('#count').textContent = n+' exhibits picked';
  const ta=$('#tally'); ta.textContent='';
  [['built','Built here'],['table','Table version'],['pack','Your pack']].forEach(([k,l])=>{ ta.appendChild(el('span','badge src-'+k, l+': '+t[k])); });
  $('#sumtxt').textContent = lines.join('\\n');
}
function toggle(n,id){
  const a = picks[n] = picks[n]||[]; const i=a.indexOf(id); if(i>=0) a.splice(i,1); else a.push(id);
  const y=window.scrollY; render(); window.scrollTo(0,y); queueSave();
}
function queueSave(){ if(!db){ return; } setStatus('Saving…',''); clearTimeout(saveTimer); saveTimer=setTimeout(save,600); }
async function save(){
  try{ await db.doc('choices/current').set({picks, updatedAt: new Date().toISOString()}); setStatus('Choices saved','ok'); }
  catch(e){ setStatus('Could not save here. Copy your choices from the bottom of the page.',''); }
}
function setStatus(t,c){ const s=$('#status'); s.textContent=t; s.className='status '+(c||''); }
function openLb(o){ $('#lbt').textContent=o.name; $('#lbi').src='full/'+o.id+'.jpg'; $('#lbi').alt=o.name+': '+o.sub; $('#lb').hidden=false; $('#lbx').focus(); }
function closeLb(){ $('#lb').hidden=true; $('#lbi').src=''; }
$('#lbx').onclick=closeLb; $('#lb').addEventListener('click',e=>{ if(e.target.id==='lb') closeLb(); });
document.addEventListener('keydown',e=>{ if(e.key==='Escape' && !$('#lb').hidden) closeLb(); });
$('#reset').onclick=()=>{ picks=JSON.parse(JSON.stringify(rec)); const y=window.scrollY; render(); window.scrollTo(0,y); queueSave(); };
$('#copy').onclick=async()=>{ const t=$('#sumtxt').textContent; try{ await navigator.clipboard.writeText(t); $('#copied').textContent='Copied.'; }catch(e){ const r=document.createRange(); r.selectNodeContents($('#sumtxt')); const s=getSelection(); s.removeAllRanges(); s.addRange(r); $('#copied').textContent='Selected: press Ctrl+C or Cmd+C.'; } };
render();
(async()=>{
  try{
    db = window.claude && window.claude.use ? await window.claude.use('db') : null;
    if(!db){ setStatus('Saving is not available in this view. Copy your choices from the bottom of the page.',''); return; }
    const snap = await db.doc('choices/current').get();
    const d = snap && (snap.data ? snap.data() : snap);
    if(d && d.picks){ picks=JSON.parse(JSON.stringify(d.picks)); render(); setStatus('Saved choices loaded','ok'); }
    else { setStatus('Showing my recommendations. Your changes will save automatically.','ok'); }
  }catch(e){ setStatus('Saving is not available in this view. Copy your choices from the bottom of the page.',''); db=null; }
})();
</script>
'''
open('/home/claude/chooser/index.html', 'w').write(page)
print('ok', len(data), sum(len(p['rec']) for p in data))
