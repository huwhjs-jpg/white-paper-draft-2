import re, json, html
B = '/home/claude/build/'
PICKS = {"1":[],"2":["pB"],"3":["p1"],"4":["pPIflow"],"5":["b3"],"6":["p2"],"7":["b5"],"8":["p4"],"9":["p5"],"10":["p6"],"11":["p7"],"12":[],"13":["b8"],"14":["pPIIflow","b10"],"15":["b11"],"16":["b12","b13"],"17":["b14"],"18":["b15"],"19":["p13"],"20":["b17"],"21":["pPIIIflow","b19"],"22":["b21"],"23":["b20"],"24":["b22"],"25":["p17"],"26":["pPIVflow"],"27":["b25"],"28":["b26"],"29":["b27"],"30":["pB1"]}
X = {str(x[0]): x for x in json.load(open(B + 'all.json'))}
PK = json.load(open('/home/claude/upl/pack.json'))
pk = {}
for it in PK:
    m = re.match(r'^(Exhibit ([0-9A-Z]+b?)|Part (I|II|III|IV) (flow|at a glance))\.', it['cap'])
    key = m.group(2) if m.group(2) else f"P{m.group(3)} {m.group(4)}"
    pk[re.sub(r'[^A-Za-z0-9]', '', key)] = it['cap']

def label(o):
    if o[0] == 'b': return 'Built ' + o[1:], X[o[1:]][3]
    cap = pk[o[1:]]
    head, rest = cap.split('. ', 1)
    return 'Pack ' + head.replace('Exhibit ', ''), rest

# slot label -> (position, candidate option ids that belong to this slot)
SLOT = {
 'Part I flow': (4, ['b2', 'pPIflow', 'pPIataglance']),
 'overseas revenue': (6, ['b4', 'p2']),
 'excavator sales at home and abroad': (5, ['b3']),
 'the 2026 policy reset': (7, ['b5', 'p3']),
 'import shares by country and category': (8, ['b6', 't6', 'p4']),
 'China and Japan in excavators': (9, ['p5']),
 'Indonesian distributor shares': (10, ['b7', 'p6']),
 'category sequence': (11, ['p7']),
 'the five tests': (12, ['p8']),
 'structural-versus-cyclical scorecard': (13, ['b8', 'p9']),
 'Part II flow': (14, ['b9', 'pPIIflow', 'pPIIataglance']),
 'strength of evidence by learning and country': (14, ['b10', 't10', 'p10']),
 'finance steps in Indonesia': (15, ['b11', 'p11']),
 'asking prices by brand': (16, ['b12']),
 'United Tractors revenue by source': (16, ['b13']),
 'plants and service bases': (17, ['b14', 'p12']),
 'local-content scores': (18, ['b15']),
 'electric and engine forklift shares': (19, ['p13']),
 'battery-pack prices by region': (19, ['b16']),
 'moves over time, closing Part II': (20, ['b17', 't17']),
 'Part III flow': (21, ['b18', 'pPIIIflow', 'pPIIIataglance']),
 'five markets compared': (21, ['b19', 't19']),
 'where Chinese brands have gained in India': (22, ['b21', 'p14']),
 'the crane case': (23, ['b20', 'p15']),
 'Chinese penetration in Indonesia': (24, ['p16']),
 'service footprint': (24, ['b22']),
 'Thailand, China against Japan': (25, ['b23', 'p17']),
 'Part IV flow': (26, ['b24', 'pPIVflow', 'pPIVataglance']),
 'failure modes': (27, ['b25', 't25', 'p18']),
 'actions by reader and horizon': (28, ['b26', 'p19']),
 'signposts': (29, ['b27', 'p20']),
}
num = [0]
order = []
def marker(pos, cands, title):
    chosen = [o for o in PICKS[str(pos)] if o in cands]
    alts = [label(o)[0] for o in cands if o not in chosen and o[0] != 't']
    if not chosen:
        return (f'<div class="exm empty"><b>No exhibit here</b> (position {pos}: {html.escape(title)}). '
                f'Options not picked: {", ".join(alts) or "none"}.</div>')
    out = []
    for o in chosen:
        num[0] += 1
        src, cap = label(o)
        order.append((num[0], pos, o, src, cap))
        out.append(f'<div class="exm"><span class="exn">Exhibit {num[0]}</span> <b>{html.escape(cap)}</b>'
                   f'<span class="exs">{src} · position {pos}' + (f' · not picked: {", ".join(alts)}' if alts else '') + '</span></div>')
    return '\n'.join(out)

def slots(s):
    def rep(m):
        t = html.unescape(re.sub(r'<[^>]+>', '', m.group(1))).replace('Exhibit slot: ', '').strip()
        pos, c = SLOT[t]
        return marker(pos, c, t)
    return re.sub(r'<div class="exslot"><b>(.*?)</b>.*?</div>', rep, s, flags=re.S)

def block(s, start_pat):
    i = s.find(start_pat)
    assert i >= 0, start_pat
    j = s.find('>', i) + 1
    depth, k = 1, j
    for m in re.finditer(r'<(/?)div\b', s[j:]):
        depth += -1 if m.group(1) else 1
        if depth == 0:
            return s[j:j + m.start()]
    raise ValueError

sp = open('/home/claude/china-playbook-step2-spine.html').read()
about = block(sp, '<div class="paper" id="t-about"')
if 'class="tw' not in about: about = about.replace('<table','<div class="tw"><table').replace('</table>','</table></div>')
exec_ = block(sp, '<div class="paper" id="t-exec"')
concl = block(sp, '<div class="paper" id="t-concl"')
p1 = block(open(B + 'step4_body.html').read(), '<div class="paper"')
p2 = open(B + 'step5_text.html').read()
p3 = open(B + 'step6_text.html').read()
p4 = open(B + 'step7_text.html').read()
m8 = open(B + 'pub/china-playbook-step8-matter.html').read()
front = block(m8, '<div class="paper"')
def sect(s, sid):
    i = s.find(f'<section id="{sid}"'); j = s.find('</section>', i)
    return s[s.find('>', i) + 1:j]
aboutycp = sect(m8, 'about'); appa = sect(m8, 'appa'); gloss = sect(m8, 'gloss'); refs = sect(m8, 'refs')
# drop the review note paragraphs (class note) in matter sections
for nm in ('aboutycp', 'appa', 'gloss'):
    pass

parts = []
parts.append(('front', 'Front matter (cover and contents)', front))
parts.append(('exec', 'Executive summary', marker(1, ['pA'], 'beside the list of six learnings') + exec_))
parts.append(('about', 'About this paper', about.replace('</h3>', '</h3>' + marker(2, ['pB'], 'scope') + marker(3, ['b1', 't1', 'p1', 'p1b'], 'how the paper is organised'), 1)))
parts.append(('p1', 'Part I', slots(p1)))
parts.append(('p2', 'Part II', slots(p2)))
parts.append(('p3', 'Part III', slots(p3)))
parts.append(('p4', 'Part IV', slots(p4)))
parts.append(('concl', 'Conclusion', concl))
parts.append(('appa', 'Appendix A', appa))
parts.append(('gloss', 'Appendix B', gloss))
parts.append(('appc', 'Appendix C', '<h3>Appendix C. UN Comtrade import values used in this paper</h3>' + marker(30, ['pB1'], 'data appendix')))
parts.append(('aboutycp', 'About YCP', aboutycp))
parts.append(('refs', 'References (audit and full cited list)', refs))

css = ''.join(re.findall(r'<style>(.*?)</style>', open(B + 'pub/china-playbook-step7-part4.html').read(), re.S))
css += ''.join(re.findall(r'<style>(.*?)</style>', open(B + 'pub/china-playbook-step8-matter.html').read(), re.S))
css += ''.join(re.findall(r'<style>(.*?)</style>', open(B + 'step4_body.html').read(), re.S))
head = open('/home/claude/_head.html').read()
head = re.sub(r'<title>.*?</title>', '', head)
extra = '''
.exm{border:1.5px solid var(--accent);background:var(--pale);border-radius:6px;padding:10px 14px;font-family:var(--sans);font-size:14px;display:grid;gap:3px;max-width:70ch}
.exm.empty{border-style:dashed;border-color:var(--rule);background:transparent;color:var(--muted)}
.exn{font-family:var(--mono);font-size:12.5px;color:var(--accent);font-weight:500}
.exs{font-size:12.5px;color:var(--muted)}
.ms{padding-top:26px}
.ms > h2.sec{font-size:13px;letter-spacing:.09em;text-transform:uppercase;color:var(--muted);font-family:var(--sans);margin:0 0 8px}
.toc2{display:flex;flex-wrap:wrap;gap:6px 16px;font-size:14px;padding:12px 0;border-bottom:1px solid var(--rule)}
.toc2 a{color:var(--accent);text-decoration:none}
.olist td,.olist th{font-size:13.5px}
.ms>*,.paper>*,.paper>div>*{min-width:0}
.paper table:not(.tw table){display:block;overflow-x:auto;max-width:100%}
'''
body = []
body.append('<header class="top" style="padding-block:32px 16px;border-bottom:3px solid var(--ink);display:grid;gap:10px">'
            '<p class="kicker" style="margin:0;font-family:var(--sans);font-size:12.5px;font-weight:700;letter-spacing:.09em;text-transform:uppercase;color:var(--accent)">Assembly source · v1 · 29 September 2026</p>'
            '<h1 style="margin:0">The China Playbook: approved text in paper order</h1>'
            '<p style="max-width:760px;margin:0">Every rewritten section from Steps 2, 4, 5, 6, 7 and 8, in the order the paper will print. '
            'Exhibit slots are replaced by the exhibits picked in the chooser, numbered in paper order. '
            'Reference superscripts still use the draft\'s numbers; they are renumbered by first citation at assembly. '
            'Orange tags mark text only the firm can supply.</p></header>')
body.append('<nav class="toc2">' + ''.join(f'<a href="#{k}">{t}</a>' for k, t, _ in parts) + '<a href="#olist">Exhibit list</a></nav>')
for k, t, h in parts:
    body.append(f'<section class="ms" id="{k}"><h2 class="sec">{t}</h2><div class="paper">{h}</div></section>')
rows = ''.join(f'<tr><td class="num">{n}</td><td>{p}</td><td>{html.escape(src)}</td><td>{html.escape(cap)}</td></tr>' for n, p, o, src, cap in order)
body.append(f'<section class="ms" id="olist"><h2 class="sec">Exhibit list</h2><p>{len(order)} exhibits: '
            f'{sum(1 for r in order if r[2][0]=="b")} built in the working chat, {sum(1 for r in order if r[2][0]=="p")} from the exhibit pack.</p>'
            f'<div class="tw olist"><table><thead><tr><th class="num">No.</th><th>Position</th><th>Source</th><th>Title</th></tr></thead><tbody>{rows}</tbody></table></div></section>')
out = '<title>China Playbook Assembly Source</title>\n' + head + '<style>' + css + extra + '</style>\n<div class="wrap">' + '\n'.join(body) + '</div>'
open(B + 'pub/china-playbook-assembly-source.html', 'w').write(out)
json.dump(order, open(B + 'exhibit_order.json', 'w'), indent=1)
print(len(order), 'exhibits')
for r in order: print(r[0], r[1], r[2], r[3], '|', r[4][:80])
