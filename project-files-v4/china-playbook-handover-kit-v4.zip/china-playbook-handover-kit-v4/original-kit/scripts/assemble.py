import json, re
X = json.load(open('/home/claude/build/all.json'))
PA = json.load(open('/home/claude/build/parts.json'))['A']
head = open('/home/claude/_head.html').read()
v2 = open('/home/claude/china-playbook-step3-exhibits-v2.html').read()
base_css = re.search(r'(<style>\n\.wrap\{max-width:1480px\}.*?</style>)', v2, re.S).group(1).replace('.wrap{max-width:1480px}', '.wrap{max-width:1040px}')

css = r'''<style>
.frame .vizwrap .viz{min-width:520px}
.frame > *, section > *, .ex > *{min-width:0}
.vlab2{font-size:12px;letter-spacing:.08em;text-transform:uppercase;font-weight:700;color:var(--accent);margin-top:6px}
.amap{display:grid;gap:12px}.amap .q,.amap .a{padding:14px 18px;font-family:var(--serif);font-size:16px}.amap .q{background:var(--pale);color:var(--ink)}.amap .a{background:var(--h5);color:var(--h5t)}
.viz .ph0{fill:var(--h5)} .viz .ph1{fill:var(--h4)} .viz .ph-t{fill:#fff;font-size:11.5px;font-weight:700;letter-spacing:.06em}
.viz .trk{stroke:var(--h3);stroke-width:4} .viz .trk-a{fill:var(--h3)}
.viz .stn{fill:var(--cn);stroke:var(--surface);stroke-width:3} .viz .stn-n{fill:#fff;font-family:var(--mono);font-size:15px;font-weight:500}
.viz .stn-v{fill:var(--ink);font-family:var(--serif);font-size:16px;font-weight:600} .viz .stn-l{fill:var(--muted);font-size:12.5px}
.ld-gaps span:not(.ld-gl){transform:translateX(-50%)!important}
.ex{scroll-margin-top:12px}
.ex-tag{font-family:var(--mono);font-size:11.5px;padding:1px 7px;border-radius:3px;background:var(--pale);color:var(--ink)}
.ex-tag.new{background:var(--h4);color:var(--h4t)}
.spec2{font-size:13.5px;color:var(--muted)}
/* chart pieces */
.viz .ln-grey{fill:none;stroke:var(--nat);stroke-width:2.5}
.viz .ln-blue{fill:none;stroke:var(--cn);stroke-width:2.5}
.viz .ln-grey-d{fill:var(--nat);stroke:var(--surface);stroke-width:2}
.viz .ln-blue-d{fill:var(--cn);stroke:var(--surface);stroke-width:2}
.viz .endlab{font-size:12px;font-weight:600}
.viz .ln-grey-t{fill:var(--muted)} .viz .ln-blue-t{fill:var(--cn)}
.viz .bar{fill:var(--h3)} .viz .bar-hi{fill:var(--cn)} .viz .bar-pale{fill:var(--h2)} .viz .bar-pale2{fill:var(--h2)}
.viz .val-in{fill:#fff;font-size:12px;font-weight:700;font-family:var(--mono)}
.viz .big-ch{fill:var(--ink);font-family:var(--serif);font-size:30px;font-weight:600}
.viz .panel-t{fill:var(--ink);font-size:12.5px;font-weight:700}
.viz .rg{fill:var(--nat);opacity:.55} .viz .rg-cn{fill:var(--cn)}
.viz .stemg{stroke:var(--rule);stroke-width:2}
.viz .d-cn{fill:var(--cn);stroke:var(--surface);stroke-width:2} .viz .d-g{fill:var(--nat);stroke:var(--surface);stroke-width:2}
.viz .sea{fill:var(--pale)} .viz .land{fill:var(--surface);stroke:var(--rule);stroke-width:.6} .viz .land-f{fill:var(--h2);stroke:var(--h3);stroke-width:.8}
.viz .cty{fill:var(--ink);font-size:12px;font-weight:700;letter-spacing:.12em;opacity:.55}
.viz .site-new{fill:var(--cn);stroke:var(--surface);stroke-width:2}
.viz .site-old{fill:var(--surface);stroke:var(--ink);stroke-width:2}
.viz .maplab{fill:var(--ink);font-size:11px;font-weight:600;paint-order:stroke;stroke:var(--pale);stroke-width:3px;stroke-linejoin:round}
.viz .sl-cn{stroke:var(--cn);stroke-width:2.5} .viz .sl-jp{stroke:var(--jp);stroke-width:2.5}
.viz .val-s{fill:var(--text);font-size:11px;font-family:var(--mono)}
.viz .sl-win-cn{fill:var(--cn);font-size:11.5px;font-weight:700} .viz .sl-win-jp{fill:var(--jp);font-size:11.5px;font-weight:700}
.kln{width:22px;height:3px;display:inline-block;vertical-align:3px} .kgrey{background:var(--nat)} .kblue{background:var(--cn)}
.ksq{width:13px;height:13px;display:inline-block;vertical-align:-2px;border-radius:2px}
.kpale{background:var(--h2)} .kpale2{background:var(--h2)} .kgreyk{background:var(--nat)}
.ksite{width:12px;height:12px;border-radius:50%;display:inline-block;vertical-align:-2px}
.knew{background:var(--cn)} .kold{border:2px solid var(--ink);background:var(--surface)}
/* part flows */
.fsteps{display:grid;grid-template-columns:1fr 28px 1fr 28px 1fr;align-items:stretch;gap:6px}
.fs{background:var(--pale);padding:14px 16px;display:grid;gap:6px;align-content:start}
.fs-ch{font-family:var(--mono);font-size:11.5px;color:var(--accent)}
.fs-q{font-family:var(--serif);font-size:15.5px;color:var(--ink);font-weight:600;line-height:1.3}
.fs-m{font-size:16px;color:var(--ink)}
.fs-big{font-family:var(--serif);font-size:34px;color:var(--cn);font-weight:600;line-height:1.05}
.fs-cap{font-size:12.5px;color:var(--muted)}
.fs-a{font-size:13.5px;color:var(--ink);border-top:1px solid var(--rule);padding-top:6px;font-weight:600}
.fs-arrow{align-self:center;height:0;border-top:12px solid transparent;border-bottom:12px solid transparent;border-left:16px solid var(--h4);width:0;justify-self:center}
.fs-next{font-size:13px;color:var(--muted);font-style:italic;text-align:right}
.mbar{height:10px;background:var(--surface);display:block;border:1px solid var(--rule)} .mbar i{display:block;height:100%;background:var(--cn)}
.ico{display:grid;gap:4px;padding:6px 0}
.ico i{display:block;background:var(--h4);border-radius:2px}
.ico6{grid-template-columns:repeat(6,1fr)} .ico6 i{height:30px}
.ico18{grid-template-columns:repeat(3,1fr)} .ico18 i{height:8px} .ico18 i:nth-child(3n+1){background:var(--h5)} .ico18 i:nth-child(3n+2){background:var(--h4)} .ico18 i:nth-child(3n){background:var(--h3)}
.ico8{grid-template-columns:repeat(8,1fr)} .ico8 i{height:18px;border-radius:50%;aspect-ratio:1;height:auto}
@media (max-width:720px){.fsteps{grid-template-columns:1fr}.fs-arrow{transform:rotate(90deg);margin:2px auto}}
.track{display:grid;gap:6px}
.tr-row{display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:6px}
.tr-ph{background:var(--h5);color:var(--h5t);font-size:11.5px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;padding:6px 10px;text-align:center}
.tr-line{position:relative}
.tr-st{background:var(--pale);padding:12px 10px;display:grid;gap:4px;justify-items:center;text-align:center;position:relative}
.tr-n{width:34px;height:34px;border-radius:50%;background:var(--cn);color:#fff;display:grid;place-items:center;font-family:var(--mono);font-weight:500}
.tr-st b{font-family:var(--serif);font-size:16px;color:var(--ink)} .tr-st span{font-size:12.5px;color:var(--muted)} .tr-c{font-family:var(--mono);font-size:11px}
@media (max-width:720px){.tr-row{grid-template-columns:repeat(3,minmax(0,1fr))} .tr-ph{grid-column:auto!important}}
/* policy calendar */
.pcal{display:grid;gap:0}
.pc-row{display:grid;grid-template-columns:48px 1fr 1fr;gap:10px;padding:7px 0;border-top:1px solid var(--rule);align-items:start}
.pc-h{border-top:0;font-size:12px;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:.06em}
.pc-m{font-family:var(--mono);font-size:12.5px;color:var(--ink);font-weight:500;padding-top:3px}
.pc-empty{padding:3px 0} .pc-empty .pc-m{color:var(--nat)}
.pc-c{display:grid;gap:5px}
.pchip{font-size:12.5px;padding:5px 9px;border-radius:4px;line-height:1.35}
.po{background:var(--h2);color:var(--h2t)} .pb{background:var(--surface);color:var(--ink);border:1.5px solid var(--ink)}
/* scorecard */
.score{display:grid}
.sc-r{display:grid;grid-template-columns:22px minmax(0,1.2fr) minmax(0,1fr) minmax(0,1fr);gap:10px;padding:10px 0;border-top:1px solid var(--rule);align-items:start}
.sc-h{border-top:0;font-size:12px;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:.06em}
.sc-n{font-family:var(--mono);color:var(--accent)} .sc-q{font-family:var(--serif);font-size:15px;color:var(--ink)}
.sc-c{display:grid;grid-template-columns:22px 1fr;gap:8px;align-items:start}
.sc-c b{display:block;font-size:13px;color:var(--ink)} .sc-c small{display:block;font-size:12px;color:var(--muted)}
.sc-m{width:20px;height:20px;border-radius:50%;display:inline-block;border:2px solid var(--cn)}
.sc-pass{background:var(--cn)} .sc-part{background:conic-gradient(var(--cn) 0 50%,transparent 50% 100%)} .sc-cont{background:var(--surface);border-style:dashed}
.vizkey .sc-m{width:13px;height:13px;vertical-align:-2px}
.sc-v{background:var(--h5);color:var(--h5t);padding:12px 10px;border-top:0;margin-top:4px}
.sc-v span{font-weight:700} .sc-vv{font-family:var(--serif);font-size:15.5px}
@media (max-width:640px){.sc-r{grid-template-columns:18px 1fr}.sc-r>.sc-c{grid-column:2}.sc-h span:nth-child(n+3){display:none}.sc-vv{grid-column:2!important}}
/* ladder */
.ladder{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px;align-items:end}
.ld-c{display:grid;gap:8px}
.ld-txt{display:grid;gap:3px} .ld-d{font-family:var(--mono);font-size:12px;color:var(--accent)} .ld-txt b{font-family:var(--serif);font-size:18px;color:var(--ink)} .ld-txt span:last-child{font-size:12.5px;color:var(--muted);line-height:1.35}
.ld-step{background:var(--cn);display:grid;place-items:start center;padding-top:8px;color:#fff;font-family:var(--mono);font-size:14px;border-radius:3px 3px 0 0}
.ld-c:nth-child(1) .ld-step{background:var(--h2);color:var(--h2t)} .ld-c:nth-child(2) .ld-step{background:var(--h3);color:var(--h3t)} .ld-c:nth-child(3) .ld-step{background:var(--h4);color:var(--h4t)} .ld-c:nth-child(4) .ld-step{background:var(--h5);color:var(--h5t)}
.ld-gaps{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px;font-size:12px;color:var(--muted);text-align:center;border-top:2px solid var(--ink);padding-top:6px}
.ld-gaps span:not(.ld-gl){transform:translateX(50%)} .ld-gl{text-align:left;font-style:italic}
.ld-side{font-size:13px;background:var(--pale);padding:10px 12px}
/* crane */
.smg{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px}
.sm .viz{min-width:0!important}
@media (max-width:720px){.smg{grid-template-columns:repeat(2,minmax(0,1fr))}}
.crane-band{display:grid;grid-template-columns:auto 1fr auto 1fr auto 1fr;gap:6px 10px;align-items:center;background:var(--pale);padding:10px 12px}
.crane-band b{font-family:var(--serif);font-size:22px;color:var(--cn)} .crane-band span{font-size:12.5px;color:var(--ink)}
@media (max-width:720px){.crane-band{grid-template-columns:auto 1fr}}
/* waffle */
.waffle-wrap{display:grid;grid-template-columns:minmax(200px,300px) 1fr;gap:20px;align-items:center}
.waffle{display:grid;grid-template-columns:repeat(10,1fr);gap:3px}
.waffle i{aspect-ratio:1;display:block;border-radius:2px}
.wf-jcb{background:var(--h5)} .wf-oth{background:var(--h2)} .wf-liu{background:var(--cn);outline:2px solid var(--ink);outline-offset:1px}
.wf-legend{display:grid;gap:10px} .wf-legend div{display:grid;grid-template-columns:18px 1fr;gap:2px 10px;align-items:center}
.wf-legend i{width:16px;height:16px;border-radius:2px;grid-row:span 2} .wf-legend b{color:var(--ink)} .wf-legend span{font-size:12.5px;color:var(--muted)}
.wf-total{font-family:var(--serif);font-size:15px;color:var(--ink);border-top:1px solid var(--rule);padding-top:8px}
@media (max-width:560px){.waffle-wrap{grid-template-columns:1fr}}
/* footprint */
.fp{display:grid;gap:4px}
.fp-grp{font-size:11.5px;letter-spacing:.08em;text-transform:uppercase;font-weight:700;color:var(--muted);padding-top:10px}
.fp-r{display:grid;grid-template-columns:minmax(150px,230px) 1fr 40px;gap:12px;align-items:center;padding:6px 0;border-top:1px solid var(--rule)}
.fp-l b{display:block;font-size:13px;color:var(--ink)} .fp-l span{font-size:11.5px;color:var(--muted)}
.fp-d{display:flex;flex-wrap:wrap;gap:3px}
.fp-d i,.vizkey i.fp-ut,.vizkey i.fp-cn{width:9px;height:9px;border-radius:50%;display:inline-block}
.fp-ut{background:var(--h5)} .fp-ut2{background:var(--h3)} .fp-cn{background:var(--cn)}
.fp-n{font-family:var(--serif);font-size:20px;color:var(--ink);text-align:right}
@media (max-width:560px){.fp-r{grid-template-columns:1fr 36px}.fp-d{grid-column:1/-1;grid-row:2}}
/* thai */
.smg5{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:6px}
.sm5 .viz{min-width:0!important}
@media (max-width:720px){.smg5{grid-template-columns:repeat(3,minmax(0,1fr))}}
/* actions */
.amx{display:grid;overflow-x:auto}
.am-r{display:grid;grid-template-columns:150px repeat(3,minmax(170px,1fr));gap:6px;padding:6px 0;border-top:1px solid var(--rule);min-width:680px}
.am-hd{border-top:0;font-size:12px;font-weight:700;color:var(--h5t);text-transform:uppercase;letter-spacing:.06em}
.am-hd div:not(:first-child){background:var(--h5);padding:6px 8px}
.am-hd div:nth-child(3){background:var(--h4)} .am-hd div:nth-child(4){background:var(--h3);color:var(--h3t)}
.am-h{font-family:var(--serif);font-size:14.5px;color:var(--ink);font-weight:600;padding-top:4px}
.am-c{display:grid;gap:4px;align-content:start}
.am-i{font-size:12.5px;background:var(--pale);padding:5px 7px;line-height:1.35;display:flex;gap:6px;align-items:baseline}
.am-t{font-family:var(--mono);font-size:10.5px;color:var(--h4t);background:var(--cn);padding:0 4px;border-radius:2px;flex:none}
/* signposts */
.sps{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:10px}
.sp{border:1px solid var(--rule);border-top:5px solid var(--rule);padding:10px 12px;display:grid;gap:6px;align-content:start;background:var(--surface)}
.sp-r{border-top-color:var(--bad)} .sp-a{border-top-color:var(--warn)} .sp-g{border-top-color:var(--good)}
.sp-top{display:flex;justify-content:space-between;align-items:center}
.sp-n{font-family:var(--mono);color:var(--accent)} .sp-s{font-size:11px;font-weight:700;padding:1px 7px;border-radius:3px}
.sp-r .sp-s{color:var(--bad);background:var(--bad-bg)} .sp-a .sp-s{color:var(--warn);background:var(--warn-bg)}
.sp b{font-size:13.5px;color:var(--ink);line-height:1.3}
.sp-k{font-size:12.5px;line-height:1.35} .sp-k em{display:block;font-style:normal;font-size:10.5px;letter-spacing:.07em;text-transform:uppercase;font-weight:700;color:var(--muted)}
.sp-src{font-size:11.5px;color:var(--muted);font-style:italic;border-top:1px solid var(--rule);padding-top:5px}
.sp-kr{background:var(--bad)} .sp-ka{background:var(--warn)}
.index-t td{font-size:13px}
</style>'''

old_map = {1: "1", 6: "2", 10: "3", 17: "4", 19: "5", 25: "6"}
sections, rows = [], []
for n, where, kind, headline, body, origin in X:
    tag = ' <span class="ex-tag">flow exhibit</span>' if kind == 'flow' else (' <span class="ex-tag">part flow</span>' if kind == 'part flow' else '')
    newtag = '<span class="ex-tag new">new</span>' if origin == 'New' else f'<span class="ex-tag">was Exhibit {old_map[n]}</span>'
    if origin != 'New':
        k = 'ex' + old_map[n]
        body = ('<div class="vlab2">Visual version (B)</div>' + body +
                '<div class="vlab2">Original table version (A)</div>' + PA[k])
    sections.append(f'<section class="ex" id="x{n}"><div class="ex-num">Exhibit {n} <span>{where}</span>{tag} {newtag}</div><p class="ex-head">{headline}</p>{body}</section>')
    rows.append(f'<tr><td class="num"><a href="#x{n}">{n}</a></td><td>{where}</td><td>{headline}</td><td>{"New" if origin=="New" else "Was " + origin.split()[-1]}</td></tr>')

json.dump({str(x[0]):sec for x,sec in zip(X,sections)}, open('/home/claude/build/secs.json','w'))
json.dump({'css': base_css+css, 'head': head}, open('/home/claude/build/css.json','w'))
part_breaks = {2: "Part I · The shift", 9: "Part II · The playbook", 18: "Part III · Markets", 24: "Part IV · Limits and actions"}
out = []
for n, sec in zip([x[0] for x in X], sections):
    if n in part_breaks:
        out.append(f'<div class="group">{part_breaks[n]}</div>')
    elif n == 1:
        out.append('<div class="group">Front of the paper</div>')
    out.append(sec)

body = f'''<div class="wrap">
<header class="top">
  <div class="eyebrow">Step 3 · Full exhibit set · 29 September 2026</div>
  <h1>The China Playbook: all 27 exhibits</h1>
  <p class="lede">Every exhibit in paper order: the six already reviewed (each shown in both its visual version and its original table version), the 17 proposed, and one flow exhibit opening each Part. Figures come from the draft unless a note says otherwise.</p>
  <div class="meta"><span>Hover a mark for its exact value</span><span>Numbers are final paper order; the six earlier exhibits are renumbered</span></div>
</header>
<section id="index">
  <h2>Index</h2>
  <div class="tw index-t"><table>
    <thead><tr><th class="num">#</th><th>Where</th><th>Headline</th><th>Status</th></tr></thead>
    <tbody>{"".join(rows)}</tbody>
  </table></div>
  <p class="prose spec2">Not built: the dealer and JV-partner diligence grid for Chapter 14. It is a table by nature and needs content from the Step 7 rewrite.</p>
</section>
{"".join(out)}
<section id="checks">
  <h2>Checks for you</h2>
  <ul class="prose">
    <li><b>Three new figures from outside the draft.</b> Exhibit 3 uses CCMA excavator sales for 2021 and 2024 (verified: 274,357 and 68,427; 100,543 and 100,588) and a 2022 figure derived from 2023's year-on-year changes. Add these sources to the reference list.</li>
    <li><b>Calculated figures.</b> Exhibit 13 splits United Tractors' segment revenue into machines and parts from rounded numbers; Exhibit 16 derives North American and European pack prices from BloombergNEF's percentages; Exhibit 7 implies market size from share. Each is labelled in its note.</li>
    <li><b>Provisional content.</b> Exhibits 8, 26 and 27 anticipate the Chapter 3 and Part IV rewrites. The horizons in 26 and the thresholds in 27 are proposals.</li>
    <li><b>Density.</b> 27 exhibits in 50 body pages is at the high end of house practice (P14 had about 35 in 48 pages). If that feels heavy, the first candidates to drop are Exhibits 16, 22 and 5.</li>
  </ul>
</section>
</div>'''
open('/home/claude/china-playbook-exhibits-all.html', 'w').write('<title>China Playbook Exhibit Set</title>\n' + head + base_css + css + body)
print('ok')
