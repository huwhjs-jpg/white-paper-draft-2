const { chromium } = require('playwright');
(async()=>{
 const b=await chromium.launch(); const p=await b.newPage({viewport:{width:1100,height:1000},deviceScaleFactor:1});
 await p.goto('file:///home/claude/pub/index.html');
 await p.evaluate(()=>document.querySelectorAll('img').forEach(i=>i.loading='eager'));
 await p.waitForTimeout(2500);
 const jobs=await p.evaluate(()=>{const out=[];
   document.querySelectorAll('section.ex').forEach(s=>{const id=s.id;const fr=s.querySelectorAll(':scope > .frame');
     if(id.startsWith('x')){ if(fr[0]) out.push([id,0,'b'+id.slice(1)]); if(fr[1]) out.push([id,1,'t'+id.slice(1)]); }
     else if(id.startsWith('pk-')){ out.push([id,0,'p'+id.slice(3)]); }
   });return out;});
 for(const [id,i,name] of jobs){
   const el=(await p.$$('#'+id+' > .frame'))[i];
   await el.screenshot({path:'/home/claude/chooser/full/'+name+'.png'});
 }
 console.log(jobs.length);
 await b.close();})();
