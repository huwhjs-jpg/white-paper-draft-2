import json, re, html
E = lambda t: html.escape(str(t), quote=True)
P = json.load(open('/home/claude/build/parts.json'))['B']
MAP = json.load(open('/home/claude/build/map.json'))

def svg(w, h, label, body):
    return f'<div class="vizwrap"><svg class="viz" viewBox="0 0 {w} {h}" role="img" aria-label="{E(label)}">{body}</svg></div>'

def frame(title, body, source, note=None, key=None):
    k = f'<div class="vizkey">{key}</div>' if key else ''
    n = f'<span>Note: {note}</span>' if note else ''
    return f'<div class="frame"><p class="ex-title">{title}</p>{k}{body}<div class="ex-src"><span>Source: {source}</span>{n}</div></div>'

def strip_existing(h):  # reuse B frames from the redesign page
    return h

# ---------------- flow exhibits ----------------
def part_flow(steps, nxt):
    cells = []
    for i, (ch, q, big, cap, ans) in enumerate(steps):
        cells.append(f'<div class="fs"><span class="fs-ch">{E(ch)}</span><span class="fs-q">{E(q)}</span><span class="fs-big">{E(big)}</span><span class="fs-cap">{E(cap)}</span><span class="fs-a">{E(ans)}</span></div>')
        if i < len(steps) - 1:
            cells.append('<div class="fs-arrow" aria-hidden="true"></div>')
    return f'<div class="fsteps">{"".join(cells)}</div><div class="fs-next">{E(nxt)}</div>'

X2 = frame("How Part I is built: three questions, chapters 1–3", part_flow([
    ("Chapter 1", "Why learn from Chinese OEMs now?", "63%", "of SANY's 2025 revenue earned abroad", "The leaders are now majority-overseas, and 2026 reset the rules"),
    ("Chapter 2", "Where has share moved?", "18 of 19", "country–category pairs where China's import share rose, 2019–24", "Broad gains, but not in Thai excavators"),
    ("Chapter 3", "Will the shift last?", "3 of 5", "tests passed outright in India and Indonesia", "Structural, specific to category, still contestable"),
], "Leads to Part II: how Chinese OEMs won"), "YCP analysis of the sources cited in Chapters 1–3.")

def track():
    W, H = 760, 230
    st = [("1", "Enter", "Beachhead", "Ch 4"), ("2", "Finance", "Customer credit", "Ch 5"), ("3", "Price and serve", "Price and lifecycle", "Ch 6"),
          ("4", "Build", "Local plants", "Ch 7"), ("5", "Qualify", "Local rules", "Ch 8"), ("6", "Renew", "Electrification", "Ch 9")]
    xs = [70 + i * 124 for i in range(6)]
    phases = [("Win first customers", 0, 1), ("Keep them", 2, 2), ("Scale in the country", 3, 4), ("Next generation", 5, 5)]
    g = []
    for i, (n, a, b) in enumerate(phases):
        x0, x1 = xs[a] - 56, xs[b] + 56
        g.append(f'<rect class="ph{i%2}" x="{x0}" y="14" width="{x1-x0}" height="28" rx="3"/><text class="ph-t" x="{(x0+x1)/2}" y="33" text-anchor="middle">{E(n.upper())}</text>')
    g.append(f'<line class="trk" x1="{xs[0]}" x2="{xs[-1]}" y1="96" y2="96"/>')
    g.append(f'<path class="trk-a" d="M{xs[-1]+34},96 l-14,-8 v16 z"/><line class="trk" x1="{xs[-1]}" x2="{xs[-1]+22}" y1="96" y2="96"/>')
    for (n, v, l, c), x in zip(st, xs):
        g.append(f'<circle class="stn" cx="{x}" cy="96" r="22"/><text class="stn-n" x="{x}" y="102" text-anchor="middle">{n}</text>')
        g.append(f'<text class="stn-v" x="{x}" y="146" text-anchor="middle">{E(v)}</text><text class="stn-l" x="{x}" y="166" text-anchor="middle">{E(l)}</text><text class="tick" x="{x}" y="184" text-anchor="middle">{c}</text>')
    g.append(f'<text class="annot" x="{W-10}" y="{H-8}" text-anchor="end">The machine stays the same; everything around it changes</text>')
    return svg(W, H, "Six moves in customer-relationship order: enter, finance, price and serve, build, qualify, renew; grouped as win first customers, keep them, scale in the country, next generation.", ''.join(g)) + '<div class="fs-next">Leads to Part III: how the moves combine in each market</div>'
X9 = frame("How Part II is built: six moves along the customer relationship, chapters 4–9", track(), "YCP analysis.")

def mkt_flow():
    rows = [("Chapter 10", "India", "What happens when the playbook meets pushback?", 33.9, "Works, then meets trade defence"),
            ("Chapter 11", "Indonesia", "What does the complete playbook look like?", 74.5, "All six moves; the contest moves to finance"),
            ("Chapter 12", "Thailand, with Vietnam and Malaysia", "Does it work without a commodity boom?", 35.9, "Only in some categories")]
    cells = []
    for i, (ch, m, q, v, a) in enumerate(rows):
        cells.append(f'<div class="fs"><span class="fs-ch">{E(ch)}</span><b class="fs-m">{E(m)}</b><span class="fs-q">{E(q)}</span>'
                     f'<span class="mbar"><i style="width:{v}%"></i></span><span class="fs-cap">China&#39;s share of excavator imports, 2024: <b>{v}%</b></span><span class="fs-a">{E(a)}</span></div>')
        if i < 2: cells.append('<div class="fs-arrow" aria-hidden="true"></div>')
    return f'<div class="fsteps">{"".join(cells)}</div><div class="fs-next">Leads to Part IV: where the playbook breaks and what to do</div>'
X18 = frame("How Part III is built: three markets, three tests, chapters 10–12", mkt_flow(), "UN Comtrade via WITS (HS 842952) [7, 8, 38]; YCP analysis.")

def iv_flow():
    blocks = ''.join('<i></i>' for _ in range(6))
    grid = ''.join('<i></i>' for _ in range(18))
    dots = ''.join('<i></i>' for _ in range(8))
    cells = [
        f'<div class="fs"><span class="fs-ch">Chapter 13</span><span class="fs-q">Where does the playbook break?</span><div class="ico ico6">{blocks}</div><span class="fs-a">Six failure modes, each with evidence and a warning sign</span></div>',
        '<div class="fs-arrow" aria-hidden="true"></div>',
        f'<div class="fs"><span class="fs-ch">Chapter 14</span><span class="fs-q">What should each reader do?</span><div class="ico ico18">{grid}</div><span class="fs-a">Six readers across three time horizons</span></div>',
        '<div class="fs-arrow" aria-hidden="true"></div>',
        f'<div class="fs"><span class="fs-ch">Chapter 15</span><span class="fs-q">What should we watch to 2030?</span><div class="ico ico8">{dots}</div><span class="fs-a">Eight signposts with thresholds and review dates</span></div>']
    return f'<div class="fsteps">{"".join(cells)}</div><div class="fs-next">Leads to the conclusion: most moves can be copied, fastest by incumbents</div>'
X24 = frame("How Part IV is built: from limits to actions to signposts, chapters 13–15", iv_flow(), "YCP analysis.")

# ---------------- Chapter 1 ----------------
def ex_sales():
    yrs = [2020, 2021, 2022, 2023, 2024, 2025]
    dom = [292864, 274357, 152000, 89980, 100543, 118518]
    exp = [34741, 68427, 109400, 105038, 100588, 116739]
    W, H, L, R, T, B = 700, 330, 60, 540, 30, 290
    x = lambda i: L + (R - L) * i / 5
    y = lambda v: B - (B - T) * v / 300000
    g = []
    for v in (0, 100000, 200000, 300000):
        g.append(f'<line class="grid" x1="{L}" x2="{R}" y1="{y(v):.1f}" y2="{y(v):.1f}"/><text class="tick" x="{L-8}" y="{y(v)+4:.1f}" text-anchor="end">{v//1000}k</text>')
    for i, yr in enumerate(yrs):
        g.append(f'<text class="tick" x="{x(i):.1f}" y="{B+18}" text-anchor="middle">{yr}</text>')
    for vals, cls, name in ((dom, 'ln-grey', 'Domestic'), (exp, 'ln-blue', 'Exports')):
        pts = ' '.join(f'{x(i):.1f},{y(v):.1f}' for i, v in enumerate(vals))
        g.append(f'<polyline class="{cls}" points="{pts}"/>')
        for i, v in enumerate(vals):
            g.append(f'<g class="row"><title>{name} {yrs[i]}: {v:,} units{" (derived)" if yrs[i]==2022 else ""}</title><circle class="{cls}-d" cx="{x(i):.1f}" cy="{y(v):.1f}" r="4.5"/></g>')
        g.append(f'<text class="endlab {cls}-t" x="{R+10}" y="{y(vals[-1])+(-6 if name=="Domestic" else 12):.1f}">{name} {vals[-1]:,}</text>')
    g.append(f'<line class="ref" x1="{x(3):.1f}" x2="{x(3):.1f}" y1="{y(160000):.1f}" y2="{y(89980)+8:.1f}"/><text class="callout" x="{x(3):.1f}" y="{y(160000)-8:.1f}" text-anchor="middle">2023: exports pass domestic sales</text>')
    g.append(f'<text class="annot" x="{x(0)+6:.1f}" y="{y(292864)-10:.1f}">Home-market peak, 292,864</text>')
    body = svg(W, H, "Line chart of Chinese excavator sales at home and abroad, 2020 to 2025. Domestic sales fell from 292,864 to 89,980 in 2023 while exports rose to 105,038, passing domestic sales.", ''.join(g))
    return frame("Excavators sold by Chinese makers, domestic and export, 2020–2025 (units)", body,
                 "CCMA via Mysteel, Chinadaily, SMM and Jiemian [49–51, new]; YCP analysis.",
                 "2022 derived from 2023 year-on-year changes (domestic −40.8%, exports −4%). First half of 2026: exports 73,295, domestic 79,025 [52, 53].",
                 '<span><i class="kln kgrey"></i>Domestic</span><span><i class="kln kblue"></i>Exports</span>')

def ex_overseas():
    d = [("SANY", 63.0, "HK filing basis; 64% in company release"), ("Zoomlion", 58.56, ""), ("XCMG", 48.2, "passed 50% in H1 2026"), ("LiuGong", 47.65, ""), ("Heli", 44.0, "forklifts"), ("Hangcha", 43.38, "forklifts")]
    W, L, R, T, rh = 700, 110, 640, 20, 38
    H = T + rh * len(d) + 30
    x = lambda v: L + (R - L) * v / 80
    g = []
    for v in (0, 20, 40, 60, 80):
        g.append(f'<line class="grid" x1="{x(v):.1f}" x2="{x(v):.1f}" y1="{T-6}" y2="{H-26}"/><text class="tick" x="{x(v):.1f}" y="{H-10}" text-anchor="middle">{v}%</text>')
    for i, (n, v, note) in enumerate(d):
        yy = T + rh * i
        g.append(f'<g class="row"><title>{n}: {v}% of 2025 revenue overseas{(" (" + note + ")") if note else ""}</title>')
        g.append(f'<text class="lab-hi" x="{L-10}" y="{yy+rh/2+4:.1f}" text-anchor="end">{n}</text>')
        g.append(f'<rect class="{"bar-hi" if v >= 50 else "bar"}" x="{L}" y="{yy+8}" width="{x(v)-L:.1f}" height="{rh-16}" rx="3"/>')
        g.append(f'<text class="val" x="{max(x(v),x(50))+10:.1f}" y="{yy+rh/2+4:.1f}">{v:g}%</text></g>')
    g.append(f'<line class="ref" x1="{x(50):.1f}" x2="{x(50):.1f}" y1="{T-10}" y2="{H-26}"/><text class="annot" x="{x(50)+5:.1f}" y="{T-4}">Half</text>')
    return frame("Overseas share of 2025 revenue, six Chinese equipment makers (%)", svg(W, H, "Bar chart of overseas revenue share for six Chinese makers in 2025, from SANY at 63% to Hangcha at 43%.", ''.join(g)),
                 "Company filings and releases [1–6, 36, 47]; YCP analysis.", "Heli and Hangcha make forklifts; the others make construction machinery. SANY reports 63% in its Hong Kong filing and 64% in its release; XCMG passed 50% in the first half of 2026.")

def ex_policy():
    months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep"]
    opens = {"Jan": ["India withdraws planned certification rule for machinery", "EU and India conclude trade talks"],
             "Feb": ["US–Indonesia trade agreement: US tariff cut to 19%; US goods exempt from local content (19 Feb)"],
             "Mar": ["India's Press Note 2: 60-day decision on minority investment in capital goods (10 Mar)"],
             "Jul": ["UK–India trade agreement in force (15 Jul)"],
             "Sep": ["European Commission sends EU–India deal for signature (11 Sep)"]}
    bars = {"Feb": ["US Supreme Court strikes emergency tariffs; 10% Section 122 surcharge runs 24 Feb–24 Jul"],
            "Mar": ["US opens excess-capacity investigation into 16 economies, all five in this paper (11 Mar)"],
            "Jul": ["US forced-labour Section 301 tariffs: 10% India, Indonesia, Malaysia; 12.5% Thailand, Vietnam, China (24 Jul)"]}
    rows = []
    for m in months:
        o = ''.join(f'<span class="pchip po">{E(t)}</span>' for t in opens.get(m, []))
        b = ''.join(f'<span class="pchip pb">{E(t)}</span>' for t in bars.get(m, []))
        empty = ' pc-empty' if not (o or b) else ''
        rows.append(f'<div class="pc-row{empty}"><span class="pc-m">{m}</span><div class="pc-c">{o}</div><div class="pc-c">{b}</div></div>')
    body = f'<div class="pcal"><div class="pc-row pc-h"><span></span><span>Opens trade or investment (6)</span><span>Raises barriers or uncertainty (3)</span></div>{"".join(rows)}</div>'
    return frame("Policy events affecting equipment trade and investment in the five markets, January–September 2026", body,
                 "Governments, regulators and law-firm notes [34, 35, 57–67]; YCP analysis.",
                 "The US Supreme Court ruling and the Section 122 surcharge that replaced the struck-down tariffs are counted as one event.")

# ---------------- Chapter 2 ----------------
def ex_komatsu():
    d = [(2020, 1564, 29), (2021, 3088, 21), (2022, 5753, 28), (2023, 5270, 29), (2024, 4420, 26), (2025, 4515, 20)]
    W, H, L, R, T, B = 700, 320, 60, 680, 30, 280
    bw = 64
    x = lambda i: L + 30 + i * (R - L - 60) / 5
    y = lambda v: B - (B - T) * v / 25000
    g = []
    for v in (0, 5000, 10000, 15000, 20000, 25000):
        g.append(f'<line class="grid" x1="{L}" x2="{R}" y1="{y(v):.1f}" y2="{y(v):.1f}"/><text class="tick" x="{L-8}" y="{y(v)+4:.1f}" text-anchor="end">{v//1000}k</text>')
    for i, (yr, k, s) in enumerate(d):
        tot = round(k / (s / 100), -2)
        cx = x(i)
        g.append(f'<g class="row"><title>{yr}: implied market about {tot:,.0f} units; Komatsu {k:,} units ({s}%)</title>')
        g.append(f'<rect class="bar-pale" x="{cx-bw/2:.1f}" y="{y(tot):.1f}" width="{bw}" height="{y(k)-y(tot)-2:.1f}" rx="3"/>')
        g.append(f'<rect class="bar-hi" x="{cx-bw/2:.1f}" y="{y(k):.1f}" width="{bw}" height="{B-y(k):.1f}"/>')
        g.append(f'<text class="val" x="{cx:.1f}" y="{min(y(tot)-8, y(k)-24):.1f}" text-anchor="middle">~{tot/1000:.1f}k</text>')
        g.append(f'<text class="{"val-in" if B-y(k)>22 else "val"}" x="{cx:.1f}" y="{y(k)+(16 if B-y(k)>22 else -6):.1f}" text-anchor="middle">{s}%</text>')
        g.append(f'<text class="tick" x="{cx:.1f}" y="{B+18}" text-anchor="middle">{yr}</text></g>')
    g.append(f'<text class="callout" x="{x(5)-bw/2-6:.1f}" y="{y(22600)-24:.1f}" text-anchor="end">Market up about a third from 2023; Komatsu units down</text>')
    return frame("Indonesian market for Komatsu-class machines, implied from United Tractors data, 2020–2025 (units)",
                 svg(W, H, "Stacked columns of Komatsu units within the implied Indonesian market, 2020 to 2025. The market grew to about 22,600 units in 2025 while Komatsu's share fell to 20%.", ''.join(g)),
                 "PT United Tractors annual releases [15–17, 78–80]; YCP analysis.",
                 "Market size = Komatsu units ÷ Komatsu market share, both as reported by United Tractors; an estimate, rounded to the nearest 100 units. Label inside each column is Komatsu's share.",
                 '<span><i class="ksq kblue"></i>Komatsu units</span><span><i class="ksq kpale"></i>Rest of the market</span>')

# ---------------- Chapter 3 ----------------
def ex_scorecard():
    tests = [("1", "Does the incumbent lose share in good years too?", ("pass", "Komatsu 29% → 20% as coal hit records"), ("pass", "Chinese gains made in the FY22–25 boom")),
             ("2", "Did the shift start before the downturn?", ("pass", "Import share 33% → 75% before the 2026 quota cut"), ("pass", "Shift predates the FY26 slowdown")),
             ("3", "Does it show outside the cyclical segment?", ("pass", "Forklifts, cranes, pumps, compressors too"), ("pass", "Forklifts and compressors too")),
             ("4", "Does it hold in a control market (Thailand)?", ("part", "Yes in 4 of 5 categories; not excavators"), ("part", "Yes in 4 of 5 categories; not excavators")),
             ("5", "Has lost share come back anywhere?", ("cont", "Komatsu 21% → 29%, 2021–23"), ("cont", "Tata Hitachi 20% → 35% in mining"))]
    lab = {"pass": "Passes: structural", "part": "Partly: category-specific", "cont": "Yes: contestable"}
    def cell(c):
        k, t = c
        return f'<div class="sc-c"><span class="sc-m sc-{k}" title="{lab[k]}"></span><span><b>{lab[k]}</b><small>{E(t)}</small></span></div>'
    rows = ''.join(f'<div class="sc-r"><span class="sc-n">{n}</span><span class="sc-q">{E(q)}</span>{cell(a)}{cell(b)}</div>' for n, q, a, b in tests)
    body = f'<div class="score"><div class="sc-r sc-h"><span></span><span>Test</span><span>Indonesia</span><span>India</span></div>{rows}<div class="sc-r sc-v"><span></span><span>Verdict</span><span class="sc-vv" style="grid-column:3/5">Structural in both markets, specific to category, and partly contestable</span></div></div>'
    return frame("Five tests of whether Chinese gains are structural or cyclical, Indonesia and India, 2019–2026", body,
                 "Chapter 3 evidence [7–19, 42, 79, 82, 83, 88–93]; YCP analysis.",
                 "A pass on any of tests 1–3 points to a structural shift. Test 5 asks whether share can be won back; a yes means the market is still contestable. Provisional until the Chapter 3 rewrite in Step 4.",
                 '<span><i class="sc-m sc-pass"></i>Passes</span><span><i class="sc-m sc-part"></i>Partly</span><span><i class="sc-m sc-cont"></i>Contestable</span>')

# ---------------- Chapter 5 ----------------
def ex_ladder():
    st = [("Dec 2017", "Partner", "SANY's distributor signs a financing MoU with MNC Leasing", 28),
          ("Dec 2018", "Product", "Low-down-payment heavy-equipment financing launched", 46),
          ("Sep 2025", "Scale", "RMB1.45bn agreement with two lenders, one in the Caterpillar dealer's group", 70),
          ("Sep 2026", "Own", "OJK licenses PT Sany Indonesia Finance", 100)]
    gaps = ["1 year", "7 years", "1 year"]
    cols = []
    for i, (d, v, t, h) in enumerate(st):
        cols.append(f'<div class="ld-c"><div class="ld-txt"><span class="ld-d">{d}</span><b>{v}</b><span>{E(t)}</span></div><div class="ld-step" style="height:{h * 1.4:.0f}px"><span>{i+1}</span></div></div>')
    gl = ''.join(f'<span>{g}</span>' for g in gaps)
    body = f'<div class="ladder">{"".join(cols)}</div><div class="ld-gaps"><span class="ld-gl">Time between steps</span>{gl}</div><div class="ld-side"><b>Same month, a second model:</b> XCMG and its dealer, Gaya Makmur Tractors, launch ABC Multifinance as a joint venture (9 Sep 2026).</div>'
    return frame("SANY's customer-finance steps in Indonesia, 2017–2026", body, "iNews, MNC Leasing, SANY Group, OJK, Equipment Indonesia [23, 56, 103–106, 108]; YCP analysis.")

# ---------------- Chapter 6 ----------------
def ex_prices():
    ind = [("SANY", "TractorJunction", 41, 61, True), ("SANY", "Desimachines", 51, 66, True), ("Komatsu", "PC210 range", 41, 76, False), ("JCB", "NXT 210LC, 215LC", 57, 65, False), ("Tata Hitachi", "comparable models", 61, 67, False)]
    W, L, R, T, rh = 700, 240, 640, 26, 32
    H = T + rh * len(ind) + 34
    x = lambda v: L + (R - L) * (v - 35) / 45
    g = [f'<text class="panel-t" x="10" y="16">India: listed price ranges, INR lakh</text>']
    for v in (40, 50, 60, 70, 80):
        g.append(f'<line class="grid" x1="{x(v):.1f}" x2="{x(v):.1f}" y1="{T}" y2="{H-26}"/><text class="tick" x="{x(v):.1f}" y="{H-10}" text-anchor="middle">{v}</text>')
    for i, (b, s, lo, hi, cn) in enumerate(ind):
        yy = T + rh * i + rh / 2
        c = 'rg-cn' if cn else 'rg'
        g.append(f'<g class="row"><title>{b} ({s}): INR {lo}–{hi} lakh</title><text class="{"lab-hi" if cn else "lab"}" x="{L-10}" y="{yy+4:.1f}" text-anchor="end">{b} · {E(s)}</text>'
                 f'<rect class="{c}" x="{x(lo):.1f}" y="{yy-7:.1f}" width="{x(hi)-x(lo):.1f}" height="14" rx="7"/><text class="val" x="{x(hi)+8:.1f}" y="{yy+4:.1f}">{lo}–{hi}</text></g>')
    a = svg(W, H, "Range bars of listed prices for 21 to 22.5 tonne excavators in India by brand; SANY's ranges sit inside those of Komatsu, JCB and Tata Hitachi.", ''.join(g))
    ido = [("SANY", "SY210–SY220", 1.75, True), ("XCMG", "XE200–XE215", 1.80, True), ("Komatsu", "PC200, PC210", 1.87, False), ("Hitachi", "ZX200, ZX210", 1.90, False), ("Caterpillar", "320", 2.23, False), ("Kobelco", "SK200, SK210", 2.26, False)]
    H2 = T + rh * len(ido) + 34
    x2 = lambda v: L + (R - L) * (v - 1.6) / 0.8
    g = [f'<text class="panel-t" x="10" y="16">Indonesia: median asking price on the public e-catalogue, Rp billion</text>']
    for v in (1.6, 1.8, 2.0, 2.2, 2.4):
        g.append(f'<line class="grid" x1="{x2(v):.1f}" x2="{x2(v):.1f}" y1="{T}" y2="{H2-26}"/><text class="tick" x="{x2(v):.1f}" y="{H2-10}" text-anchor="middle">{v:.1f}</text>')
    for i, (b, s, v, cn) in enumerate(ido):
        yy = T + rh * i + rh / 2
        g.append(f'<g class="row"><title>{b} {s}: median Rp{v:.2f}bn</title><text class="{"lab-hi" if cn else "lab"}" x="{L-10}" y="{yy+4:.1f}" text-anchor="end">{b} · {E(s)}</text>'
                 f'<line class="stemg" x1="{L}" x2="{x2(v):.1f}" y1="{yy:.1f}" y2="{yy:.1f}"/><circle class="{"d-cn" if cn else "d-g"}" cx="{x2(v):.1f}" cy="{yy:.1f}" r="7"/><text class="val" x="{x2(v)+12:.1f}" y="{yy+4:.1f}">{v:.2f}</text></g>')
    b = svg(W, H2, "Dot plot of median asking prices for 20 to 22 tonne excavators in Indonesia: SANY 1.75, XCMG 1.80, Komatsu 1.87, Hitachi 1.90, Caterpillar 2.23, Kobelco 2.26 billion rupiah.", ''.join(g))
    return frame("Asking prices for 20–22.5 tonne excavators by brand, India and Indonesia, September 2026", a + b,
                 "TractorJunction Infra, Desimachines [112–116]; LKPP INAPROC e-Katalog [117]; YCP analysis.",
                 "Asking prices, not transaction prices; specifications vary within each model name. Indonesian figures are medians of reseller listings.",
                 '<span><i class="ksq kblue"></i>Chinese brand</span><span><i class="ksq kgreyk"></i>Incumbent</span>')

def ex_ut():
    d = [("Machine sales", 15.4, 9.5, "−38%"), ("Parts and service", 5.45, 5.5, "+1%")]
    W, H, L, T, B = 700, 300, 40, 56, 250
    y = lambda v: B - (B - T) * v / 18
    g = []
    for v in (0, 5, 10, 15):
        g.append(f'<line class="grid" x1="{L}" x2="{W-20}" y1="{y(v):.1f}" y2="{y(v):.1f}"/><text class="tick" x="{L-8}" y="{y(v)+4:.1f}" text-anchor="end">{v}</text>')
    for i, (n, a, b, ch) in enumerate(d):
        gx = 120 + i * 300
        for j, (v, lab, cls) in enumerate(((a, "H1 2025", "bar-pale2"), (b, "H1 2026", "bar-hi"))):
            bx = gx + j * 92
            g.append(f'<g class="row"><title>{n}, {lab}: Rp{v} trillion</title><rect class="{cls}" x="{bx}" y="{y(v):.1f}" width="80" height="{B-y(v):.1f}" rx="3"/>'
                     f'<text class="val" x="{bx+40}" y="{y(v)-7:.1f}" text-anchor="middle">{v:g}</text><text class="tick" x="{bx+40}" y="{B+16}" text-anchor="middle">{lab}</text></g>')
        g.append(f'<text class="lab-hi" x="{gx+86}" y="{B+38}" text-anchor="middle">{n}</text>')
        g.append(f'<text class="big-ch" x="{gx+86}" y="{y(max(a,b))-26:.1f}" text-anchor="middle">{ch}</text>')
    return frame("United Tractors heavy-equipment revenue by source, first half of 2025 and 2026 (Rp trillion)",
                 svg(W, H, "Paired bars: United Tractors machine sales fell from about 15.4 to 9.5 trillion rupiah while parts and service rose from 5.45 to 5.5 trillion, first half 2025 to 2026.", ''.join(g)),
                 "PT United Tractors, Public Expose 2026 [89]; YCP analysis.",
                 "The company reports segment revenue of Rp15.0 trillion (−28%) and parts and service of Rp5.5 trillion (+1%). Machine sales and the 2025 figures are our calculation from those rounded numbers.",
                 '<span><i class="ksq kpale2"></i>H1 2025</span><span><i class="ksq kblue"></i>H1 2026</span>')

# ---------------- Chapter 7: map ----------------
def ex_map():
    W, H = MAP['W'], MAP['H']
    g = [f'<rect class="sea" x="0" y="0" width="{W}" height="{H}"/>', MAP['paths']]
    for k, (lx, ly) in MAP['lab'].items():
        n = {'356': 'INDIA', '360': 'INDONESIA', '764': 'THAILAND'}[k]
        g.append(f'<text class="cty" x="{lx:.0f}" y="{ly:.0f}" text-anchor="middle">{n}</text>')
    pts = {p['name']: p for p in MAP['pts']}
    for p in MAP['pts']:
        cls = 'site-new' if p['age'] == 'new' else 'site-old'
        tt = f"{p['name']}, {p['date']}"
        if p['type'] == 'service':
            g.append(f'<g class="row"><title>{E(tt)}</title><rect class="{cls}" x="{p["x"]-6}" y="{p["y"]-6}" width="12" height="12"/></g>')
        else:
            g.append(f'<g class="row"><title>{E(tt)}</title><circle class="{cls}" cx="{p["x"]}" cy="{p["y"]}" r="6.5"/></g>')
    labels = [("SANY, Chakan (Pune)", 12, 14, "start", ["Pune area: SANY 2007,", "Zoomlion 2024"]),
              ("LiuGong, Pithampur (expansion)", 10, -8, "start", ["LiuGong, Pithampur", "(expanded Jul 2026)"]),
              ("XCMG, Chennai", 12, 12, "start", ["XCMG, Chennai 2021"]),
              ("Hangcha, Chonburi", 12, -22, "start", ["Hangcha, Chonburi Jun 2026", "Heli, Rayong Nov 2025"]),
              ("SANY, Karawang", -12, 18, "end", ["Karawang: SANY 2023,", "LiuGong Jul 2026 (electric)"]),
              ("XCMG, Balikpapan remanufacturing", -10, 18, "end", ["XCMG remanufacturing,", "Balikpapan Sep 2026"]),
              ("XCMG, Weda Bay", -10, -22, "end", ["XCMG, Weda Bay", "Jul 2026 (electric)"])]
    for nm, dx, dy, anc, lines in labels:
        p = pts[nm]
        t = ''.join(f'<tspan x="{p["x"]+dx}" dy="{0 if i==0 else 13}">{E(l)}</tspan>' for i, l in enumerate(lines))
        g.append(f'<text class="maplab" x="{p["x"]+dx}" y="{p["y"]+dy}" text-anchor="{anc}">{t}</text>')
    return frame("Chinese OEM plants and service bases in India, Indonesia and Thailand, by opening or ground-breaking date, 2007–September 2026",
                 svg(W, H, "Map of ten Chinese OEM sites: four in India, four in Indonesia, two in Thailand; five are new since November 2025.", ''.join(g)),
                 "Company releases and media [21, 24–32, 124]; map: Natural Earth via world-atlas; YCP analysis.",
                 "Ten sites. New since November 2025: Heli Rayong, Hangcha Chonburi, LiuGong Karawang, XCMG Weda Bay, XCMG Balikpapan. LiuGong Pithampur is an expansion of an existing plant. Positions approximate.",
                 '<span><i class="ksite knew"></i>Opened or started since Nov 2025</span><span><i class="ksite kold"></i>Earlier</span><span><i class="ksq kblue"></i>Square: service and remanufacturing base</span>')

# ---------------- Chapter 8 ----------------
def ex_tkdn():
    d = [("Komatsu PC200", 51.21, "most listings"), ("Hitachi ZX200", 39.35, "most listings"), ("SANY SY215C", None, "no score shown; 9 of 15 listings labelled imported"), ("XCMG XE215", None, "no score shown"), ("Kobelco SK200", None, "no score shown"), ("Caterpillar 320", None, "no score shown")]
    W, L, R, T, rh = 700, 150, 660, 34, 36
    H = T + rh * len(d) + 30
    x = lambda v: L + (R - L) * v / 60
    g = []
    for v in (0, 20, 40, 60):
        g.append(f'<line class="grid" x1="{x(v):.1f}" x2="{x(v):.1f}" y1="{T-4}" y2="{H-26}"/><text class="tick" x="{x(v):.1f}" y="{H-10}" text-anchor="middle">{v}%</text>')
    for i, (n, v, note) in enumerate(d):
        yy = T + rh * i + rh / 2
        g.append(f'<g class="row"><title>{n}: {("TKDN " + str(v) + "%") if v else "no local-content score shown"}</title><text class="lab-hi" x="{L-10}" y="{yy+4:.1f}" text-anchor="end">{n}</text>')
        if v:
            g.append(f'<rect class="{"bar-hi" if v >= 40 else "bar"}" x="{L}" y="{yy-10:.1f}" width="{x(v)-L:.1f}" height="20" rx="3"/><text class="val" x="{x(v)+8:.1f}" y="{yy+4:.1f}">{v}%</text>')
        else:
            g.append(f'<text class="annot" x="{L+6}" y="{yy+4:.1f}">{E(note)}</text>')
        g.append('</g>')
    g.append(f'<line class="ref" x1="{x(40):.1f}" x2="{x(40):.1f}" y1="{T-16}" y2="{H-26}"/><text class="callout" x="{x(40)-6:.1f}" y="{T-8}" text-anchor="end">Above 40%, government buyers must choose the domestic product</text>')
    return frame("Local-content (TKDN) scores shown for 20–22 tonne excavators on Indonesia's public e-catalogue, September 2026 (%)",
                 svg(W, H, "Bars of TKDN local-content scores: Komatsu 51.21%, above the 40% threshold; Hitachi 39.35%; SANY, XCMG, Kobelco and Caterpillar show no score.", ''.join(g)),
                 "LKPP INAPROC e-Katalog [117]; Kementerian Perindustrian [33]; YCP analysis.",
                 "Combined TKDN plus company-benefit score as listed. Investing in a local plant now earns a 25% credit towards the score.")

# ---------------- Chapter 9 ----------------
def ex_battery():
    d = [("China", 84, True), ("Global average", 108, False), ("North America", 121, False), ("Europe", 131, False)]
    W, L, R, T, rh = 700, 140, 560, 16, 40
    H = T + rh * len(d) + 30
    x = lambda v: L + (R - L) * v / 150
    g = []
    for v in (0, 50, 100, 150):
        g.append(f'<line class="grid" x1="{x(v):.1f}" x2="{x(v):.1f}" y1="{T}" y2="{H-26}"/><text class="tick" x="{x(v):.1f}" y="{H-10}" text-anchor="middle">US${v}</text>')
    for i, (n, v, hi) in enumerate(d):
        yy = T + rh * i + rh / 2
        extra = "" if hi or n == "Global average" else f"  +{round((v/84-1)*100)}%"
        g.append(f'<g class="row"><title>{n}: about US${v} per kWh</title><text class="lab-hi" x="{L-10}" y="{yy+4:.1f}" text-anchor="end">{n}</text><rect class="{"bar-hi" if hi else "bar"}" x="{L}" y="{yy-11:.1f}" width="{x(v)-L:.1f}" height="22" rx="3"/><text class="val" x="{x(v)+8:.1f}" y="{yy+4:.1f}">{v}{extra}</text></g>')
    return frame("Average lithium-ion battery pack price by region, 2025 (US$ per kWh)",
                 svg(W, H, "Bars of 2025 battery pack prices: China 84, global average 108, North America about 121, Europe about 131 US dollars per kilowatt-hour.", ''.join(g)),
                 "BloombergNEF, December 2025 [132]; YCP analysis.",
                 "North America and Europe are our calculation from BloombergNEF's statement that their prices were 44% and 56% higher than China's.")

# ---------------- Chapter 10 ----------------
def ex_crane():
    def panel(title, vals, labels, fmt, maxv, note, hi_last=True):
        W, H, T, B = 220, 190, 34, 150
        bw = 150 / len(vals) - 8
        g = [f'<text class="panel-t" x="6" y="16">{E(title)}</text>']
        for i, v in enumerate(vals):
            h = (B - T) * abs(v) / maxv
            bx = 20 + i * (bw + 8) + (150 - len(vals) * (bw + 8)) / 2 + 20
            cls = 'bar-hi' if (hi_last and i == len(vals) - 1) else 'bar'
            g.append(f'<g class="row"><title>{E(title)}: {labels[i]} {fmt(v)}</title><rect class="{cls}" x="{bx:.1f}" y="{B-h:.1f}" width="{bw:.1f}" height="{h:.1f}" rx="2"/><text class="val" x="{bx+bw/2:.1f}" y="{B-h-6:.1f}" text-anchor="middle">{fmt(v)}</text><text class="tick" x="{bx+bw/2:.1f}" y="{B+15}" text-anchor="middle">{labels[i]}</text></g>')
        g.append(f'<text class="annot" x="6" y="{H-6}">{E(note)}</text>')
        return f'<div class="sm">{svg(W, H, title, "".join(g))}</div>'
    ps = [panel("Imports from China, units", [163, 667, 949, 938], ["FY21", "FY22", "FY23", "FY24"], lambda v: f"{v:,}", 1000, "China: 99–100% of imports"),
          panel("Indian demand, index", [100, 488], ["FY21", "FY24"], lambda v: str(v), 500, "Demand nearly quintupled"),
          panel("Indian makers' share, index", [100, 17], ["FY21", "FY24"], lambda v: str(v), 110, "Lost five-sixths of share"),
          panel("Indian makers' loss per unit, index", [100, 981], ["FY21", "FY24"], lambda v: str(v), 1000, "Loss per unit up almost tenfold")]
    band = '<div class="crane-band"><b>0–10%</b><span>Chinese prices undercut Indian prices by only 0–10% (FY24)</span><b>3 years</b><span>Credit extended to related importers in India</span><b>24.9–52.0%</b><span>Duties recommended, not imposed</span></div>'
    return frame("India's anti-dumping case on Chinese crawler and truck cranes, FY21–FY24", f'<div class="smg">{"".join(ps)}</div>{band}',
                 "Directorate General of Trade Remedies, final findings, 19 September 2025 [14, 37]; YCP analysis.",
                 "FY24 is the period of investigation, April 2023 to March 2024. Loss per unit is shown as the size of the loss; the regulator indexes it from −100 to −981. Inventories rose from 100 to 400.")

def ex_waffle():
    cells = ['jcb'] * 49 + ['oth'] * 50 + ['liu']
    sq = ''.join(f'<i class="wf-{c}" title="{ {"jcb":"JCB","oth":"Other brands","liu":"LiuGong"}[c] }"></i>' for c in cells)
    body = f'<div class="waffle-wrap"><div class="waffle">{sq}</div><div class="wf-legend"><div><i class="wf-jcb"></i><b>JCB</b><span>34,632 machines, 49%</span></div><div><i class="wf-oth"></i><b>All other brands</b><span>35,534 machines, 50%</span></div><div><i class="wf-liu"></i><b>LiuGong</b><span>1,061 machines, 1.5%: the only Chinese brand listed</span></div><p class="wf-total">71,227 road-registered machines, FY26 (−11.7%)</p></div></div>'
    return frame("Retail registrations of road-registered construction equipment in India by brand, FY26 (each square = 1%)", body,
                 "FADA via TractorJunction Infra [140]; YCP analysis.",
                 "Road registrations cover mostly wheeled machines such as backhoe loaders; crawler excavators and cranes are not registered, so Chinese brands' main categories are not in this count.")

# ---------------- Chapter 11 ----------------
def ex_footprint():
    def row(name, sub, n, cls):
        dots = ''.join(f'<i class="{cls}"></i>' for _ in range(n))
        return f'<div class="fp-r"><div class="fp-l"><b>{E(name)}</b><span>{E(sub)}</span></div><div class="fp-d">{dots}</div><span class="fp-n">{n}</span></div>'
    body = ('<div class="fp-grp">United Tractors (Komatsu distributor)</div>' +
            row("Workshops and remanufacturing sites", "", 40, "fp-ut") + row("Warehouses", "", 117, "fp-ut2") + row("Parts distribution centres", "", 2, "fp-ut") +
            '<div class="fp-grp">Chinese brands\' distributors</div>' +
            row("SANY: PT Sany Perkasa branches", "14 in Kalimantan, 9 in Sulawesi", 44, "fp-cn") + row("XCMG: GM Tractors branches (2023)", "plus 2 service points in Kalimantan", 14, "fp-cn"))
    return frame("Service and branch footprint in Indonesia, United Tractors against the distributors of SANY and XCMG (sites)", f'<div class="fp">{body}</div>',
                 "United Tractors product support [118]; PT Sany Perkasa [92]; Media Indonesia [139]; YCP analysis.",
                 "Site types are not like-for-like: a branch usually combines sales, parts and service, while United Tractors lists workshops and warehouses separately. GM Tractors' count is from 2023.",
                 '<span><i class="fp-ut"></i>United Tractors</span><span><i class="fp-cn"></i>Chinese brands\' distributors</span>')

# ---------------- Chapter 12 ----------------
def ex_thai():
    d = [("Excavators", 34.5, 35.9, 39.8, 50.8), ("Forklifts", 38.6, 70.5, 37.8, 16.8), ("Cranes", 16.0, 53.8, 41.1, 43.3), ("Compressors", 20.9, 37.1, 45.0, 35.4), ("Pumps", 33.3, 53.4, 14.4, 4.5)]
    W, H, T, B = 150, 230, 30, 190
    y = lambda v: B - (B - T) * v / 80
    out = []
    for n, c0, c1, j0, j1 in d:
        win = "Japan leads" if j1 > c1 else "China leads"
        g = [f'<text class="panel-t" x="75" y="16" text-anchor="middle">{n}</text>']
        for v in (0, 40, 80):
            g.append(f'<line class="grid" x1="28" x2="122" y1="{y(v):.1f}" y2="{y(v):.1f}"/>')
        def sep(p, q):
            yp, yq = y(p), y(q)
            if abs(yp - yq) < 12:
                m = (yp + yq) / 2
                return (m - 6, m + 6) if yp < yq else (m + 6, m - 6)
            return yp, yq
        la = sep(c0, j0); lb = sep(c1, j1)
        for k, (a, b, cls, nm) in enumerate(((c0, c1, 'cn', 'China'), (j0, j1, 'jp', 'Japan'))):
            g.append(f'<g class="row"><title>Thailand {n.lower()}, {nm}: {a}% → {b}%</title><line class="sl-{cls}" x1="40" x2="110" y1="{y(a):.1f}" y2="{y(b):.1f}"/><circle class="f-{cls}" cx="40" cy="{y(a):.1f}" r="4"/><circle class="f-{cls}" cx="110" cy="{y(b):.1f}" r="5"/><text class="val-s" x="{34}" y="{la[k]+4:.1f}" text-anchor="end">{a:g}</text><text class="val-s" x="116" y="{lb[k]+4:.1f}">{b:g}</text></g>')
        g.append(f'<text class="tick" x="40" y="{B+16}" text-anchor="middle">2019</text><text class="tick" x="110" y="{B+16}" text-anchor="middle">2024</text>')
        g.append(f'<text class="{"sl-win-jp" if win=="Japan leads" else "sl-win-cn"}" x="75" y="{H-4}" text-anchor="middle">{win}</text>')
        out.append(f'<div class="sm5">{svg(W, H, f"Thailand {n}: China {c0} to {c1}, Japan {j0} to {j1}", "".join(g))}</div>')
    return frame("Share of Thailand's imports supplied by China and Japan, five equipment categories, 2019 and 2024 (%)", f'<div class="smg5">{"".join(out)}</div>',
                 "UN Comtrade via World Bank WITS, accessed 27 September 2026 [12, 38, 39, 68, 69]; YCP analysis.",
                 "In cranes China passed Japan while Japan's own share held; in excavators Japan gained.",
                 '<span><i class="kcn"></i>China</span><span><i class="kjp"></i>Japan</span>')

# ---------------- Chapter 14 ----------------
def ex_actions():
    R = [("Global incumbents", [("Aim captive finance at first-time buyers", "2"), ("Publish uptime and resale evidence", "3")],
                               [("Earn more from parts, service and remanufacturing", "3"), ("Defend or exit thin segments deliberately", "1"), ("Qualify for local-content scores", "5")],
                               [("Run Asian plants as export hubs", "4"), ("Launch electric ranges before adoption", "6")]),
         ("Indian and ASEAN champions", [("Use Press Note 2 to take Chinese technology on own terms", "5"), ("Set up brand finance with lenders", "2")],
                               [("Pick niches global players under-serve", "1"), ("Build service before volume", "3"), ("Offer JV and contract capacity", "4")],
                               [("Localise battery-pack assembly", "6")]),
         ("Dealers", [("Add a challenger brand where entrants land", "1"), ("List products on public e-catalogues", "5")],
                     [("Sell parts, service and trade-in as a bundle", "3"), ("Site service near the new plants", "4")],
                     [("Build electric-fleet service", "6")]),
         ("Financiers", [("Build residual-value data by brand", "3"), ("Price Chinese-brand credit risk explicitly", "2")],
                        [("Finance lifecycle bundles, not machines alone", "3")],
                        [("Offer electric-fleet finance with battery-risk cover", "6")]),
         ("Chinese OEMs", [("Keep related-party credit terms transparent", "2"), ("Plan for trade remedies", "2")],
                          [("Build parts depth before dealer count", "1"), ("Invest early in remanufacturing", "3")],
                          [("Site plants as export bases and tariff insurance", "4"), ("Lead with electric where switching costs are lowest", "6")]),
         ("Policymakers", [("Monitor credit quality in equipment finance", "2"), ("Watch concentration in niche categories", "1")],
                          [("Tie incentives to exports and local suppliers", "4"), ("Encourage used-price transparency", "3")],
                          [("Align standards and charging for electric equipment", "6")])]
    def cell(items):
        return '<div class="am-c">' + ''.join(f'<div class="am-i"><span class="am-t">L{l}</span>{E(t)}</div>' for t, l in items) + '</div>'
    rows = ''.join(f'<div class="am-r"><div class="am-h">{E(n)}</div>{cell(a)}{cell(b)}{cell(c)}</div>' for n, a, b, c in R)
    body = f'<div class="amx"><div class="am-r am-hd"><div></div><div>Next 12 months</div><div>12–36 months</div><div>To 2030</div></div>{rows}</div>'
    return frame("Actions for six reader types by time horizon, with the learning each follows from", body,
                 "YCP analysis, drawn from Chapter 14 of the draft.",
                 "Horizons are proposed and will be confirmed in the Chapter 14 rewrite (Step 7). L1–L6 refer to the six learnings.",
                 '<span><span class="am-t">L2</span> = follows from Learning 2</span>')

# ---------------- Chapter 15 ----------------
def ex_signposts():
    S = [("r", "India's next trade-remedy decision on Chinese capital goods", "Crane duties recommended Sep 2025, not imposed", "Any duty imposed on a Chinese capital good", "Policy fragments the market", "DGTR, Finance Ministry notices"),
         ("r", "First Press Note 2 approvals in capital goods", "Rules in force since March 2026", "First approved minority Chinese investment", "Chinese share consolidates through partnership", "Government announcements"),
         ("r", "US excess-capacity Section 301 outcome", "Investigation open since March 2026; no tariffs by August", "Tariffs that name plants in the five markets", "Policy fragments the market", "USTR, Federal Register"),
         ("a", "EU–India trade agreement", "Sent to the Council for signature, 11 Sep 2026", "Entry into force", "European OEMs' costs of serving India fall", "European Commission"),
         ("r", "Finance licences for equipment makers in Indonesia", "One OEM-owned licence (SANY) and one dealer joint venture (XCMG)", "A second OEM-owned licence", "Chinese share consolidates", "OJK announcements"),
         ("r", "United Tractors and Hexindo market shares", "Komatsu 17% (Jan–Apr 2026); Hexindo targets 18%", "Komatsu back above 25% for two quarters", "Incumbents counter-attack", "Monthly company releases"),
         ("a", "Electric share of Chinese equipment exports", "135 of 73,295 excavators exported in H1 2026 were electric", "Electric above 5% of excavator exports", "Chinese lead extends to the next generation", "CCMA, ICCT, company reports"),
         ("r", "Indonesia's coal production quota", "2026 output expected at about 720 Mt, down 12%", "2027 quota above the 2026 level", "Cycle turns: mining fleet demand returns", "Energy ministry RKAB")]
    lab = {"r": "Within 12 months", "a": "1–3 years", "g": "Beyond 3 years"}
    t = []
    for i, (s, n, cur, thr, path, src) in enumerate(S, 1):
        t.append(f'<div class="sp sp-{s}"><div class="sp-top"><span class="sp-n">{i}</span><span class="sp-s">{lab[s]}</span></div><b>{E(n)}</b>'
                 f'<div class="sp-k"><em>Now</em>{E(cur)}</div><div class="sp-k"><em>Threshold</em>{E(thr)}</div><div class="sp-k"><em>Would signal</em>{E(path)}</div><div class="sp-src">{E(src)}</div></div>')
    return frame("Eight signposts to 2030: current reading, threshold and expected timing, as of September 2026", f'<div class="sps">{"".join(t)}</div>',
                 "Sources as cited in Chapter 15 [14, 23, 34, 37, 53, 59, 60, 65, 81, 83, 88]; YCP analysis.",
                 "Thresholds are proposed and will be set in the Chapter 15 rewrite (Step 7). Colour shows when the signpost is likely to resolve: red within 12 months, amber in one to three years.",
                 '<span><i class="ksq sp-kr"></i>Likely to resolve within 12 months</span><span><i class="ksq sp-ka"></i>1–3 years</span>')

# ---------------- assemble in paper order ----------------
X = [
 (1, "About this paper", "flow", "The paper answers one question in four parts", P['ex1'], "Existing Exhibit 1"),
 (2, "Part I opening", "part flow", "Part I asks whether the shift is real, where it happened and whether it will last", X2, "New"),
 (3, "Chapter 1", "", "China's excavator makers now sell almost as many machines abroad as at home", ex_sales(), "New"),
 (4, "Chapter 1", "", "The leading Chinese makers earn around half or more of their revenue abroad", ex_overseas(), "New"),
 (5, "Chapter 1", "", "Six policy events in 2026 opened access and three raised barriers", ex_policy(), "New"),
 (6, "Chapter 2", "", "China's share of imports rose in 18 of 19 country–category pairs and now exceeds half in 12", P['ex2'], "Existing Exhibit 2"),
 (7, "Chapter 2", "", "Indonesia's market grew while Komatsu's units fell", ex_komatsu(), "New"),
 (8, "Chapter 3", "", "The shift passes the first three tests in both main markets", ex_scorecard(), "New"),
 (9, "Part II opening", "part flow", "Six moves redesign the commercial system around the machine", X9, "New"),
 (10, "Part II opening", "flow", "India and Indonesia show all six learnings; Thailand shows mainly plants and electrification", P['ex3'], "Existing Exhibit 3"),
 (11, "Chapter 5", "", "SANY moved from lender partner to licensed finance company in nine years", ex_ladder(), "New"),
 (12, "Chapter 6", "", "Chinese excavators are priced within the incumbents' range, not below it", ex_prices(), "New"),
 (13, "Chapter 6", "", "Parts and service held up while machine sales fell by more than a third", ex_ut(), "New"),
 (14, "Chapter 7", "", "Chinese makers now have ten plant and service sites in these markets, five of them started since November 2025", ex_map(), "New"),
 (15, "Chapter 8", "", "Komatsu clears Indonesia's 40% local-content bar; Chinese brands show no score yet", ex_tkdn(), "New"),
 (16, "Chapter 9", "", "Battery packs cost about a third less in China than in North America and Europe", ex_battery(), "New"),
 (17, "End of Part II", "", "Plants and lender partnerships came first; owned finance, remanufacturing and electric plants arrived in 2025–26", P['ex4'], "Existing Exhibit 4"),
 (18, "Part III opening", "part flow", "Each market answers a different question about the playbook", X18, "New"),
 (19, "Part III opening", "", "The same playbook produced five different outcomes", P['ex5'], "Existing Exhibit 5"),
 (20, "Chapter 10", "", "India's crane makers lost the market to imports priced only 0–10% below theirs", ex_crane(), "New"),
 (21, "Chapter 10", "", "In India's largest, wheeled segment, Chinese brands have barely arrived", ex_waffle(), "New"),
 (22, "Chapter 11", "", "Chinese distributors in Indonesia are wide but not yet as deep as United Tractors", ex_footprint(), "New"),
 (23, "Chapter 12", "", "In Thailand, China won four categories and lost excavators", ex_thai(), "New"),
 (24, "Part IV opening", "part flow", "Part IV moves from where the playbook breaks to what to do and what to watch", X24, "New"),
 (25, "Chapter 13", "", "Each way the playbook breaks has an early-warning sign and a reader who can act", P['ex6'], "Existing Exhibit 6"),
 (26, "Chapter 14", "", "Every reader has a first move in the next 12 months", ex_actions(), "New"),
 (27, "Chapter 15", "", "Six of the eight signposts are likely to move within a year", ex_signposts(), "New"),
]
json.dump([list(x) for x in X], open('/home/claude/build/all.json', 'w'))
print(len(X))
