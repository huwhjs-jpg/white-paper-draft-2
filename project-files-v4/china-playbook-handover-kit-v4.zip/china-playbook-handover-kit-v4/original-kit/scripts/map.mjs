import fs from 'fs';
import {geoMercator, geoPath} from 'd3-geo';
import {feature} from 'topojson-client';
const topo = JSON.parse(fs.readFileSync('node_modules/world-atlas/countries-50m.json'));
const countries = feature(topo, topo.objects.countries).features;
const W=760,H=420;
const proj = geoMercator().fitExtent([[10,10],[W-10,H-10]], {type:'MultiPoint',coordinates:[[67,-11.5],[131,31]]}); proj.clipExtent([[0,0],[W,H]]);
const path = geoPath(proj);
const focus = {'356':'India','360':'Indonesia','764':'Thailand'};
let out = '';
for (const f of countries) {
  const d = path(f); if (!d) continue;
  // skip features fully outside the frame
  const b = path.bounds(f); if (b[1][0] < 0 || b[0][0] > W || b[1][1] < 0 || b[0][1] > H) continue;
  const cls = focus[f.id] ? 'land-f' : 'land';
  out += `<path class="${cls}" d="${d.replace(/\.\d+/g,"")}"/>`;
}
const sites = [
 ['SANY, Chakan (Pune)',18.76,73.86,'plant','old','2007'],
 ['Zoomlion, Khed City (Pune)',18.85,73.90,'plant','old','2024'],
 ['XCMG, Chennai',12.97,79.95,'plant','old','2021'],
 ['LiuGong, Pithampur (expansion)',22.61,75.68,'plant','old','Jul 2026'],
 ['SANY, Karawang',-6.32,107.28,'plant','old','2023'],
 ['LiuGong, Karawang',-6.36,107.36,'plant','new','Jul 2026'],
 ['XCMG, Weda Bay',0.46,127.93,'plant','new','Jul 2026'],
 ['XCMG, Balikpapan remanufacturing',-1.24,116.85,'service','new','Sep 2026'],
 ['Hangcha, Chonburi',13.36,101.00,'plant','new','Jun 2026'],
 ['Heli, Rayong',12.90,101.30,'plant','new','Nov 2025'],
];
const pts = sites.map(s=>{const [x,y]=proj([s[2],s[1]]);return {name:s[0],x:+x.toFixed(1),y:+y.toFixed(1),type:s[3],age:s[4],date:s[5]}});
const lab = {'356':proj([78.5,24.5]),'360':proj([114,-3.5]),'764':proj([100.2,16.5])};
fs.writeFileSync('map.json', JSON.stringify({W,H,paths:out,pts,lab}));
console.log(out.length, pts);
