# China Playbook upgrade: handover brief

Written 29 September 2026, at the end of the first working chat. The next chat needs this brief, the assembly source and the handover kit, and nothing else.

---

## 0. How to start the next chat

1. Open a new chat inside the **Chinese Learnings** Project.
2. Attach **`china-playbook-handover-kit.zip`** (downloaded from the first chat).
3. Paste this prompt:

> We are continuing the upgrade of "The China Playbook for Emerging Asia". Read the Project doc `claude/China Playbook — Handover Brief (29 Sep 2026).md` in full first. Then read `claude/China Playbook — Assembly Source v1.html`. The attached zip is the handover kit, and its README explains it. Settle the open decisions in section 8 with me, then assemble the Word draft as described in section 10, and then run the Step 9 checks. Do not rewrite the approved text except where a decision or fix in the brief requires it.

---

## 1. Where everything lives

### Project docs (already in the Project)

| Doc | What it is | Status |
|---|---|---|
| `China_Playbook_Paper.docx` | The original draft (about 18,400 body words) | Superseded by the steps below |
| `china-playbook-lessons-from-past-white-papers.md` | Benchmark from 16 past YCP papers | Reference |
| `pdf-gap-fill-supplement.md` | Visual identity and exhibit rules | Reference |
| `claude/China Playbook — Draft Audit (28 Sep 2026).html` | Audit and gap assessment, with the plan | Done |
| `claude/China Playbook — Step 1 Accuracy Fixes and Decisions.html` | Fixes F1–F13 and decisions D1–D6 | Approved |
| `claude/China Playbook — Step 2 Spine Rewrite.html` | Executive summary, About this paper, Chapter 1 central question, Conclusion | Approved |
| `claude/China Playbook — Step 3 First Six Exhibits.html` | The first six exhibits, as tables | Superseded by the chooser |
| `claude/China Playbook — Step 3 Exhibit Redesign (A vs B).html` | Table versus visual versions, and 17 suggestions | Superseded by the chooser |
| `claude/China Playbook — Step 3 Full Exhibit Set (27).html` | All 27 built exhibits | Source images are in the kit |
| `claude/China Playbook — Step 4 Part I Rewrite.html` | Chapters 1–3 | Approved |
| `claude/China Playbook — Step 5 Part II Rewrite.html` | Chapters 4–9 and the box | Approved |
| `claude/China Playbook — Step 6 Part III Rewrite.html` | Chapters 10–12 | Approved |
| `claude/China Playbook — Step 7 Part IV Rewrite.html` | Chapters 13–15 | Approved |
| `claude/China Playbook — Step 8 Front and Back Matter.html` | Cover, contents, About YCP, Appendix A, glossary, reference audit | Waiting on the firm's inputs (section 9) |
| `claude/China Playbook — Assembly Source v1.html` | **All approved text in paper order**, with exhibit slots replaced by the picked exhibits, numbered 1–31 | **Main source for assembly** |
| `claude/China Playbook — Handover Brief (29 Sep 2026).md` | This brief | — |

### Published pages

The next chat can open these with the Artifact tool's `read` action.

| Page | Link |
|---|---|
| Audit | https://claude.ai/artifact/6EsijcwYFFhGcUYsu8Krog |
| Step 1 | https://claude.ai/artifact/SZsRX7PqVZhbwYEj8oBWvB |
| Step 2 | https://claude.ai/artifact/JvLcVQLsnWcyhVU45nJ5GP |
| Step 3, first six | https://claude.ai/artifact/JrtXKcycH8G3cvHy1sNcPn |
| Step 3, A vs B | https://claude.ai/artifact/2FxmsWtbUkgibPiyvW8N5X |
| Combined exhibit page (superseded; confusing) | https://claude.ai/artifact/Y7BtnMfYV7nkQNLuQZBh7T |
| Step 4 | https://claude.ai/artifact/Wtg8FiAENYAFhbhRuPmzw9 |
| Step 5 | https://claude.ai/artifact/8CwRWA2AMxJFMtptesYLve |
| Step 6 | https://claude.ai/artifact/9UdA9EgN94y6fmsgUMSj2M |
| Step 7 | https://claude.ai/artifact/KPaxmj3Y9zy4bMNnUiLW94 |
| Step 8 | https://claude.ai/artifact/QtbNs33EBC1L5A8ETPKuVj |
| **Exhibit chooser** (the live picks) | https://claude.ai/artifact/7CV1Bn1xRaqsocmfRGjnJb |

**Reading the picks.** Use the ArtifactData tool:

```
action: get
url: https://claude.ai/artifact/7CV1Bn1xRaqsocmfRGjnJb
collection: choices
doc_id: current
```

A copy as of 29 September is in the kit at `data/exhibit-choices.json`. It matches my recommendations. **Re-read the live version before assembly**, because the user may change picks.

### Handover kit (the zip)

It is not in the Project. See `README.md` inside the zip.

- `exhibit-images/`: PNG renders at 2× of all 65 options.
  - `built-NN.png` and `built-NN-table-version.png`: built in the working chat.
  - `pack-*.png`: from the user's exhibit pack.
- `exhibit-source/`: the editable code for the 27 built exhibits.
  - `all.json`: HTML and SVG for each, with `css.json` for the styles.
  - `map.json`: projected map paths.
  - `built-exhibits-all-27.html`: opens in a browser.
- `pack-original/`: the pack's images, `pack.json` (captions, tables, notes and placement for 32 items), and the pack .docx.
- `text/`: the assembly source, every step page, and the raw body HTML of Parts I–IV.
- `data/`:
  - `refs.json`: all 157 draft references, which ones the new text cites, and which were dropped.
  - `refrows.json`, `exhibit_order.json`, `exhibit-choices.json`.
- `scripts/`: the Python and Node build scripts. They use absolute paths under `/home/claude/`, so fix the paths before re-running.

---

## 2. Decisions (locked)

| # | Decision |
|---|---|
| D1 | **Six reader types:** global incumbents; Indian and ASEAN champions; dealers; financiers; Chinese OEMs planning their next market; policymakers. Dealers and financiers are separate. |
| D2 | **50 body pages.** References are separate. The exhibit count is set by the chooser (31 at present). |
| D3 | **Three country chapters on one template:** India (10) and Indonesia (11) as deep dives; Thailand with Vietnam and Malaysia as comparators (12). |
| D4 | **Voice is "we" for judgements, never "you".** Chapter 14 addresses each reader group by name. The byline is ignored for now. |
| D5 | **Firm-focused, not author-focused.** No author bios. About YCP names four capabilities: market entry; channel and dealer design; qualification for local-content rules and incentives; partner search and M&A. |
| D6 | **"Our view" by category in Chapter 15, only where insightful and grounded in evidence.** |

### Governing thought

Chinese OEMs won share mainly by redesigning the commercial system around the machine, not by selling it cheaply, and most of their moves can be copied.

### Central question

Which of the moves that won Chinese OEMs share can be copied, by whom, and how fast?

### Six learnings (locked labels)

1. Enter through a narrow beachhead, then broaden.
2. Treat customer credit as part of the product.
3. Price just enough, then invest in the lifecycle.
4. Localise plants, then export from the host.
5. Turn local-content and investment rules into an advantage. Never "FDI rules".
6. Use electrification as the entry wedge.

### Six failure modes (plain names, Chapter 13)

- Buyers return where uptime matters.
- A loyal installed base holds.
- High share invites trade cases.
- Overseas acquisitions lose money.
- Dealer networks outgrow parts supply.
- Price wars at home drain cash.

### Chapter titles (final)

1. Why learn from Chinese OEMs now
2. Where the shift is happening
3. Structural or cyclical?
4. Learning 1: Enter through a narrow beachhead, then broaden
5. Learning 2: Treat customer credit as part of the product
6. Learning 3: Price just enough, then invest in the lifecycle
7. Learning 4: Localise plants, then export from the host
8. Learning 5: Turn local-content and investment rules into an advantage
9. Learning 6: Use electrification as the entry wedge
10. India: the full playbook meets pushback
11. Indonesia: the complete case
12. Thailand and the comparators
13. Where the playbook breaks
14. What each reader should do
15. Outlook to 2030 and signposts

Part II ends with "Box: Two supporting moves". The conclusion is titled "A playbook open to every firm".

---

## 3. Accuracy fixes (all applied in the approved text)

| # | Fix |
|---|---|
| F1 | India's crane anti-dumping duties were recommended on 19 Sep 2025 but **not imposed within the three months Rule 18(1) allows**, so they were not in force in Aug 2026. Never write "pending" or "still unnotified". Add a new reference: Rule 18(1), India Code. Counsel should check before print. |
| F2 | The 10% US tariff (India, Indonesia, Malaysia) and 12.5% (Thailand, Vietnam, China) come from the **forced-labour Section 301 action** (ref 67), in effect since 24 Jul 2026. |
| F3 | Learning 5 is "local-content and investment rules" everywhere. |
| F4 | The 0–10% crane price undercut was measured over April 2023–March 2024. |
| F5 | Absorbed into F1. |
| F6 | United Tractors' 2026 sales are given for one period, January–August: Komatsu 2,689 (−21%); large mining 436 (−49%). |
| F7 | Vietnam's forklift figures are 2023, the latest year available. |
| F8 | The combined Komatsu and Hitachi share is marked "indicative". |
| F9 | Parts and service is United Tractors' figure only: "+1% to Rp5.5tn, about 37%". It is told once, in Chapter 6. |
| F10 | "Korea's losses were steeper" is measured relative to Korea's starting share, not in percentage points. |
| F11 | Chapter 13 was rewritten with six named failure modes. |
| F12 | Indian currency in "INR" style. **Still to do:** US$ conversions on one FX date (28 Sep 2026) at assembly. |
| F13 | Caveat on the Vietnam 2019 excavator base (Japan and Korea both report 688 units). Check the 2020 base, and add a new reference: WITS Vietnam 2020. |

---

## 4. Word counts and balance

| Section | Draft | Rewritten |
|---|---|---|
| About this paper, executive summary, conclusion | 1,750 | 1,202 |
| Part I | 4,960 | 2,504 |
| Part II | 6,450 | 3,250 |
| Part III (including tables) | 3,360 | 2,208 |
| Part IV (including tables) | 1,900 | 1,972 |
| **Body** | **~18,400** | **11,136** |

Part IV plus the conclusion is about 20% of the body, which meets the benchmark's floor. At about 450–500 words a page, the text fills roughly 23–25 pages. With 31 exhibits, the body lands close to the 50-page target. Confirm this after the first Word build.

---

## 5. Exhibits as currently picked (31, numbered in paper order)

Key to sources: **Built** = made in the working chat (`exhibit-images/built-NN.png`). **Pack** = the user's exhibit pack (`exhibit-images/pack-*.png`).

| Ex. | Where | Pick | Title | Fix needed at assembly |
|---|---|---|---|---|
| 1 | About this paper | Pack B | Industries in scope | Colours |
| 2 | About this paper | Pack 1 | Paper architecture | "FDI rules" → "local-content and investment rules"; five → six reader types; Chapter 2 and 10 titles |
| 3 | Part I opener | Pack Part I flow | What changed, where, and is it real? | Chapter 2 title |
| 4 | Ch 1 | Pack 2 | Overseas revenue of Chinese OEMs, FY2025 | Colours. It is the only place ref 2 (SANY 64%) is cited. |
| 5 | Ch 1 | Built 3 | Excavator sales at home and abroad | Needs two new refs (China Daily 16 Jan 2022; SMM/CCMA 2024) |
| 6 | Ch 1 | Built 5 | 2026 policy reset | Crane wording per F1 |
| 7 | Ch 2 | Pack 4 | China's import share by country and category | Colours |
| 8 | Ch 2 | Pack 5 | China and Japan in excavator imports (Korea in table) | Colours (China/Japan) |
| 9 | Ch 2 | Pack 6 | Komatsu and Hitachi shares in Indonesia; implied market | F6 and F8 wording |
| 10 | Ch 2 | Pack 7 | Category maturity ladder | — |
| 11 | Ch 3 | Built 8 | Five tests scorecard | India "structural" vs "likely structural" (decision) |
| 12 | Part II opener | Pack Part II flow | How did they win, and what transfers? | L5 label |
| 13 | Part II opener | Built 10 | Evidence strength by learning and country | India "mixed channels" Weak → Moderate (decision) |
| 14 | Ch 5 | Built 11 | SANY's finance steps in Indonesia | — |
| 15 | Ch 6 | Built 12 | Asking prices by brand | **Duplicates the text** (see 6d) |
| 16 | Ch 6 | Built 13 | United Tractors revenue by source | — |
| 17 | Ch 7 | Built 14 | Map of ten plant and service sites | **Label collision:** "INDONESIA" overlaps the Balikpapan label. Capacities are not shown (see 6a). |
| 18 | Ch 8 | Built 15 | Local-content (TKDN) scores | Partly duplicates the text (see 6d) |
| 19 | Ch 9 | Pack 13 | Forklift import share by type | Colours; Vietnam 2023 (F7) |
| 20 | End of Part II | Built 17 | Moves over time | — |
| 21 | Part III opener | Pack Part III flow | Country by country | Chapter 10 title ("…meets pushback") |
| 22 | Part III opener | Built 19 | Five markets compared | — |
| 23 | Ch 10 | Built 21 | India registrations by segment | — |
| 24 | Ch 10 | Built 20 | Crane case panels | F1 and F4 wording |
| 25 | Ch 11 | Built 22 | Service footprint in Indonesia | Partly duplicates the text (see 6d) |
| 26 | Ch 12 | Pack 17 | Thailand, China vs Japan by category | Colours |
| 27 | Part IV opener | Pack Part IV flow | Where it breaks and what to do | Seven → six failure modes; five → six reader types; crane wording |
| 28 | Ch 13 | Built 25 | Failure-mode cards | — |
| 29 | Ch 14 | Built 26 | Actions by reader and horizon | — |
| 30 | Ch 15 | Built 27 | Signposts with thresholds and timing | Thresholds are proposals (decision) |
| 31 | Appendix C | Pack B1 | UN Comtrade values | — |

Totals: 17 built and 14 from the pack. Left empty: position 1 (beside the six learnings in the executive summary) and position 12 (five tests, which the scorecard already covers).

### Colour conflict

- **Pack:** China orange, Japan blue.
- **Built:** China blue (#0B6FD9), Japan amber (#C07A00). This pair passed the colour-vision check; dark-mode pair is #3383E0 / #B97A12.

The final paper needs one scheme, and the exhibits in the other scheme must be redrawn. See section 8.

---

## 6. What was cut, and what the exhibits must carry

This answers three questions:
1. What was cut from the text and is now carried by an exhibit, so that exhibit must stay?
2. What was removed without needing any exhibit?
3. Which exhibits add something without replacing any text?

### 6a. Cut from the text and carried only by an exhibit

**Keep these exhibits, or put the text back.**

| Content taken out of the text | Was in | Carried now by | If the exhibit is dropped |
|---|---|---|---|
| Overseas revenue shares for all six OEMs, growth rates, Asia–Oceania revenue; the executive summary's shares for Zoomlion, XCMG and LiuGong | Exec summary, Ch 1 | **Ex 4** (Pack 2; Built 4 is the alternative) | Figures for LiuGong, Hangcha, Heli and others disappear; ref 2 becomes uncited |
| Dated 2026 policy events; court history of the Section 122 surcharge (now one clause) | Ch 1 | **Ex 6** (Built 5; Pack 3 is the alternative, with more detail) | The 2026 calendar is lost |
| China's import shares, five countries × five categories | Ch 2 | **Ex 7** (Pack 4; Built 6 is the alternative) | Chapter 2's core evidence is lost. Chapter 10 also points here for India by category. |
| Excavator import values by country; Korea's shares | Ch 2 | **Ex 8** (Pack 5) | The Korea claim (F10) loses its numbers. Built 19 has no Korea. |
| Komatsu share and units by year; Hitachi by year; implied market size | Ch 2 (and the repeat in Ch 11) | **Ex 9** (Pack 6; Built 7 is the alternative) | The executive summary's 755-unit and 4,400-unit calculation loses its visible basis |
| Evidence-strength paragraph, country by country | Part II introduction | **Ex 13** (Built 10; Pack 10 is the alternative) | Only one sentence of the paragraph remains in the text |
| Dated list of June–September 2026 plant and finance moves | Ch 1 | **Ex 20** (Built 17), plus one paragraph in Ch 1 and details in Chapters 5–7 | Partly lost; the chapters keep the key dates |
| Plant capacities and dates in full | Ch 7 | **Ex 17** (Built 14) shows sites and dates. **Capacities appear only in Pack 12, which is not picked.** The text keeps one line per country, including XCMG Chennai's 8,500 a year and Heli Rayong's 10,000. | Pick Pack 12 as well if full capacities matter |
| How the paper is organised (list of chapters) | About this paper | The reader map table in the text, the contents list, and **Ex 2** (Pack 1) | The contents list covers it; the exhibit is useful but optional |

### 6b. Removed with no exhibit needed

**Cut outright** (judged non-essential or off-scope):

- Executive summary opener, "Five years ago…".
- About: the list of cases. The cases now appear where they are used.
- Zoomlion's 9,000 overseas staff, the KHL Yellow Table ranking, and Zoomlion's local hiring. XCMG's 80% local staff carries the point.
- Forklift sales and export totals, and ASEAN forklift export growth. Forklift detail stays in Ch 9.
- Komatsu's 2021 response of mid-priced machines. United Tractors' second-tier line carries the point.
- MNC Leasing's 2023 Karawang visit, and the exhibition and smelter quotes on ABC Multifinance.
- SANY India service engineers and 90-day checks, Tata Hitachi's extended warranty, and LiuGong iLink. These are cut to one sentence on service promises.
- Inovance's electric-vehicle powertrain plants, which are not equipment. **Open decision: restore?**
- India's reported US$1.2bn incentive for tunnel-boring machines. **Open decision: restore into Ch 10's policy section?**
- Chapter 10's full list of FY26 sales by category. The total and the domestic–export split remain.
- ACE's mobile-crane share claim.
- HINABI's 2023 and 2024 production figures. The 2025 figure is kept.
- Krungsri's breakdown of Chinese applications by sector.

**Told once instead of several times** (moved, nothing lost):

- Executive summary country paragraph → the verdict sentence; the detail is in Chapters 10–12.
- Efort and UK trade-remedy examples → Ch 13.
- Press Note 2 terms (the 10% beneficial-ownership route) → Ch 8, with one sentence in Ch 10.
- Crane case detail from Chapters 1, 3, 4 and 6 (dumping margins, credit terms, duty rates, indices, cost squeeze) → Ch 10. Those chapters keep the unit counts and the 0–10% gap.
- SANY's distributor branches in the nickel belt, and the ABC Multifinance quote → Chapters 5 and 11.
- ICEMA's causes of the FY26 slowdown → Ch 10.
- SANY Indonesia finance dates (told in Chapters 1, 5 and 11) → Ch 5 only.
- SANY India and Tata Hitachi dealer counts → Ch 4 and the Part II box.
- SANY India claims and Tata Hitachi's mining recovery (repeated from Ch 4) → one sentence in Ch 10.
- Thai Eastern Economic Corridor count, "zero-dollar" investment, and GM Tractors' branches → Chapters 12 and 11.
- United Tractors' parts and service +1% → Ch 6 only.
- India's import shares by category (repeated in Ch 10) → a pointer to Ch 2 and Ex 7.
- Chapter 11's repeat of the Komatsu series and the Chinese plant list → the snapshot table, Ch 2 and Ch 7.
- HS codes, the import-share definition and the four sectors' evidence descriptions → Appendix A.

### 6c. Exhibits that add without replacing any text

The text stands without these, so they can be dropped if pages run over. The exceptions are the four Part flows, which the user required.

| Ex | What it adds |
|---|---|
| 3, 12, 21, 27 | **Part flow diagrams, one per Part (required by the user).** They add navigation, not data. |
| 1 | Scope: the four equipment families and how far each has gone abroad |
| 2 | Paper architecture (partly replaces "How the paper is organised"; see 6a) |
| 5 | **New evidence:** China's excavator sales at home against exports, with the 2023 crossover. It needs two new references. |
| 10 | Category maturity ladder, summarising the sequence Chapter 2 ends on |
| 11 | Test-by-test marks. The text keeps its own verdict table by market, so the two complement each other. |
| 14 | SANY's finance staircase. Chapter 5 also tells the dates, so this reinforces rather than replaces. |
| 16 | United Tractors revenue by source over time. The text gives one number. |
| 19 | Forklift import share by type. The text gives the headline shares. |
| 22 | China against Japan in five markets |
| 23 | India registrations by segment: how little of the wheeled segment Chinese brands hold |
| 24 | Crane case in four panels. Chapter 10 remains the home of the case. |
| 26 | Thailand, all five categories, with the excavator exception |
| 28, 29 | Summaries of Chapters 13 and 14 (six failure cards; action matrix) |
| 30 | Signposts. It **adds expected timing**, which is not in the text; the text states the thresholds. |
| 31 | Raw UN Comtrade values behind every import-share figure |
| Built 16 (not picked) | Battery-pack prices. It is the easiest exhibit to drop and is currently dropped. |

### 6d. Tell each fact once: where text and exhibit repeat the same numbers

At assembly, trim the text to one sentence that points to the exhibit, or drop the exhibit.

- **Ex 15 (asking prices)**: Chapter 6 still lists every India price range and every Indonesian e-catalogue median. Recommendation: keep the exhibit and cut the text to "SANY's listings sit inside the incumbents' ranges in both markets (Exhibit 15)".
- **Ex 18 (TKDN)**: Chapter 8 gives the Komatsu PC200 listing scores. Keep one sentence.
- **Ex 25 (service footprint)**: Chapter 11 lists United Tractors' 40 workshops and 117 warehouses, and PT Sany Perkasa's 44 branches. Keep the headline comparison only.
- **Ex 9 and the Chapter 11 snapshot table**: both show Komatsu's share. This is acceptable because the snapshot is a summary row.

---

## 7. Differences between the pack and our decisions

These affect the picked pack exhibits.

| Pack says | We decided | Affected picks |
|---|---|---|
| Five reader types | Six | Ex 2, 27 |
| "FDI rules" (L5) | "Local-content and investment rules" | Ex 2, 12 |
| Crane duties "still unnotified" or "pending" | "Recommended but not imposed" (F1) | Search every picked pack item |
| Seven failure modes (trade remedies in India and abroad counted separately) | Six | Ex 27 |
| Old titles for Ch 2 ("…a map of Emerging Asia") and Ch 10 ("India: localise, then face trade defence") | New titles (section 2) | Ex 2, 3, 21 |
| China orange, Japan blue | China blue, Japan amber | All pack charts |

---

## 8. Open decisions for the user

Settle these first in the next chat.

1. **Colour scheme.** Keep the built scheme and redraw 14 pack exhibits, or keep the pack scheme and redraw 17 built ones. Check the house palette in `pdf-gap-fill-supplement.md` first. The built pair passed the colour-vision check.
2. **Failure-mode count.** Six (as in the rewritten Chapter 13 and Ex 28) or seven (as in the pack).
3. **India's grade for "mixed dealer channels"** in Ex 13: Weak or Moderate. Moderate is recommended, because the Part II box shows SANY India running mixed channels.
4. **India verdict:** "structural" or "likely structural". If it changes, update the Chapter 3 table, Ex 11 and the executive summary verdict sentence together.
5. **Restore either cut item?** India's US$1.2bn tunnel-boring-machine incentive (into Ch 10) and Inovance's plants.
6. **Add Pack 12 (plant capacities)** alongside the Ex 17 map?
7. **Signpost thresholds and action horizons.** The proposals are Komatsu above 25%, and electric above 5% of excavator exports. Adjust as needed.
8. **"Our view by category"** (Ch 15 table). This is the paper's firmest judgement and needs a close read.
9. **Partner-checks table** (Ch 14). The family-owned distributor row rests on YCP analysis, not evidence in the paper.
10. **Closing invitation in the conclusion.** Swap in the division's own wording for the four capabilities if available.
11. **Counsel's view on the crane-duty wording** before print.

---

## 9. Inputs only the firm can supply

- The house disclaimer text and the legal entity name.
- About YCP facts: the approved one-line description, the number of offices, how YCP describes its way of working, and a contact email or page.
- The publication month. The draft says September 2026, and the data are as of 28 September 2026.

---

## 10. Assembly spec (Step 8½) and final checks (Step 9)

### Build

1. Re-read the live picks from the chooser, and apply the decisions from section 8.
2. **Source text:** `claude/China Playbook — Assembly Source v1.html`, also at `text/china-playbook-assembly-source.html` in the kit. It holds all approved text in print order: cover and contents → executive summary → About this paper → Parts I–IV → conclusion → Appendix A → Appendix B → Appendix C → About YCP → references.
   - Keep the in-text tables: reader map, verdict table, snapshot tables, Vietnam and Malaysia comparators, partner checks, and "our view".
   - Keep the case boxes and the "In brief" panels.
3. **Output:** one Word file, since the original draft is .docx. Read the docx skill before building.
   - House fonts and styles per `pdf-gap-fill-supplement.md`.
   - Exhibit title as a message headline, a source line, and notes.
   - Page numbers and a real table of contents.
4. **Exhibits:**
   - Use the 2× PNGs in `exhibit-images/`, after the redraw fixes in section 5 and the single colour scheme.
   - Renumber 1–N in order of first appearance, and update every "(Exhibit N)" and "Chapter N" cross-reference.
   - Fix the label collision on the Ex 17 map.
   - Built exhibits can be edited from `exhibit-source/all.json` and `css.json`. Pack exhibits are redrawn from `pack.json` data and tables.
5. **References:**
   - Renumber by first citation, using `data/refs.json` for the draft-to-new mapping.
   - Add a "Used for" note to each entry.
   - Add the four new references: Rule 18(1); WITS Vietnam 2020; China Daily, 16 Jan 2022; SMM/CCMA 2024.
   - Swap in primary sources: **ref 86 first** (an AI-generated Sina page; replace with Estun's CNINFO annual report), then refs 3, 4 and 6 (company filings), 17 (United Tractors' own site), and 145 and 146. Add deep links for 23, 109 and 138.
   - Drop the 17 refs no longer cited, except 2, 16, 78 and 80 if their exhibits stay.
   - Exhibit source lines use the new numbers.
6. **FX:** convert INR and Rp figures to US$ at the 28 September 2026 rate where the benchmark calls for it, and state the rate in Appendix A.
7. Apply the section 6d trims.

### Step 9 checks

- Every number in the text against its reference and its exhibit.
- The benchmark checklist in `china-playbook-lessons-from-past-white-papers.md`.
- Page count against the 50-page target.
- Export to PDF, then compare the PDF text layer with the source text.
- Open the document and look at every exhibit page.
- For the final check, have a separate reviewer that has not seen the work read it.
