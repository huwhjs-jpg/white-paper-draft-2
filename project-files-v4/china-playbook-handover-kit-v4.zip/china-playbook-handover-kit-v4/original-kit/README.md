# China Playbook handover kit (29 Sep 2026)

Start with HANDOVER-BRIEF.md. The same brief is in the Project as
"claude/China Playbook — Handover Brief (29 Sep 2026).md".

| Folder | What it holds |
|---|---|
| HANDOVER-BRIEF.md | Decisions, fixes, the exhibit plan, what was cut and why, open decisions, and the assembly spec |
| text/china-playbook-assembly-source.html | All approved text in print order, with the 31 picked exhibits slotted and numbered. **This is the source for the Word build.** |
| text/china-playbook-step*.html | The review pages for Steps 1, 2 and 4–8, including change logs and "what moved where" tables |
| text/step4_body.html, step5_text.html, step6_text.html, step7_text.html | Raw body HTML for Parts I–IV |
| exhibit-images/ | PNG renders at 2× of every option. built-NN = made in the working chat; built-NN-table-version = the earlier table edition; pack-* = the user's exhibit pack |
| exhibit-source/ | Editable code for the 27 built exhibits: all.json (per exhibit: number, place, type, headline, HTML/SVG, notes), css.json, map.json (projected map), built-exhibits-all-27.html (opens in a browser) |
| pack-original/ | The user's exhibit pack: pack.json (captions, placement, type, images, tables, notes for 32 items), images/, and the pack .docx |
| data/refs.json | The 157 draft references, which ones the new text cites, and which were dropped |
| data/refrows.json | Rows for the reference tables |
| data/exhibit_order.json | The current exhibit numbering: [number, chooser position, option id, source, title] |
| data/exhibit-choices.json | The picks as read from the chooser on 29 Sep. Re-read the live version before assembly. |
| scripts/ | The build scripts. They use absolute paths under /home/claude/ (build/, upl/, chooser/), so adjust the paths before re-running |
