# China Playbook upgrade: handover brief v2

This brief was written on 1 October 2026 at the end of the second working chat (29 September to 1 October 2026). It supersedes nothing in the first brief, *China Playbook — Handover Brief (29 Sep 2026)*; it adds to it. Read v1 for the original decisions (D1–D6), the accuracy fixes (F1–F13), the exhibit history and the "what was cut" analysis.

**Where things stand, in one paragraph.** We settled the 11 open decisions, assembled and delivered Word draft v1 (62 pages; body 46) and started the Step 9 checks. The user then widened the scope with three additions and tightened the length:

- a dated timeline of the Chinese expansion with its turning points;
- an archetype-level extension to mid-level industrial products (compressors and pumps);
- an archetype-level extension to emerging automation (robotics and automation);
- a much shorter paper: **the chapters alone must fit in 20 pages**, with the executive summary, About page and appendices excluded from the count.

I proposed a four-chapter, 20-page structure and a research run then gathered evidence on the three new topics. **The next chat should agree the final structure with the user (section 6), then write the paper in the new structure.** Draft v1 is now the source of approved text and assets, not the final shape.

---

## 0. Files and where they are

| What | Where |
|---|---|
| This brief | Handover kit v2: `HANDOVER-BRIEF-v2.md`. A copy is in the Project as `claude/China Playbook — Handover Brief v2 (1 Oct 2026).md` |
| Brief v1 | Project: `claude/China Playbook — Handover Brief (29 Sep 2026).md`; also `original-kit/HANDOVER-BRIEF.md` in the kit |
| Approved text (assembly source) | Project: `claude/China Playbook — Assembly Source v1.html`; also `original-kit/text/china-playbook-assembly-source.html` |
| Research report on the three new topics | Kit: `research/evidence-upgrade-report-2026-10-01.md`. A copy is in the Project as `claude/China Playbook — Evidence Upgrade Research (1 Oct 2026).md` |
| Restructure proposal v2 (20 pages, 4 chapters) | Project: `claude/China Playbook — Restructure Proposal (1 Oct 2026).html`; kit: `restructure/`; published page https://claude.ai/artifact/9Qs4wZsjt6K6vtvYEYZySm |
| Word draft v1 and its PDF render | Kit: `draft/China_Playbook_Word_Draft_v1.docx` and `.pdf` |
| Build pipeline and data | Kit: `build/` (scripts, `data/*.json`, `ex/` with 28 rendered exhibits) |
| Fact-check results and reference research | Kit: `research/*.json` |
| Fonts used for rendering | Kit: `fonts/` (Selawik as a stand-in for Segoe UI; `fonts.conf` maps Palatino Linotype to TeX Gyre Pagella) |
| Original kit (text, data, exhibit source, scripts, pack.json) | Kit: `original-kit/`. The old exhibit PNGs are not included because they are superseded; they are in the first zip if needed |
| Exhibit chooser (live picks, 31) | https://claude.ai/artifact/7CV1Bn1xRaqsocmfRGjnJb (ArtifactData: collection `choices`, doc `current`). The picks did not change on 29 Sep. **The restructure means the exhibits will be re-picked.** |

---

## 1. Decisions settled on 29 September (section 8 of brief v1)

The user accepted every recommendation.

| # | Decision | Outcome |
|---|---|---|
| 1 | Colour scheme | **Built scheme:** China blue #0B6FD9, Japan amber #C07A00. All pack exhibits are redrawn in it |
| 2 | Failure modes | **Six** |
| 3 | India "mixed dealer channels" (old Ex 13) | **Moderate** |
| 4 | India verdict | **Structural.** Kept because India passes tests 1–3, and the paper's own rule says structural |
| 5 | Restore cut items | **Tunnel-boring-machine incentive restored** (ref 128, one sentence in the India policy section). **Inovance not restored** at the time; see the new evidence, where it returns only as a cautionary automation example |
| 6 | Pack 12 (plant capacities) | Not added. Moot after the restructure |
| 7 | Signpost thresholds | Kept: Komatsu above 25% for two quarters; electric above 5% of excavator exports |
| 8 | "Our view by category" | Approved, with one fix: the "(signpost 7)" pointer was dropped from the forklift row |
| 9 | Partner checks, family-distributor row | Evidence cell relabelled "YCP judgement; no case in this paper" |
| 10 | Closing invitation | Current wording kept |
| 11 | Crane-duty wording | Flagged for counsel with a Word comment in two places (Ch 1 and the India crane case) |

Firm-only inputs are still missing and stay as yellow placeholders: the disclaimer and legal entity, the About YCP facts, contact details, the office list and the publication month.

---

## 2. Work completed in draft v1 (reusable in the new structure)

### 2a. Text edits applied to the approved text (`build/edits.py`)

- **Decisions 5, 8 and 9**, as in section 1.
- **Section 6d trims** (tell each fact once):
  - Ch 6 price lists became one sentence pointing to the asking-price exhibit (refs 112–117 still cited).
  - Ch 8 TKDN became "Komatsu's PC200-class listings clear the 40% bar, and no SANY or XCMG listing in the class shows a score".
  - The Ch 11 service footprint became one headline comparison.
- **Every exhibit is now referenced in the text** with an "(Exhibit N)" pointer, as the benchmark checklist requires.
- **FX (F12): US$ equivalents at 28 September 2026 rates**, stated in Appendix A.2.

  | Currency | Rate | Basis |
  |---|---|---|
  | INR | 96.03 | Closing rate (PTI / Deccan Herald) |
  | IDR | Rp17,965 | Bank Indonesia JISDOR |
  | CNY | RMB6.7399 | PBOC central parity (Xinhua) |
  | THB | 33.52 | Late-afternoon rate (Reuters/LSEG via Business Recorder) |
  | MYR | RM4.0805 | 6 pm close (Bernama via Malay Mail) |

  Volvo's SDLG sale (SEK8bn) was left in the transaction currency. Conversions applied: INR 1,000 crore ≈ US$104m; INR 500 crore ≈ US$52m; INR 272 crore ≈ US$28m; Rp15.0tn ≈ US$835m; Rp5.5tn ≈ US$306m; RMB1.45bn ≈ US$215m; RMB154.8m ≈ US$23m; RMB497m ≈ US$74m; THB100,000 ≈ US$3,000; THB400,000 ≈ US$12,000; THB172.1bn ≈ US$5.1bn; THB200m ≈ US$6m; RM426.7bn ≈ US$105bn.
- **ELGi "is launching a low-cost screw-compressor range" was kept.** Ref 147 (Q1 FY27 call, Aug 2026) confirms first orders and a formal launch in August/September 2026.

### 2b. Exhibits (`build/exspec.py`, `build/pack_ex.py`, `build/render_ex.py`)

- **All 31 exhibits use one scheme.** Eleven pack exhibits were redrawn from data recomputed from the pack's UN Comtrade table (B1). Every share in the text reconciled; China's share rose in 18 of 19 country–category pairs. Pack B, Pack 7 and B1 became native Word tables, and "Inovance filings" was removed from Pack B.
- **Fixes to the built exhibits:**
  - Ex 13: India's mixed-channels grade changed to Moderate.
  - Ex 17 map: the INDONESIA, THAILAND and INDIA labels moved and the Balikpapan label was flipped, so no labels collide.
  - Ex 29: the stray incumbent action "L5 Qualify for local-content scores" was removed and the tags fixed to match Ch 14 (L2, L3; L4, L5).
  - Stale notes ("Provisional… Step 4", "Thresholds are proposed… Step 7", "Version A", "drawn from Chapter 14 of the draft") were removed.
- **Pack exhibits now carry message headlines** (claim titles) as well as descriptive titles.
- **Source lines and notes sit in Word text below each image**, not inside the images. Reference numbers in them use the new numbering.

### 2c. References (`build/refs.py`, `build/refs_final.py`, `build/data/refs_final.json`)

- **147 references, numbered by first citation** across text and exhibit source lines.
  - Refs 2, 16, 78 and 80 were kept because their exhibits stay; 128 was restored.
  - The 12 others dropped: 48, 54, 55, 87, 91, 105, 107, 122, 134, 143, 148, 156. Ref 146 was merged into 145.
- **New references:**
  - Rule 18(1) of India's anti-dumping rules (India Code link found but **not opened; verify**).
  - China Daily, 16 Jan 2022.
  - SMM, 9 Jan 2025 (CCMA 2024 figures).
  - WITS Vietnam 2020, merged into ref 75 as the assembly source said. The 2020 base confirms the pattern: Japan 46.9%, Korea 40.1%, China 2.4%.
- **Primary-source upgrades** (URLs in `research/ref_upgrades.json`):
  - Estun 2025 annual report on CNINFO (all four figures confirmed).
  - Zoomlion, XCMG and LiuGong 2025 annual reports on CNINFO (figures confirmed). XCMG's new-energy +23.6% is from its 13 May 2026 investor-relations record, which is now added to ref 4.
  - United Tractors' own release (Komatsu 20% in 2025).
  - ELGi's own Q3 FY26 transcript (12 Feb 2026; "25 to 30% of the market… in volume terms").
  - The direct OJK announcement link (decision KEP-56/D.06/2026 dated 14 Sep 2026, announced 16 Sep).
  - Trakindo at a glance (Caterpillar dealer; acquired CSUL in 1995).
  - The SANY India Thiruvarur COCO outlet page (opened 6 Feb 2026).
- **Every reference has a "Used for" note** (`research/usedfor.json`, with overrides in `refs_final.py`).

### 2d. Word build (`build/build_docx.js`, `build/post.py`, `build/build.sh`)

- **Format:** A4, house fonts (Palatino Linotype headings, Segoe UI body), navy/YCP-blue palette.
- **Page furniture:** a running header between thin rules, and a royal-blue page tab with "ycp.com" in the footer.
- **Blocks:** In-brief panels, case boxes, failure-mode blocks and action lists with horizon chips.
- **Contents page:** a real TOC field wrapping cached entries whose page numbers come from a two-pass build. Word may reflow with the real fonts; right-click and choose Update Field.
- **Status:** two counsel comments; yellow placeholders. It passed schema validation.
- **Length:** 62 pages in total; body 46 (exec summary on p3 to conclusion on p48).

---

## 3. Step 9 checks: status at handover

- **Fact-check against sources: 1 of 3 batches done** (`research/check_2.json`): 44 claims, 37 ok, 4 partial, 3 unreachable. Batches 1 and 3 (`research/claims_1.json`, `claims_3.json`, 88 claims) did not run because the usage limit hit. Neither did the 24 WITS-based claims (`claims_wits.json`), which can be checked against B1 data offline.
- **Partials to fix in the rewrite:**
  1. MNC Leasing and SANY Perkasa signed an **MoU** in Dec 2017, not a financing agreement. The iNews sources do not call SANY Perkasa "SANY's distributor", so source that description or drop it.
  2. India crane case: DGTR treats the three-year related-party credit as an export-price adjustment. Its findings don't name it as a cause of injury, so soften "the damage came from… long credit".
  3. SANY Chakan: the INR 1,000 crore investment is dated to 2012 by the source. The 2007 MoU planned US$60m. "Exported about 1,200 machines in 2024" is a company-level figure, not a plant figure. Reword to "more than INR 1,000 crore invested".
  4. "XCMG's first Indonesian plant makes electric loaders": the source says Weda Bay is XCMG's **first overseas new-energy factory**. Reword.
- **Unreachable** (WebFetch quota): the asking-price pages (TractorJunction, Desimachines, INAPROC), the INAPROC TKDN listing and the GeM listing. Recheck.
- **Other flags:**
  - Highway pace: the text says "25 km a day in FY26", but the source (CareEdge, via ref 94 in draft numbering) headline says 21 km/day. Check exactly what it says for FY26.
  - The HINABI citation (draft ref 150, Feb 2025) is attached to a 2025 production figure. It probably no longer supports anything; consider dropping it.
- **Not yet started:** the PDF text-layer diff, a visual check of every exhibit page at full size, the benchmark checklist run and the independent reviewer read.
- **Do the remaining checks once, on the restructured paper**, not on v1.

---

## 4. The scope upgrade and constraints from the user (1 October)

1. Add a **timeline breakdown of the Chinese expansion, including a possible inflection point**.
2. Add an **archetype-level product-category expansion to mid-level industrial products**. The user chose **compressors and pumps only** (not valves, motors or bearings).
3. Add an **archetype-level expansion for emerging archetypes like robotics**. The user chose **robotics and automation**: industrial robots, cobots, warehouse robots and AMRs, servo and PLC.
4. **Length:** "the final length may be restricted to much below 50 pages", then "excluding executive summary, about page, appendix and stuff, [the body] will only be 20 pages."
5. **The Part flow diagrams are dropped** (user's instruction), though they were required in v1.
6. "Don't worry about the exhibits for now"; re-pick them once the structure is set.
7. The user is happy to work in batches to keep the output impeccable.
8. **Still unanswered:** whether I may correct accuracy points directly and log them, or should show each first. My default is to fix and log.

---

## 5. Restructure proposal v2 (pending the user's sign-off)

There are four chapters and no Parts, each answering one question in order.

| Chapter | Question | Pages | Words | Exhibits |
|---|---|---|---|---|
| 1. The shift: four phases, two turning points | How fast, where, will it last? | 4 | 1,400 | 3 |
| 2. The playbook: six moves that won share | Which moves, what transfers? | 6 | 2,500 | 2 |
| 3. The next categories: same playbook, different clocks | Compressors, pumps, robotics: will it work, how soon? | 4 | 1,500 | 3 |
| 4. The response: where it breaks, what to do, what to watch | By whom; signposts | 5 | 1,350 | 3 |
| Conclusion | | 1 | 250 | |

- **Linking framework:** four phases (Probe 2007–15; Beachheads 2016–20; Push 2021–24; Embed 2025–26) date the shift in Ch 1, become a clock for each product type in Ch 3, and set up the possible third turning point (2026–27), which frames the signposts in Ch 4.
- **Outside the 20 pages:**
  - Executive summary (1 page) and About this paper (1 page).
  - Appendix A: market profiles (India, Indonesia, Thailand with Vietnam and Malaysia; about 3 pages).
  - Appendix B: actions in full and partner checks.
  - Appendix C: method.
  - Appendix D: glossary.
  - Appendix E: Comtrade values.
  - References and About YCP.
- **Locked decisions this changes (all need sign-off):**
  - D2: 50 pages becomes 20.
  - D3: three country chapters become appendix profiles.
  - Fifteen chapter titles become four.
  - The central question gains "…and in which product categories next?"
  - The Part flows are dropped.
  - About 40% of the body text is condensed or moved, and each chapter is shown against the approved text.
- **Unchanged:** the governing thought, the six learning labels, the six reader types, the six failure modes and all accuracy fixes.

---

## 6. What the research found, and the recommended direction (the next chat starts here)

Full report: `research/evidence-upgrade-report-2026-10-01.md`. The headline findings:

1. **Turning point 1 is 2022 at firm level and 2023 in industry units.** SANY's overseas revenue share went from 23% (2021) to 45.7% (2022), and its overseas gross margin beat the domestic margin for the first time. Exports overtook domestic excavator sales in 2023.
2. **Turning point 2 (2025–26, from selling machines to owning the system) is supported.** Five dated plant, finance, remanufacturing and service moves fall in 2026 alone, against three in 2024 (hand-built count).
3. **Turning point 3 (2026–27 downturn test) has not happened yet.** Exports were still +33.5% in H1 2026. Indonesia shows early warnings: RKAB approvals are delayed and lenders are reluctant to lend without them. **Frame it as a signpost.**
4. **Compressors and pumps are "import-led, channel-light", at Beachheads moving into early Push.**
   - Shares are rising: Thailand pumps went from 33% to 53%, and India compressors from 44.4% in 2023 to 52.6% in 2024, so the rise came in one year.
   - Overseas revenue at Chinese makers is modest: Kaishan 45% (including geothermal), Hanbell about 19%, CNP 17%, Dongya 6%; Leo's international pumps are about 52% of its pump revenue.
   - Local footprints are thin and recent: CNP India 2005, Kaishan India 2019, Leo Indonesia 2023, Hanbell and CNP Vietnam service sites 2024.
   - Incumbents answer with **fighter brands** (ELGi Tier 4, Sep 2026), not credit or plants.
   - Credit is largely irrelevant; electrification becomes energy efficiency.
5. **Robotics is two archetypes.**
   - **Robot arms and servos are at Probe abroad.** Estun's overseas share fell, Efort made losses, and Inovance is about 6% overseas.
   - **Warehouse AMRs are born global.** Geek+ earned 75.3% of FY2025 revenue outside mainland China.
   - China became a net exporter of industrial robots only in 2025, with Asia (Vietnam, Thailand, India) as the main destination.
   - "Follow the home customer" is plausible, but the evidence is only indirect.
6. **The new storyline: "same moves, different order".** In the next categories, price and channel come first and the commercial system follows years later. **That gap is the incumbents' window.**
7. **Recommended structure** (the research's verdict): keep 20 pages and four chapters, but re-weight them.
   - Ch 1, 3 pp: two turning points and one test ahead.
   - Ch 2, 6 pp: unchanged.
   - Ch 3, 5 pp: "same moves, different order".
     - Heavy equipment as the reference (0.5 pp)
     - Forklifts as the bridge (0.5 pp)
     - Compressors and pumps (2 pp)
     - Robotics as a forward look led by AMRs (1.5 pp)
     - Clocks to 2030 (0.5 pp)
   - Ch 4, 5 pp: add fighter brands, and the uptime and installed-base defence (the Thai counter-case).
   - Conclusion, 1 p.
8. **Suggested central question:** "Which of the moves that won Chinese OEMs share can be copied, by whom, and how long is the window before the system follows the price in each category?" This is an alternative to the v2 wording ("…and in which product categories next?"). **The user must choose.**
9. **Suggested body exhibits (11):**
   1. Excavators, domestic and export
   2. Overseas revenue share over time
   3. Import-share heat map
   4. Indonesian excavators, China against Japan
   5. Dated moves by year
   6. The credit stack
   7. The Thai counter-case
   8. Compressors and pumps share and footprint
   9. Robots' home share against exports, plus Geek+'s geography
   10. The clocks matrix
   11. Signposts dashboard
10. **Corrections the research makes to the existing text** (apply in the rewrite):
    1. Chinese suppliers' share of China's robot market is 55%, **down** from 57%.
    2. Turning point 1 moves to 2022 at firm level.
    3. India **rescinded the Omnibus Technical Regulation** (S.O. 239(E), 14 Jan 2026), which would have required BIS certification for pumps, compressors, cranes and construction equipment. The hermetic-compressor QCO remains. The current wording, "withdrew a planned certification rule", is broadly right; make it precise.
    4. India's compressor share rose mainly in 2024.
    5. Reconcile Indonesia's 2026 coal quota ("about 720 Mt" against the ministry's earlier signal of "below 700 Mt") with the final quota.
    6. Inovance is about 6% overseas and serves only as a cautionary example.
    7. ELGi's launch was confirmed.
    8. Label ELGi's "25–30%" as a company estimate. It is not comparable with HS 841480 unit shares.
11. **Data gaps:**
    - IFR figures for the four ASEAN markets
    - An HS 847950 series
    - India's 8-digit compressor lines
    - GeM and e-Katalog brand listings
    - Country-level revenue of Chinese pump and compressor makers
    - Aggregator destination figures (verify against China customs or CCMA before use)
    - Vendor-blog robot price gaps (do not use)

**My recommendation to put to the user:** adopt the research's re-weighted four-chapter structure, using the "same moves, different order" framing for Ch 3. The four-phase clock still works and gains the 2022 date. Then:

- update the restructure page to v3;
- get sign-off on the six locked-decision changes and the central-question wording;
- run a short, focused evidence top-up on the data gaps that matter for the new exhibits: an HS 847950 annual series for the five markets, annual HS 841370/841480 series for 2015–2024, and verification of the robot-export and excavator-destination figures from primary sources;
- write Ch 1 and Ch 3 first.

---

## 7. Open questions for the user

1. Approve the re-weighted four-chapter, 20-page structure and the six locked-decision changes?
2. Which central-question wording: the v2 version ("…and in which product categories next?") or the research version ("…how long is the window before the system follows the price in each category?")?
3. Robotics: a 1.5-page forward look led by AMRs (recommended), or a fuller section?
4. May I fix accuracy points directly and log them, or show each first?
5. Back-matter order: References before About YCP (the approved contents order, which v1 followed), or the brief v1 section 10 order?
6. Firm inputs: disclaimer and legal entity, About YCP facts, contact, office list, publication month. Optionally the house .dotx template, logo and cover photo.

---

## 8. Next steps, in batches

1. Agree the structure (section 7, questions 1–3) and publish the restructure page v3.
2. Evidence top-up for the new chapters, plus the remaining fact-check batches on text that survives.
3. Write Ch 1 and Ch 3, then Ch 2, Ch 4, the conclusion, the executive summary, About and the appendices. Show each against the approved text.
4. Re-pick and rebuild about 11 body exhibits plus the appendix exhibits. Reuse the rendered PNGs and sources in `build/` where possible.
5. Build Word draft v2. Run all of Step 9: numbers against references and exhibits, the benchmark checklist, the page count (20-page body), the PDF text-layer diff, a look at every exhibit page, and an independent reviewer.

---

## 9. Technical notes for rebuilding (to save time)

- **Unpack the kit to `/home/claude/build`** and the original kit to `/home/claude/kit/kit`. The scripts use those absolute paths (`/home/claude/build/...`, `/home/claude/kit/kit/...`).
- **Fonts:** copy `fonts/*.ttf` to `~/.fonts`, copy `fonts/fonts.conf` to `~/.config/fontconfig/fonts.conf`, then run `fc-cache -f`. This maps Palatino Linotype to TeX Gyre Pagella (preinstalled) and Segoe UI to Selawik, so renders match the house look.
- **Exhibits:**
  - Run `python3 render_ex.py`. It assembles `ex/all.html` from the built source (`original-kit/exhibit-source/all.json` plus `css.json`) and `pack_ex.py`, then screenshots it with Playwright at 860 px width and 2.5× scale.
  - Run `npm install @fontsource/ibm-plex-mono` in `build/` for the mono font.
  - Playwright is preinstalled; run node from `/home/claude/build`, where `node_modules` lives.
- **Text pipeline:** `parse.py` (assembly source to `doc_v1.json`), then `edits.py` (`doc_v2.json`), then `refs.py` and `refs_final.py`, then `prep_model.py` (`model.json`), then `bash build.sh <name> [toc.json]`. `build.sh` runs `build_docx.js`, then `post.py`, then the LibreOffice PDF render. `pages.py` reports section pages and writes `toc.json` for the second pass.
- **Gotchas found:**
  - docx-js spacing without `lineRule:'auto'` makes LibreOffice treat lines as exact and clip images. Always set `lineRule`.
  - docx-js highlight emits `w:highlightCs`, which fails schema validation; `post.py` strips it.
  - Empty spacer paragraphs after lists caused blank pages.
  - Exhibit images capped at 700 px tall.
- **Network:** ECB rate APIs are blocked from the shell; use WebSearch/WebFetch. GitHub raw works (Selawik came from there).
- **The fact-check agents hit the weekly usage limit** at about 44 claims. Run batches smaller, or check WITS claims offline against B1.
