# The China Playbook for Emerging Asia: Evidence Upgrade and Recommended Direction

Research run, 1 October 2026. Produced by a web research task in the chat of 29 Sep–1 Oct 2026. Treat as reference material: several figures come from secondary sources and are flagged for re-verification against primary sources before publication.

## Summary

The evidence supports the paper's governing thought for heavy equipment and forklifts, but not yet for compressors, pumps or robots. In those categories Chinese firms are still winning mainly on price and through distributors, with only thin local operations. The strongest storyline is "same moves, different order": Chinese OEMs win first on price and channel, and the commercial system follows years later. That gap is the window incumbents should use. Keep the four-chapter, 20-page structure, but rewrite Chapter 3 and cut robotics to a shorter forward-looking section led by warehouse robots (AMRs).

- **Turning points are real but need re-dating.**
  - At firm level the break came in 2022, not 2023. SANY's FY2022 release says overseas sales of RMB 36.571bn "accounted for 45 percent of SANY's total revenue, a significant jump from 23 percent the previous year" (45.7% in the annual report). Its overseas gross margin of 26.4% beat the 21.9% domestic margin for the first time.
  - 2023 is when exports overtook domestic sales in units.
  - Dated "ownership" moves (plants, finance, remanufacturing, service) cluster in 2024–26, which supports a 2025–26 second turning point.
  - The 2026–27 downturn test has not yet happened. Frame it as a signpost, not a finding.
- **Compressors and pumps are an "import-led, channel-light" archetype, at Beachheads moving into early Push.**
  - China's import share is rising: Thailand pumps went from 33.3% to 53.4% between 2019 and 2024.
  - Overseas revenue shares are modest: Kaishan 44.95% (including geothermal), Hanbell about 19%, CNP 17.19%, Dongya 5.69%.
  - Local footprints are only just appearing: Kaishan India in 2019, Leo in Indonesia in 2023, Hanbell and CNP service sites in Vietnam in 2024.
  - Incumbents' main response is a low-cost "fighter" range (ELGi, launch September 2026), not credit or plants.
- **Robotics is two archetypes; cover only one in depth.**
  - Robot arms come from home-market champions whose overseas position is weak or shrinking: Estun's overseas share fell from 34.16% to 29.92%, Efort lost money, and Inovance's overseas share is about 6%.
  - Warehouse AMRs are born global: Geek+'s FY2025 revenue outside mainland China was RMB 2,387.1m, 75.3% of the total.
  - China became a net exporter of industrial robots only in 2025 (customs). That is too recent for a full chapter, so give it 1.5 pages as a forward look.

## Key findings

### 1. The phases hold, but turning point 1 is 2022, and the phases differ by category

- **Turning point 1: 2021–22 at firm level, 2023 at industry unit level.**
  - China's domestic excavator sales fell from a record 292,864 in 2020 to 89,980 in 2023 (CCMA).
  - SANY's overseas revenue rose 47.2% to RMB 36.57bn in 2022, reaching 45.7% of revenue, up 22.3 points (SANY FY2022 results, April 2023).
  - SANY's overseas gross margin (26.4%) beat the domestic margin for the first time.
  - Asia-Australia was SANY's largest overseas region in 2022, at RMB 14.85bn (+41.1%).
- **Turning point 2 (2025–26): supported.** These are counts of dated plant, finance, remanufacturing and service moves in a hand-built timeline, not an exhaustive census.
  - 2026 has 5 such moves: Hangcha Chonburi, LiuGong Karawang, XCMG Weda Bay, OJK's licence for PT Sany Indonesia Finance, and XCMG Balikpapan remanufacturing.
  - 2024 has 3, and earlier years 1–2 a year.
- **Turning point 3 (2026–27): not yet observed.**
  - Excavator exports were still +33.5% in H1 2026 (73,295 units, CCMA).
  - Indonesian early warnings:
    - PAABI reported 2023 heavy-equipment sales of 18,123 units (−10.8%).
    - In April 2026 PAABI said sales would pick up only in H2 as RKAB mining work plans are approved (Jakarta Post, 9 Apr 2026).
    - Intraco Penta's director said financiers are reluctant to lend without RKAB approval, which is the mechanism that would test credit-led share.
- **The clocks differ by country.**
  - Thai excavators are the counter-example: China's share was flat at about 36% while Japan's rose from 39.8% to 50.8%, an uptime and installed-base effect.
  - Indonesian excavators and Indian cranes are the extreme cases of Chinese share gain.

### 2. Compressors and pumps: import-led, channel-light and price-first, with system moves just starting

**China's share of imports (WITS/UN Comtrade; shares and unit values are our calculations)**

| Market and product | China's share |
|---|---|
| India HS 841480 | 44.4% in 2023, then 52.6% in 2024; most of the rise came in one year |
| India HS 841370 | 35.5% in 2019, flat at about 35% through 2024 |
| Indonesia HS 841370 | 45.7% in 2023, 46.5% in 2024 |
| Thailand HS 841370 | 33.3% in 2019, 48.9% in 2023, 53.4% in 2024 |

- **Unit values cannot settle "price just enough" versus "low-end".** India's 2023 HS 841480 imports from China averaged about US$36 per item (11.19m items), against about US$1,500 per item from Germany (102,834 items). The gap is mostly product mix, so testing it needs India's 8-digit tariff lines.

**Company evidence (FY2024 filings)**

- **Kaishan:** overseas revenue RMB 1,903.4m, 44.95% of the total (compressors RMB 1.105bn, geothermal RMB 0.798bn).
  - Kaishan Machinery India was set up in Mumbai in 2019 and had sales of nearly US$10m in 2024.
  - A Hong Kong unit set up in 2012 covers ASEAN.
  - In 2022 the company targeted US$250m of overseas compressor revenue by 2025, "no later than 2026" (company claim).
- **CNP (Nanfang):** overseas revenue 17.19% of the total. Its first overseas service centre opened in Vietnam in 2024; CNP Pumps India has existed since August 2005.
- **Hanbell:** overseas revenue about 19.2% (own calculation). Its Bac Ninh (Vietnam) plant opened in May 2024, mainly for maintenance and servicing.
- **Leo Group:** international pump revenue RMB 2.454bn, about 52% of pump revenue (CGMIA citing the annual report). Its Tangerang (Indonesia) production base opened in 2023.
- **Dongya:** overseas revenue 5.69% of the total, mainly ASEAN.

**Incumbent response: a fighter brand (ELGi)**

- On the Q2 FY26 call ELGi said the low-cost range "targets customers prioritizing low upfront costs over energy efficiency… typically served by Chinese products".
- On the Q3 FY26 call it said it was investing in motor technology to cut dependence on permanent magnets and on China.
- On the Q4 call (29 May 2026) it reported FY26 sales +12% and PBT +17%.
- On the Q1 FY27 call (14 Aug 2026) it said the Tier 4 range was validated, first orders were in, and the formal launch was set for September in Hyderabad. Aftermarket is 28–30% of its India revenue, against 15–16% globally.

**Regulation**

- On 14 Jan 2026 the Ministry of Heavy Industries rescinded the Machinery and Electrical Equipment Safety (Omnibus Technical Regulation) Order 2024 (S.O. 239(E)), which would have required BIS certification for pumps, compressors, cranes and construction equipment.
- The separate hermetic-compressor QCO, for air-conditioning and refrigeration, remains in force, with import relaxations to 31 Mar 2027.

### 3. Robotics and automation: China's home lead is not yet travelling, except in warehouse robots

- **IFR World Robotics 2026 (24 Sep 2026):**
  - China installed 354,000 robots in 2025 (+20%), 59% of the world total.
  - Chinese suppliers' units rose 15% to 195,000, but their share of China's market fell to 55% from 57% in 2024. It was 47% in 2023.
- **Exports are new:**
  - China's industrial robot exports rose 48.7% in 2025 and exceeded imports for the first time (General Administration of Customs, via Global Times, Jan 2026). The deputy administrator said "Asia remains the primary market… key destinations including Vietnam, Thailand, and India."
  - H1 2026 exports were RMB 6.29bn (about US$930m), +18.6%, to 141 countries (ECNS/CGTN, Jul 2026). H1 2025 exports were US$746m, up nearly 60% (customs via SCMP).
  - As late as Aug 2024 the China Robot Industry Alliance described Chinese robot exports as "very limited".
- **India:** almost 10,500 installations in 2025 (+15%; 2020–25 CAGR 27%), against 9,120 in 2024 and 8,510 in 2023. Electronics is emerging as a customer industry (+171%). IFR's public releases give no figures for Thailand, Vietnam, Indonesia or Malaysia.
- **Robot arms abroad are weak:**
  - Estun's overseas share fell from 34.16% to 29.92% in 2025; it listed H-shares in March 2026.
  - Efort booked a RMB 154.8m impairment and a RMB 497m loss.
  - Inovance's overseas revenue was about 5.87% of 2025 revenue (secondary source), and its Thai plant serves its automotive business. Morningstar notes the risk to its target of 20% non-China sales.
- **AMRs are born global (Geek+):**
  - 2024 revenue: 28.1% Asia-Pacific (RMB 676m), 26.1% US, 17.9% EMEA; 72.1% of AMR solution revenue came from outside mainland China.
  - 2025: revenue RMB 3.171bn (+31.6%), of which RMB 2.387bn (75.3%) was outside mainland China, at a 46.6% gross margin.
  - H1 2026: revenue RMB 1.284bn (+25.3%), new orders RMB 2.385bn (+35.5%).
- **"Follow the home customer" is plausible, but the evidence is only indirect.**
  - IFR links Brazil's 212% jump in automotive robot installations to Chinese carmakers' investment there.
  - SUMEC (a trading company, not a filing) says Chinese end-users are investing overseas and their robots go with them.
  - We found no filing-level evidence of Chinese robot sales to Chinese-owned plants in Thailand, Vietnam or Indonesia.

## Exhibit candidate series

| Series | Data | Source |
|---|---|---|
| China excavators, domestic and export | 2020: 292,864 domestic, 34,741 export; 2021: 68,427 export; 2023: 89,980 domestic, 105,038 export; 2024: 100,588 export; 2025: 118,518 domestic, 116,739 export; H1 2026: 73,295 export (+33.5%) | CCMA via Mysteel, China Daily, SMM, SCMP |
| SANY overseas share of revenue | 2021 23%; 2022 45.7%; FY2025 63% | SANY FY2022 results (PR Newswire, 8 Apr 2023); FY2025 annual report |
| India HS 841480, China's share | 2019 44.0%; 2023 44.4%; 2024 52.6% | WITS (own calculation) |
| Thailand HS 841370, China's share | 2019 33.3%; 2023 48.9%; 2024 53.4% | WITS (own calculation) |
| Chinese suppliers' share of China's robot market | 2023 47%; 2024 57%; 2025 55% | IFR World Robotics 2024, 2025, 2026 |
| India robot installations | 2023 8,510; 2024 9,120; 2025 about 10,500 | IFR |
| Geek+ share of revenue outside mainland China | 2024 &gt;70%; 2025 75.3%; H1 2026 &gt;75% | Geek+ prospectus, FY2025 results, interim results |

**Comparability:** customs counted 135,200 crawler excavators exported in H1 2025, while CCMA's member-OEM figure for all of 2025 is 116,739. Customs data include mini-excavators from small makers, so use one basis per exhibit. Aggregator data put Jan–Nov 2025 crawler-excavator exports to Indonesia at 18,578 units worth US$910m, with an H1 2025 average unit value of about US$52,100. Verify these against China customs before use.

## Dated timeline (selected; company claims labelled)

- **2005 (Aug):** CNP Pumps India set up.
- **2007:** SANY's Chakan plant.
- **2012:** Kaishan's Hong Kong unit set up to cover ASEAN.
- **2016 (Oct):** SANY claims 52% of India's long-reach excavator niche (company claim).
- **2017 (Dec):** MoU between MNC Leasing and SANY Perkasa.
- **2018 (Dec):** low-down-payment financing launched.
- **2019:** Kaishan India set up in Mumbai; Siasun plans a plant in Thailand.
- **2021:** SANY cuts prices by about 20% in Indonesia; XCMG starts making in Chennai.
- **2022:** SANY's overseas share reaches 45.7%; Hangcha ships 100 lithium-ion forklifts to Southeast Asia.
- **2023:** Leo opens its Indonesian base; excavator exports exceed domestic sales.
- **2024:** Zoomlion's Khed City plant (May); Hanbell's Bac Ninh plant (May); CNP's Vietnam service centre.
- **2025:**
  - Geek+ lists in Hong Kong (9 Jul).
  - DGTR recommends crane duties (19 Sep); they lapse without being imposed.
  - Heli's Rayong plant (Nov).
  - Indonesia issues Permenperin 35/2025.
  - China becomes a net exporter of industrial robots.
- **2026:**
  - India rescinds the Omnibus Technical Regulation (14 Jan).
  - March: India's Press Note 2; Estun's H-share listing; the US Section 301 excess-capacity probe.
  - Hangcha's Chonburi plant (Jun).
  - LiuGong Karawang and XCMG Weda Bay (Jul).
  - US forced-labour Section 301 tariffs take effect (24 Jul).
  - OJK licenses Sany Indonesia Finance (14 Sep).
  - XCMG's Balikpapan remanufacturing base (16 Sep).
  - ELGi's Tier 4 launch (Sep).

## Where each category sits on the four-phase clock

| Category | Phase in 2026 | Evidence | Learnings that transfer | Failure modes that apply |
|---|---|---|---|---|
| Construction and mining equipment | Embed | Local finance company, remanufacturing, host-country plants | All six | Price wars at home; trade cases; credit exposure in a downturn |
| Forklifts | Push → Embed | About two-thirds of imports; Thai plants in 2025–26 | 1, 3, 4, 6 (lithium) | Dealers outgrow parts supply |
| Compressors and pumps | Beachheads → early Push | Rising share; service sites from 2019 to 2024; 6–45% of revenue overseas | 1, 3, partly 4. Credit largely irrelevant; electrification becomes energy efficiency | Buyers return where uptime and energy cost matter; the installed base holds |
| Robot arms and servos | Probe abroad | Export surge only from 2025; Estun and Efort setbacks | 1 (follow the customer), 3 | Overseas acquisitions and integration lose money |
| AMRs and warehouse robots | Push | Geek+ earns over 75% outside mainland China | 1; 3 (subscription, or robots-as-a-service) | High share invites security and trade scrutiny |

## Recommendations

**Direction.** Keep the governing thought, and add a qualifier in Chapter 3: "In the next categories the same moves arrive in a different order: price and channel first, the system later." Sharpen the central question to: "Which of the moves that won Chinese OEMs share can be copied, by whom, and how long is the window before the system follows the price in each category?"

**Structure: keep 20 pages and four chapters, but re-weight them.**

1. **The shift: two turning points, one test ahead (3 pp).** Turning point 1 is 2022 at firm level and 2023 in units. The 2026–27 test becomes a signpost.
2. **The playbook: six moves (6 pp).**
3. **The next categories: same moves, different order (5 pp).**
   - Heavy equipment as the reference (0.5 pp)
   - Forklifts as the bridge (0.5 pp)
   - Compressors and pumps (2 pp)
   - Robotics as a forward look led by AMRs (1.5 pp)
   - Clocks to 2030 (0.5 pp)
4. **The response (5 pp).** Add fighter brands (ELGi) as incumbents copying move 3, plus the uptime and installed-base defence (Thailand).
5. **Conclusion (1 p).**

Move to appendices: country profiles, the full HS-code tables, the excavator customs-versus-CCMA reconciliation, and robot-maker profiles.

**Exhibits (11):**

1. China's excavators, domestic and export, 2015 to H1 2026
2. Overseas revenue shares over time
3. Heat map of the 19 country–category pairs, 2019 and 2024
4. Indonesian excavators: China against Japan
5. Dated moves by year
6. The credit stack, from the 2017 MNC Leasing MoU to the 2026 OJK licence
7. The Thai counter-case
8. Compressors and pumps: import share and overseas footprint
9. Robots: China's home share against exports, plus Geek+'s geography
10. The clocks matrix
11. Signposts dashboard

## Corrections to the existing draft

1. "Chinese suppliers held 55% of China's market" is correct, but the share fell from 57%. Do not describe it as rising.
2. Turning point 1 moves from 2023 to 2022 at firm level (SANY 23% → 45.7%).
3. The draft says "QCOs withdrawn Jan 2026 for pumps/compressors". What was rescinded is the Omnibus Technical Regulation (S.O. 239(E)), and the hermetic-compressor QCO remains. Check the draft's wording ("withdrew a planned certification rule") against this.
4. India compressors, 44.0% → 52.6%: the 2023 share was still 44.4%, so the rise came in 2024. Unit values reflect product mix.
5. Indonesia's 2026 coal quota of "about 720 Mt": the ministry signalled "below 700 million tons" in Nov 2025 (Jakarta Globe). Reconcile with the final quota.
6. Inovance has only about 6% of revenue overseas (secondary source), and its Thai plant is automotive. Use it only as a cautionary example.
7. ELGi: confirm the September 2026 Hyderabad launch and first orders (Q1 FY27 call).
8. ELGi's "25–30% of Indian compressor volume" cannot be compared with HS 841480, where Chinese goods were about 79% of 2023 import units. Label it as a company estimate of the industrial market.

## Data gaps

- IFR country data for the four ASEAN markets
- An HS 847950 series
- India's 8-digit compressor lines
- Brand listings on GeM and e-Katalog
- Forklift company filings by country
- Country-level revenue for Chinese pump and compressor makers (only Kaishan discloses India)
- Destination and robot-export figures from aggregators, which need checking against primary customs or CCMA data. Vendor-blog claims that Chinese robots are "20–40% cheaper" should not be used.

## Main sources (selection)

- SANY press releases: https://www.sanyglobal.com/press_releases/1069/ ; https://www.sanyglobal.com/press_releases/866/
- Jakarta Post (PAABI): https://www.thejakartapost.com/business/2024/02/13/heavy-equipment-sales-take-a-dive-as-commodity-prices-plunge.html ; https://www.thejakartapost.com/business/2026/04/09/heavy-equipment-sales-projected-to-rise-as-rkab-approvals-gather-pace
- WITS: https://wits.worldbank.org/trade/comtrade/en/country/IND/year/2023/tradeflow/Imports/partner/ALL/product/841480 (and the same paths for IND 2019, IDN 2023 and THA 2023, HS 841370)
- Kaishan, CNP, Hanbell, Dongya and Leo filings and pages: http://notice.10jqka.com.cn/api/pdf/a6fc400a8559c1e1.pdf ; http://xinpi.zqrb.cn/pdf/CYB/300145/2025/0429/9f7c03721ee8017995926a1eb81f55b4.pdf ; https://pu.cgmia.org.cn/News/Detail/23117 ; https://leopump.com/en/pump-manufacturer.html ; https://static.cninfo.com.cn/finalpage/2025-06-27/1224014851.PDF ; https://static.cninfo.com.cn/finalpage/2025-05-15/1223556556.PDF ; https://www.jintuomachinery.com/en/news/kaishan-information-kaishan-compressor-overseas-business-global-conference-held-at-kca/
- ELGi calls: https://ca.investing.com/news/company-news/elgi-equipments-ltd-bom522074-q2-2026-earnings-call-highlights-navigating-growth-amidst--4328038 ; https://finance.yahoo.com/markets/stocks/articles/elgi-equipments-ltd-bom-522074-010126707.html ; https://finance.yahoo.com/markets/stocks/articles/elgi-equipments-ltd-bom-522074-010534382.html
- India regulation: https://zeus.firm.in/regulatory-reset-withdrawal-of-the-machinery-and-electrical-equipment-safety/ ; https://www.taxscan.in/top-stories/govt-extends-quality-control-amendment-for-air-conditioners-and-compressor-import-relaxation-till-march-2027-1445872
- IFR: https://ifr.org/ifr-press-releases/news/five-million-robots-now-operate-in-factories-globally ; https://ifr.org/downloads/press_docs/2025-09-25-IFR_press_release_India_in_English.pdf ; https://ifr.org/downloads/press_docs/Market_Presentation_WR_Press_Conference_2026.pdf ; https://www.businesswire.com/news/home/20240829390139/en
- Robot exports: https://www.globaltimes.cn/page/202601/1353238.shtml ; https://www.sumec-itc.com/news/industrial-robot-export
- Geek+: https://www.manilatimes.net/2026/09/02/tmt-newswire/pr-newswire/subscription-based-services-boom-geek-reports-2026-interim-results-orders-up-355-breakthroughs-across-the-business-spectrum/2416690 ; https://kr-asia.com/geek-goes-public-in-hong-kong-with-a-global-robotics-agenda ; https://finance.yahoo.com/markets/stocks/articles/geekplus-hits-profitability-milestone-31-124000013.html
- Inovance: https://www.investing.com/news/transcripts/earnings-call-transcript-shenzhen-inovance-tech-sees-robust-q3-2025-growth-93CH-4307299 ; https://robots-daily.com/the-chinese-giant-youve-never-heard-of-inovance/
- Coal quota: https://jakartaglobe.id/business/indonesia-to-scale-back-coal-output-next-year-on-price-slump
