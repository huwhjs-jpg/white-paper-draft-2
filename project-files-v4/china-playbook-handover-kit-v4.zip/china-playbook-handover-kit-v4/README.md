# China Playbook handover kit v4 (2 Oct 2026)

Start with HANDOVER-BRIEF-v4.md. It is self-contained and supersedes brief v3, which is kept with briefs v1 and v2 for reference.

| Folder or file | What it holds |
|---|---|
| HANDOVER-BRIEF-v4.md | Status, standing instructions, locked items, structure, decisions (provisional ones marked), corrections, new evidence, exhibits, Word build, Step 9 checks, technical notes |
| v2/draft/ | Integrated draft v2: executive summary, About, Chapters 1–4, conclusion, appendix plan, references cited (.md, .html, .docx) |
| v2/text/ | Source text in assembly-source HTML conventions, ready for the build pipeline |
| v2/review/ | Side-by-side review pages, Chapters 1–4 (new text next to the approved v1 text, with fix logs) |
| v2/tools/ | Scripts: assemble_draft.py, review_page.py, chapter_data.py (decisions and fix logs), sources.py (N1–N41) |
| v2/research/ | UN Comtrade robot re-pull (raw JSON plus summary) and verbatim extracts from filings read on 2 Oct 2026 |
| v2/outline-v6.md, decisions-and-fix-log.md, sources-batch3.md, 00-evidence-topup-note.md | Working notes |
| benchmark/ | The two benchmark files (past YCP papers; PDF gap-fill supplement) |
| outline/, evidence/, research/, original-kit/, build/, draft/, fonts/ | Unchanged from kit v3: approved outline v5 and v4, evidence dossiers and log, fact-check data, approved v1 text and exhibit source, build pipeline, Word draft v1, fonts |

Scripts expect build/ at /home/claude/build and original-kit/ at /home/claude/kit/kit (see brief v4 §9 and §11).
