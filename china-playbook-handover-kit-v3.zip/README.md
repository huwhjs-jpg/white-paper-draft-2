# China Playbook handover kit v3 (2 Oct 2026)

Start with HANDOVER-BRIEF-v3.md. It is self-contained and supersedes briefs v1 and v2 (kept for reference).

| Folder or file | What it holds |
|---|---|
| HANDOVER-BRIEF-v3.md | Status, the user's standing instructions, locked items, the approved outline v5 in full, key evidence with sources, corrections, the evidence top-up, the writing plan, exhibits, Word build, Step 9 checks, technical notes |
| outline/restructure-v5.html | The approved outline (open in a browser). v4 kept for its evidence-by-section tables |
| evidence/archetype-evidence-dossiers.md | Graded evidence by product group (batch 2) |
| evidence/evidence-log-and-trade-data.md | Every source with date and URL, the 36-product Comtrade screen and the 2015–2025 series |
| research/ | 1 Oct research report; fact-check batches and reference data (json) |
| original-kit/text/china-playbook-assembly-source.html | The approved text in the old 15-chapter structure (the source for rewriting) |
| draft/ | Word draft v1 (.docx) and its PDF |
| build/ | Build pipeline, data and 28 rendered v1 exhibits |
| original-kit/ | Brief v1, step pages, exhibit source, pack data, scripts |
| fonts/ | Rendering fonts and fonts.conf |

Not included (attach separately from the old Project): china-playbook-lessons-from-past-white-papers.md and pdf-gap-fill-supplement.md.
Scripts expect build/ at /home/claude/build and original-kit/ at /home/claude/kit/kit.
